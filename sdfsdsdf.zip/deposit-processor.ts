import { db } from './src/lib/db';

/**
 * Обрабатывает confirmed депозиты, которые еще не были зачислены на баланс
 */
export async function processConfirmedDeposits() {
  console.log('🔍 Проверка confirmed депозитов...');

  try {
    return await db.transaction(async (client) => {
      // Находим confirmed депозиты без записей в ledger
      const unprocessedDeposits = await client.query(`
        SELECT d.*
        FROM deposits d
        WHERE d.status = 'confirmed'
        AND d.id NOT IN (
          SELECT DISTINCT related_deposit_id
          FROM ledger_entries
          WHERE related_deposit_id IS NOT NULL
          AND entry_type = 'deposit_in'
        )
        ORDER BY d.created_at ASC
      `);

      console.log(`💰 Найдено ${unprocessedDeposits.rows.length} необработанных confirmed депозитов`);

      if (unprocessedDeposits.rows.length === 0) {
        return { processed: 0, success: true };
      }

      let processedCount = 0;

      for (const deposit of unprocessedDeposits.rows) {
        try {
          console.log(`\n💰 Обработка депозита ID: ${deposit.id}`);
          console.log(`  Пользователь: ${deposit.user_id}`);
          console.log(`  Желаемая сумма: ${deposit.desired_amount} ${deposit.currency}`);

          // Используем desired_amount - сумму, которую пользователь хотел внести
          const amountToCredit = parseFloat(String(deposit.desired_amount || deposit.amount));

          // 1. Создаем или обновляем баланс пользователя
          await client.query(`
            INSERT INTO users_balance (user_id, currency, available, bonus, locked, updated_at)
            VALUES ($1, $2, $3, 0, 0, NOW())
            ON CONFLICT (user_id, currency)
            DO UPDATE SET
              available = users_balance.available + $3,
              updated_at = NOW()
          `, [deposit.user_id, deposit.currency, amountToCredit]);

          // 2. Создаем запись в ledger_entries
          await client.query(`
            INSERT INTO ledger_entries (
              user_id,
              currency,
              entry_type,
              amount,
              balance_available_delta,
              balance_bonus_delta,
              balance_locked_delta,
              related_deposit_id,
              idempotency_key,
              created_at
            ) VALUES ($1, $2, 'deposit_in', $3, $3, 0, 0, $4, $5, NOW())
          `, [
            deposit.user_id,
            deposit.currency,
            amountToCredit,
            deposit.id,
            `auto_deposit_${deposit.id}_${Date.now()}`
          ]);

          // 3. Получаем обновленный баланс
          const balanceResult = await client.query(`
            SELECT available FROM users_balance
            WHERE user_id = $1 AND currency = $2
          `, [deposit.user_id, deposit.currency]);

          const newBalance = balanceResult.rows[0]?.available || '0';

          console.log(`  ✅ Зачислено ${amountToCredit} ${deposit.currency}`);
          console.log(`  💳 Новый баланс: ${newBalance} ${deposit.currency}`);

          processedCount++;

        } catch (error) {
          console.error(`  ❌ Ошибка обработки депозита ${deposit.id}:`, error);
        }
      }

      console.log(`\n🎉 Обработано депозитов: ${processedCount} из ${unprocessedDeposits.rows.length}`);

      return {
        processed: processedCount,
        total: unprocessedDeposits.rows.length,
        success: true
      };
    });

  } catch (error) {
    console.error('❌ Ошибка при обработке депозитов:', error);
    return {
      processed: 0,
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

if (require.main === module) {
  processConfirmedDeposits()
    .then(result => {
      console.log('Результат:', result);
      process.exit(0);
    })
    .catch(error => {
      console.error('Критическая ошибка:', error);
      process.exit(1);
    });
}
