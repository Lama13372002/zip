"use client";
import { useEffect, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { LogItem } from '@/types';

export default function LogsView() {
  const [type, setType] = useState<'audit'|'provider'|'webhooks'>('audit');
  const [items, setItems] = useState<LogItem[]>([]);

  const load = useCallback(async () => {
    const res = await fetch(`/api/admin/logs?type=${type}&limit=50`);
    const data = await res.json();
    setItems(data.data?.items || []);
  }, [type]);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <Button variant={type==='audit'?'default':'outline'} onClick={()=>setType('audit')}>Audit</Button>
        <Button variant={type==='provider'?'default':'outline'} onClick={()=>setType('provider')}>Provider</Button>
        <Button variant={type==='webhooks'?'default':'outline'} onClick={()=>setType('webhooks')}>Webhooks</Button>
        <Button onClick={load}>Reload</Button>
      </div>
      <div className="space-y-2 max-h-[400px] overflow-auto border rounded-md p-2 text-xs">
        {items.map((it, idx)=>(
          <pre key={idx} className="whitespace-pre-wrap break-words">{JSON.stringify(it, null, 2)}</pre>
        ))}
      </div>
    </div>
  );
}
