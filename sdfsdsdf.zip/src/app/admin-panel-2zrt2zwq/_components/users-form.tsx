"use client";
import { useEffect, useState, useCallback } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { UserListItem } from '@/types';

export default function UsersForm() {
  const [items, setItems] = useState<UserListItem[]>([]);
  const [q, setQ] = useState('');

  const load = useCallback(async () => {
    const res = await fetch('/api/admin/users' + (q?`?q=${encodeURIComponent(q)}`:''));
    const data = await res.json();
    setItems(data.users || []);
  }, [q]);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <Input placeholder="Search by telegram_id or phone" value={q} onChange={e=>setQ(e.target.value)} />
        <Button onClick={load}>Search</Button>
      </div>
      <div className="space-y-2">
        {items.map(u => (
          <div key={u.id} className="grid grid-cols-2 md:grid-cols-7 gap-2 items-center border p-3 rounded-md">
            <div className="text-xs">{u.id} / {u.telegram_id}</div>
            <div className="text-xs">{u.phone||'-'}</div>
            <div className="text-xs">{u.language}</div>
            <div className="text-xs">{u.kyc_status}</div>
            <div className="text-xs">{u.ref_code}</div>
            <div className="text-xs">ref-by: {u.referred_by_id||'-'}</div>
            <div className="text-xs">{new Date(u.created_at).toLocaleString()}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
