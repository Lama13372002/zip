export function Section({ title, description, actions, children }: { title: string; description?: string; actions?: React.ReactNode; children: React.ReactNode; }) {
  return (
    <section className="bg-white border rounded-xl p-5 shadow-sm">
      <div className="flex items-start justify-between gap-4 mb-4">
        <div>
          <h2 className="text-lg font-semibold">{title}</h2>
          {description && <p className="text-sm text-neutral-500 mt-1">{description}</p>}
        </div>
        {actions}
      </div>
      {children}
    </section>
  );
}
