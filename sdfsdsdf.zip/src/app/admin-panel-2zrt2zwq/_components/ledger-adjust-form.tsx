"use client";
import { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface UserInfo {
  id: string;
  telegram_id: string;
  username?: string;
  phone?: string;
  created_at: string;
  balance: {
    available: string;
    bonus: string;
    locked: string;
  };
}

export default function LedgerAdjustForm() {
  const [userInput, setUserInput] = useState('');
  const [userInfo, setUserInfo] = useState<UserInfo | null>(null);
  const [amount, setAmount] = useState('');
  const [reason, setReason] = useState('');
  const [isBonus, setIsBonus] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Поиск пользователя по ID или username
  const searchUser = async (input: string) => {
    if (!input.trim()) {
      setUserInfo(null);
      setError('');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const res = await fetch(`/api/admin/users/search?q=${encodeURIComponent(input.trim())}`);
      const data = await res.json();

      if (res.ok && data.success && data.user) {
        setUserInfo(data.user);
        setError('');
      } else {
        setUserInfo(null);
        setError(data.error || 'Пользователь не найден');
      }
    } catch (err) {
      setUserInfo(null);
      setError('Ошибка поиска пользователя');
    } finally {
      setLoading(false);
    }
  };

  // Дебаунс поиска
  useEffect(() => {
    const timer = setTimeout(() => {
      searchUser(userInput);
    }, 500);

    return () => clearTimeout(timer);
  }, [userInput]);

  const submit = async () => {
    if (!userInfo) {
      setError('Сначала найдите пользователя');
      return;
    }

    if (!amount || !reason) {
      setError('Заполните сумму и причину');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/admin/ledger/adjust', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          user_id: userInfo.id,
          amount: Number(amount),
          reason,
          is_bonus: isBonus
        })
      });

      const data = await res.json();

      if (res.ok && data.success) {
        setUserInput('');
        setUserInfo(null);
        setAmount('');
        setReason('');
        setIsBonus(false);
        alert('Операция выполнена успешно!');
      } else {
        setError(data.error || 'Ошибка выполнения операции');
      }
    } catch (err) {
      setError('Ошибка сети');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="text-sm font-medium">Поиск пользователя</label>
          <Input
            placeholder="ID пользователя или @username"
            value={userInput}
            onChange={e=>setUserInput(e.target.value)}
            className={userInfo ? 'border-green-500' : error ? 'border-red-500' : ''}
          />
          {loading && <p className="text-sm text-gray-500">Поиск...</p>}
          {userInfo && (
            <div className="p-3 bg-green-100 border border-green-300 rounded text-sm text-green-800">
              <p><strong>ID:</strong> {userInfo.id}</p>
              <p><strong>Telegram ID:</strong> {userInfo.telegram_id}</p>
              {userInfo.username && <p><strong>Username:</strong> @{userInfo.username}</p>}
              {userInfo.phone && <p><strong>Телефон:</strong> {userInfo.phone}</p>}
              <p><strong>Баланс:</strong> {userInfo.balance?.available || '0'} USDT</p>
            </div>
          )}
        </div>

        <div className="space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-sm font-medium">Сумма (+/-)</label>
              <Input
                placeholder="100 или -50"
                value={amount}
                onChange={e=>setAmount(e.target.value)}
                type="number"
                step="0.01"
              />
            </div>
            <div>
              <label className="text-sm font-medium">Причина</label>
              <Input
                placeholder="Ручное пополнение"
                value={reason}
                onChange={e=>setReason(e.target.value)}
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="isBonus"
              checked={isBonus}
              onChange={e=>setIsBonus(e.target.checked)}
            />
            <label htmlFor="isBonus" className="text-sm">Бонусный баланс</label>
          </div>

          <Button
            onClick={submit}
            disabled={loading || !userInfo}
            className="w-full"
          >
            {loading ? 'Обработка...' : 'Выполнить операцию'}
          </Button>

          {error && <p className="text-sm text-red-500">{error}</p>}
        </div>
      </div>
    </div>
  );
}
