"use client";
import { useEffect, useState } from "react";
import LoginForm from "./login-form";
import { Button } from "@/components/ui/button";

export default function AdminGuard({ children }: { children: React.ReactNode }) {
  const [authenticated, setAuthenticated] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);

  const checkAuth = async () => {
    try {
      const response = await fetch('/api/admin/auth', {
        method: 'GET',
        credentials: 'include',
      });
      const data = await response.json();
      setAuthenticated(data.authenticated === true);
    } catch (error) {
      console.error('Auth check failed:', error);
      setAuthenticated(false);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/admin/auth', {
        method: 'DELETE',
        credentials: 'include',
      });
      setAuthenticated(false);
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  const handleLoginSuccess = () => {
    setAuthenticated(true);
  };

  useEffect(() => {
    checkAuth();
  }, []);

  // Показываем загрузку во время проверки
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-neutral-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-neutral-600">Checking authentication...</p>
        </div>
      </div>
    );
  }

  // Если не аутентифицирован, показываем форму логина
  if (!authenticated) {
    return <LoginForm onSuccess={handleLoginSuccess} />;
  }

  // Если аутентифицирован, показываем админку с кнопкой выхода
  return (
    <div className="min-h-screen bg-neutral-50">
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-5xl mx-auto px-4 py-3 flex justify-between items-center">
          <h1 className="text-xl font-bold text-neutral-900">
            🛠️ Admin Panel
          </h1>
          <Button
            onClick={handleLogout}
            variant="outline"
            size="sm"
          >
            🚪 Logout
          </Button>
        </div>
      </div>
      <div className="max-w-5xl mx-auto px-4 py-6">
        {children}
      </div>
    </div>
  );
}
