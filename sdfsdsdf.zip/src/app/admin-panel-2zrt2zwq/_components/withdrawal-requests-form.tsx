"use client";
import { useEffect, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { WithdrawalRequest } from '@/types';

interface WithdrawalRequestWithDetails extends WithdrawalRequest {
  telegram_id: number;
  user_display: string;
  investment_amount: number;
  tariff_code: string;
  tariff_name: string;
}

export default function WithdrawalRequestsForm() {
  const [requests, setRequests] = useState<WithdrawalRequestWithDetails[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [selectedRequest, setSelectedRequest] = useState<WithdrawalRequestWithDetails | null>(null);
  const [adminNotes, setAdminNotes] = useState('');
  const [processing, setProcessing] = useState(false);
  const [stats, setStats] = useState<Record<string, { count: number; total_amount: number }>>({});

  const loadRequests = useCallback(async () => {
    setLoading(true);
    try {
      const url = filter === 'all' ? '/api/admin/withdrawal-requests' : `/api/admin/withdrawal-requests?status=${filter}`;
      const res = await fetch(url);
      const data = await res.json();
      if (data.success) {
        setRequests(data.data?.items || []);
      }
    } catch (e) {
      console.error('Failed to load withdrawal requests:', e);
    }
    setLoading(false);
  }, [filter]);

  const loadStats = useCallback(async () => {
    try {
      const res = await fetch('/api/admin/withdrawal-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'stats' })
      });
      const data = await res.json();
      if (data.success) {
        setStats(data.data?.stats || {});
      }
    } catch (e) {
      console.error('Failed to load stats:', e);
    }
  }, []);

  useEffect(() => {
    loadRequests();
    loadStats();
  }, [filter, loadRequests, loadStats]);

  const processRequest = async (action: 'approve' | 'reject') => {
    if (!selectedRequest) return;

    setProcessing(true);
    try {
      const res = await fetch('/api/admin/withdrawal-requests', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: selectedRequest.id,
          action,
          admin_notes: adminNotes
        })
      });

      const data = await res.json();
      if (data.success) {
        await loadRequests();
        await loadStats();
        setSelectedRequest(null);
        setAdminNotes('');
        alert(`Запрос ${action === 'approve' ? 'одобрен' : 'отклонен'}: ${data.data.message}`);
      } else {
        alert(`Ошибка: ${data.error}`);
      }
    } catch (e) {
      alert(`Ошибка обработки: ${e}`);
    }
    setProcessing(false);
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      pending: 'secondary',
      approved: 'default',
      rejected: 'destructive'
    } as const;

    const labels = {
      pending: 'Ожидает',
      approved: 'Одобрен',
      rejected: 'Отклонен'
    };

    return (
      <Badge variant={variants[status as keyof typeof variants] || 'secondary'}>
        {labels[status as keyof typeof labels] || status}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      {/* Статистика */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Ожидающие</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.pending?.count || 0}</div>
            <div className="text-sm text-gray-600">{(stats.pending?.total_amount || 0).toFixed(2)} USDT</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Одобренные</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.approved?.count || 0}</div>
            <div className="text-sm text-gray-600">{(stats.approved?.total_amount || 0).toFixed(2)} USDT</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Отклоненные</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{stats.rejected?.count || 0}</div>
            <div className="text-sm text-gray-600">{(stats.rejected?.total_amount || 0).toFixed(2)} USDT</div>
          </CardContent>
        </Card>
      </div>

      {/* Фильтры */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-2">
            {['all', 'pending', 'approved', 'rejected'].map(status => (
              <Button
                key={status}
                variant={filter === status ? 'default' : 'outline'}
                size="sm"
                onClick={() => setFilter(status as typeof filter)}
              >
                {status === 'all' ? 'Все' :
                 status === 'pending' ? 'Ожидающие' :
                 status === 'approved' ? 'Одобренные' : 'Отклоненные'}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Список запросов */}
      {loading ? (
        <div className="text-center py-8">Загрузка...</div>
      ) : requests.length === 0 ? (
        <div className="text-center py-8 text-gray-500">Запросов не найдено</div>
      ) : (
        <div className="space-y-4">
          {requests.map((request) => (
            <Card key={request.id} className="p-4">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                <div>
                  <div className="font-medium">ID: {request.id}</div>
                  <div className="text-sm text-gray-600">
                    Пользователь: {request.user_display}
                  </div>
                  <div className="text-sm text-gray-600">
                    Тариф: {request.tariff_code}
                  </div>
                </div>

                <div>
                  <div className="font-medium">{Number(request.amount).toFixed(2)} USDT</div>
                  <div className="text-sm text-gray-600">
                    Инвестиция: {request.investment_id}
                  </div>
                </div>

                <div>
                  {getStatusBadge(request.status)}
                  <div className="text-sm text-gray-600 mt-1">
                    {new Date(request.requested_at).toLocaleDateString('ru-RU')}
                  </div>
                </div>

                <div>
                  {request.status === 'pending' && (
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button
                          size="sm"
                          onClick={() => {
                            setSelectedRequest(request);
                            setAdminNotes('');
                          }}
                        >
                          Обработать
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Обработка запроса на возврат тела</DialogTitle>
                        </DialogHeader>

                        <div className="space-y-4">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <strong>Пользователь:</strong> {request.user_display}
                            </div>
                            <div>
                              <strong>Сумма:</strong> {Number(request.amount).toFixed(2)} USDT
                            </div>
                            <div>
                              <strong>Тариф:</strong> {request.tariff_name}
                            </div>
                            <div>
                              <strong>Дата запроса:</strong> {new Date(request.requested_at).toLocaleDateString('ru-RU')}
                            </div>
                          </div>

                          {request.reason && (
                            <div>
                              <Label>Причина запроса:</Label>
                              <div className="text-sm bg-gray-50 p-2 rounded">{request.reason}</div>
                            </div>
                          )}

                          <div>
                            <Label htmlFor="admin-notes">Заметки администратора:</Label>
                            <Input
                              id="admin-notes"
                              value={adminNotes}
                              onChange={(e) => setAdminNotes(e.target.value)}
                              placeholder="Добавьте комментарий (необязательно)"
                            />
                          </div>

                          <div className="flex gap-3">
                            <Button
                              variant="destructive"
                              onClick={() => processRequest('reject')}
                              disabled={processing}
                              className="flex-1"
                            >
                              {processing ? 'Обработка...' : 'Отклонить'}
                            </Button>
                            <Button
                              onClick={() => processRequest('approve')}
                              disabled={processing}
                              className="flex-1"
                            >
                              {processing ? 'Обработка...' : 'Одобрить'}
                            </Button>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                  )}

                  {request.status !== 'pending' && request.processed_at && (
                    <div className="text-sm text-gray-600">
                      Обработан: {new Date(request.processed_at).toLocaleDateString('ru-RU')}
                      {request.admin_notes && (
                        <div className="text-xs mt-1">
                          Заметка: {request.admin_notes}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
