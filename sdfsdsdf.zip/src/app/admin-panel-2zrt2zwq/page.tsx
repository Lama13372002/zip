'use client';

import { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowDownRight, ArrowUpRight, Clock, CheckCircle, XCircle, AlertCircle, Users, DollarSign, Loader2, Eye, Check, X, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ErrorDialog } from '@/components/ui/error-dialog';
import Link from 'next/link';

import TariffsForm from './_components/tariffs-form';
import ConfigForm from './_components/config-form';
import ProvidersForm from './_components/providers-form';
import UsersForm from './_components/users-form';
import LogsView from './_components/logs-view';
import LedgerAdjustForm from './_components/ledger-adjust-form';
import WithdrawalRequestsForm from './_components/withdrawal-requests-form';
import { VerificationsForm } from './_components/verifications-form';

interface Deposit {
  id: number;
  telegram_id: number;
  user_display: string;
  amount: number;
  desired_amount?: number;        // Желаемая сумма к получению
  pay_amount?: number;           // Сумма к оплате
  platform_fee_percent?: number; // Процент платформенной комиссии
  platform_fee_amount?: number;  // Размер платформенной комиссии
  merchant_amount?: number;
  currency: string;
  status: string;
  network_code: string;
  address?: string;
  provider_tx_id?: string;
  created_at: string;
  confirmed_at?: string;
}

interface Withdrawal {
  id: number;
  telegram_id: number;
  user_display: string;
  amount: number;
  address: string;
  fee: number;
  currency: string;
  status: string;
  network_code: string;
  provider_tx_id?: string;
  created_at: string;
  processed_at?: string;
}

export default function AdminPage() {
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [depositsLoading, setDepositsLoading] = useState(true);
  const [withdrawalsLoading, setWithdrawalsLoading] = useState(true);
  const [processingWithdrawal, setProcessingWithdrawal] = useState<number | null>(null);
  const [syncingWithdrawal, setSyncingWithdrawal] = useState<number | null>(null);
  const [selectedDeposit, setSelectedDeposit] = useState<Deposit | null>(null);
  const [selectedWithdrawal, setSelectedWithdrawal] = useState<Withdrawal | null>(null);
  const [errorDialog, setErrorDialog] = useState<{
    isOpen: boolean;
    title: string;
    errorData: {
      error: string;
      details?: string;
      debugInfo?: Record<string, unknown>;
      timestamp?: string;
    } | null;
  }>({
    isOpen: false,
    title: '',
    errorData: null
  });
  const [activeTab, setActiveTab] = useState<string>('withdrawals');
  const { toast } = useToast();

  // Загрузка депозитов
  const loadDeposits = useCallback(async () => {
    try {
      setDepositsLoading(true);
      const response = await fetch('/api/admin/deposits?limit=50');
      const result = await response.json();

      if (result.success) {
        setDeposits(result.data.deposits);
      } else {
        console.error('Failed to load deposits:', result);

        toast({
          title: "Error",
          description: "Failed to load deposits. Click for details.",
          variant: "destructive",
        });

        setErrorDialog({
          isOpen: true,
          title: "Failed to Load Deposits",
          errorData: {
            error: result.error || "Unknown API error while loading deposits",
            details: result.details || "Server returned unsuccessful response",
            debugInfo: {
              ...result,
              endpoint: '/api/admin/deposits',
              method: 'GET'
            },
            timestamp: new Date().toISOString()
          }
        });
      }
    } catch (error) {
      console.error('Deposits loading error:', error);

      const errorMessage = error instanceof Error ? error.message : 'Unknown network error';

      toast({
        title: "Network Error",
        description: "Failed to load deposits. Click for details.",
        variant: "destructive",
      });

      setErrorDialog({
        isOpen: true,
        title: "Network Error Loading Deposits",
        errorData: {
          error: `Network Error: ${errorMessage}`,
          details: "Failed to connect to server while loading deposits",
          debugInfo: {
            error: errorMessage,
            errorType: 'NetworkError',
            endpoint: '/api/admin/deposits',
            method: 'GET'
          },
          timestamp: new Date().toISOString()
        }
      });
    } finally {
      setDepositsLoading(false);
    }
  }, [toast]);

  // Загрузка выводов
  const loadWithdrawals = useCallback(async () => {
    try {
      setWithdrawalsLoading(true);
      const response = await fetch('/api/admin/withdrawals?limit=50');
      const result = await response.json();

      if (result.success) {
        setWithdrawals(result.data.withdrawals);
      } else {
        console.error('Failed to load withdrawals:', result);

        toast({
          title: "Error",
          description: "Failed to load withdrawals. Click for details.",
          variant: "destructive",
        });

        setErrorDialog({
          isOpen: true,
          title: "Failed to Load Withdrawals",
          errorData: {
            error: result.error || "Unknown API error while loading withdrawals",
            details: result.details || "Server returned unsuccessful response",
            debugInfo: {
              ...result,
              endpoint: '/api/admin/withdrawals',
              method: 'GET'
            },
            timestamp: new Date().toISOString()
          }
        });
      }
    } catch (error) {
      console.error('Withdrawals loading error:', error);

      const errorMessage = error instanceof Error ? error.message : 'Unknown network error';

      toast({
        title: "Network Error",
        description: "Failed to load withdrawals. Click for details.",
        variant: "destructive",
      });

      setErrorDialog({
        isOpen: true,
        title: "Network Error Loading Withdrawals",
        errorData: {
          error: `Network Error: ${errorMessage}`,
          details: "Failed to connect to server while loading withdrawals",
          debugInfo: {
            error: errorMessage,
            errorType: 'NetworkError',
            endpoint: '/api/admin/withdrawals',
            method: 'GET'
          },
          timestamp: new Date().toISOString()
        }
      });
    } finally {
      setWithdrawalsLoading(false);
    }
  }, [toast]);

  // Обработка вывода
  const processWithdrawal = async (withdrawalId: number, action: 'approve' | 'reject') => {
    try {
      setProcessingWithdrawal(withdrawalId);

      const response = await fetch('/api/admin/withdrawals/process', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          withdrawal_id: withdrawalId,
          action: action,
          admin_id: 1, // В реальном приложении получаем из сессии
        }),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: "Success",
          description: `Withdrawal ${action}ed successfully`,
        });

        // Обновляем список выводов
        loadWithdrawals();
      } else {
        // Показываем краткую ошибку в toast
        toast({
          title: "Error",
          description: `${action === 'approve' ? 'Approval' : 'Rejection'} failed. Click for details.`,
          variant: "destructive",
        });

        // Логируем полную ошибку в консоль для разработчика
        console.error('Withdrawal processing failed:', {
          withdrawalId,
          action,
          error: result.error,
          details: result.details,
          debugInfo: result.debugInfo,
          response: result
        });

        // Показываем детальную ошибку в диалоге
        setErrorDialog({
          isOpen: true,
          title: `Withdrawal ${action.charAt(0).toUpperCase() + action.slice(1)} Failed`,
          errorData: {
            error: result.error || `Failed to ${action} withdrawal`,
            details: result.details,
            debugInfo: result.debugInfo,
            timestamp: new Date().toISOString()
          }
        });
      }
    } catch (error) {
      console.error('Network/parsing error during withdrawal processing:', error);

      const errorMessage = error instanceof Error ? error.message : 'Unknown network error';

      toast({
        title: "Network Error",
        description: "Connection failed. Click for details.",
        variant: "destructive",
      });

      // Показываем детальную ошибку сети в диалоге
      setErrorDialog({
        isOpen: true,
        title: `Network Error During Withdrawal ${action.charAt(0).toUpperCase() + action.slice(1)}`,
        errorData: {
          error: `Network/Connection Error: ${errorMessage}`,
          details: `Failed to communicate with server during withdrawal ${action}. This could be a network connectivity issue or server problem.`,
          debugInfo: {
            withdrawalId,
            action,
            error: errorMessage,
            errorType: 'NetworkError',
            timestamp: new Date().toISOString()
          },
          timestamp: new Date().toISOString()
        }
      });
    } finally {
      setProcessingWithdrawal(null);
    }
  };

  // Синхронизация статуса вывода с NOWPayments
  const syncWithdrawal = async (withdrawalId: number) => {
    try {
      setSyncingWithdrawal(withdrawalId);

      const response = await fetch('/api/admin/withdrawals/sync', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          withdrawal_id: withdrawalId,
          admin_id: 1, // В реальном приложении получаем из сессии
        }),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: "Success",
          description: result.data.message || 'Status synchronized successfully',
        });

        // Обновляем список выводов
        loadWithdrawals();
      } else {
        toast({
          title: "Sync Error",
          description: "Failed to sync withdrawal status. Click for details.",
          variant: "destructive",
        });

        console.error('Withdrawal sync failed:', result);

        setErrorDialog({
          isOpen: true,
          title: "Withdrawal Sync Failed",
          errorData: {
            error: result.error || 'Failed to sync withdrawal status',
            details: result.details,
            debugInfo: result.debugInfo,
            timestamp: new Date().toISOString()
          }
        });
      }
    } catch (error) {
      console.error('Network error during withdrawal sync:', error);

      const errorMessage = error instanceof Error ? error.message : 'Unknown network error';

      toast({
        title: "Network Error",
        description: "Failed to sync withdrawal. Click for details.",
        variant: "destructive",
      });

      setErrorDialog({
        isOpen: true,
        title: "Network Error During Withdrawal Sync",
        errorData: {
          error: `Network Error: ${errorMessage}`,
          details: 'Failed to communicate with server during withdrawal sync',
          debugInfo: {
            withdrawalId,
            error: errorMessage,
            errorType: 'NetworkError',
            timestamp: new Date().toISOString()
          },
          timestamp: new Date().toISOString()
        }
      });
    } finally {
      setSyncingWithdrawal(null);
    }
  };

  useEffect(() => {
    loadDeposits();
    loadWithdrawals();
  }, [loadDeposits, loadWithdrawals]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'confirmed':
      case 'completed':
        return <CheckCircle size={16} className="text-green-500" />;
      case 'pending':
      case 'processing':
        return <Clock size={16} className="text-yellow-500" />;
      case 'failed':
      case 'rejected':
        return <XCircle size={16} className="text-red-500" />;
      default:
        return <AlertCircle size={16} className="text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
      case 'completed':
        return 'text-green-600 border-green-200 bg-green-50';
      case 'pending':
      case 'processing':
        return 'text-yellow-600 border-yellow-200 bg-yellow-50';
      case 'failed':
      case 'rejected':
        return 'text-red-600 border-red-200 bg-red-50';
      default:
        return 'text-gray-600 border-gray-200 bg-gray-50';
    }
  };

  const pendingWithdrawals = withdrawals.filter(w => w.status === 'pending');
  const processingWithdrawals = withdrawals.filter(w => w.status === 'processing');

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">TMA Admin Panel</h1>
        <div className="flex gap-2">
          {pendingWithdrawals.length > 0 && (
            <Badge variant="destructive" className="animate-pulse">
              {pendingWithdrawals.length} Pending Withdrawals
            </Badge>
          )}
          {processingWithdrawals.length > 0 && (
            <Badge variant="secondary" className="animate-pulse">
              {processingWithdrawals.length} Processing Withdrawals
            </Badge>
          )}
        </div>
      </div>

      <div className="flex gap-2 flex-wrap">
        <Link className="text-sm underline" href="#tariffs">Tariffs</Link>
        <Link className="text-sm underline" href="#withdrawal-requests">Withdrawal Requests</Link>
        <Link className="text-sm underline" href="#verifications">Verifications</Link>
        <Link className="text-sm underline" href="#config">Config</Link>
        <Link className="text-sm underline" href="#providers">Providers</Link>
        <Link className="text-sm underline" href="#users">Users</Link>
        <Link className="text-sm underline" href="#logs">Logs</Link>
        <Link className="text-sm underline" href="#ledger">Ledger Adjust</Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Deposits</CardTitle>
            <ArrowDownRight className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {deposits.filter(d => d.status === 'confirmed').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Withdrawals</CardTitle>
            <ArrowUpRight className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {withdrawals.filter(w => w.status === 'completed').length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending / Processing</CardTitle>
            <Clock className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">
              {pendingWithdrawals.length} / {processingWithdrawals.length}
            </div>
            <p className="text-xs text-muted-foreground">
              Pending / Processing
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Volume</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {(deposits.reduce((sum, d) => sum + (d.merchant_amount || d.amount), 0)).toFixed(0)} USDT
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="withdrawals" className="space-y-4" value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="withdrawals">
            Withdrawals {(pendingWithdrawals.length > 0 || processingWithdrawals.length > 0) && (
              <div className="flex gap-1 ml-2">
                {pendingWithdrawals.length > 0 && (
                  <Badge variant="destructive">{pendingWithdrawals.length}</Badge>
                )}
                {processingWithdrawals.length > 0 && (
                  <Badge variant="secondary">{processingWithdrawals.length}</Badge>
                )}
              </div>
            )}
          </TabsTrigger>
          <TabsTrigger value="deposits">Deposits</TabsTrigger>
          <TabsTrigger value="tariffs">Tariffs</TabsTrigger>
          <TabsTrigger value="withdrawal-requests">Principal Withdrawals</TabsTrigger>
          <TabsTrigger value="verifications">Verifications</TabsTrigger>
          <TabsTrigger value="config">Config</TabsTrigger>
          <TabsTrigger value="providers">Providers</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="logs">Logs</TabsTrigger>
          <TabsTrigger value="ledger">Ledger</TabsTrigger>
        </TabsList>

        <TabsContent value="withdrawals" className="space-y-4">
          {processingWithdrawals.length > 0 && (
            <Card className="border-yellow-200 bg-yellow-50">
              <CardHeader>
                <CardTitle className="text-yellow-800 flex items-center gap-2">
                  <AlertCircle className="h-5 w-5" />
                  {processingWithdrawals.length} Processing Withdrawals Detected
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-yellow-700 mb-4">
                  These withdrawals are stuck in "processing" status. You can manually sync their status with NOWPayments
                  by clicking the sync button next to each withdrawal, or check the status of all processing withdrawals at once.
                </p>
                <Button
                  variant="outline"
                  onClick={() => window.open('/api/admin/withdrawals/sync', '_blank')}
                  className="border-yellow-300 text-yellow-700 hover:bg-yellow-100"
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Check All Processing Withdrawals
                </Button>
              </CardContent>
            </Card>
          )}
          <Card>
            <CardHeader>
              <CardTitle>Withdrawal Requests</CardTitle>
            </CardHeader>
            <CardContent>
              {withdrawalsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin" />
                  <span className="ml-2">Loading withdrawals...</span>
                </div>
              ) : withdrawals.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No withdrawals found
                </div>
              ) : (
                <div className="space-y-4">
                  {withdrawals.map((withdrawal) => (
                    <div key={withdrawal.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                          <ArrowUpRight className="h-5 w-5 text-red-600" />
                        </div>
                        <div>
                          <p className="font-semibold">{withdrawal.user_display}</p>
                          <p className="text-sm text-gray-500">ID: {withdrawal.telegram_id}</p>
                          <p className="text-sm text-gray-500">{withdrawal.network_code}</p>
                        </div>
                      </div>

                      <div className="text-center">
                        <p className="font-bold text-lg">{withdrawal.amount.toFixed(2)} USDT</p>
                        <p className="text-sm text-gray-500">Fee: {withdrawal.fee.toFixed(2)} USDT</p>
                      </div>

                      <div className="text-center">
                        <Badge className={getStatusColor(withdrawal.status)}>
                          {getStatusIcon(withdrawal.status)}
                          <span className="ml-1 capitalize">{withdrawal.status}</span>
                        </Badge>
                        <p className="text-xs text-gray-500 mt-1">
                          {new Date(withdrawal.created_at).toLocaleDateString()}
                        </p>
                      </div>

                      <div className="flex items-center space-x-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" onClick={() => setSelectedWithdrawal(withdrawal)}>
                              <Eye className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Withdrawal Details</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <label className="text-sm font-medium">User:</label>
                                <p>{withdrawal.user_display} (ID: {withdrawal.telegram_id})</p>
                              </div>
                              <div>
                                <label className="text-sm font-medium">Amount:</label>
                                <p>{withdrawal.amount.toFixed(2)} USDT</p>
                              </div>
                              <div>
                                <label className="text-sm font-medium">Address:</label>
                                <p className="break-all">{withdrawal.address}</p>
                              </div>
                              <div>
                                <label className="text-sm font-medium">Network:</label>
                                <p>{withdrawal.network_code}</p>
                              </div>
                              <div>
                                <label className="text-sm font-medium">Fee:</label>
                                <p>{withdrawal.fee.toFixed(2)} USDT</p>
                              </div>
                              <div>
                                <label className="text-sm font-medium">Status:</label>
                                <Badge className={getStatusColor(withdrawal.status)}>
                                  {withdrawal.status}
                                </Badge>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>

                        {withdrawal.status === 'pending' && (
                          <>
                            <Button
                              size="sm"
                              onClick={() => processWithdrawal(withdrawal.id, 'approve')}
                              disabled={processingWithdrawal === withdrawal.id}
                            >
                              {processingWithdrawal === withdrawal.id ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <Check className="h-4 w-4" />
                              )}
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => processWithdrawal(withdrawal.id, 'reject')}
                              disabled={processingWithdrawal === withdrawal.id}
                            >
                              {processingWithdrawal === withdrawal.id ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : (
                                <X className="h-4 w-4" />
                              )}
                            </Button>
                          </>
                        )}

                        {withdrawal.status === 'processing' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => syncWithdrawal(withdrawal.id)}
                            disabled={syncingWithdrawal === withdrawal.id}
                            title="Sync status with NOWPayments"
                          >
                            {syncingWithdrawal === withdrawal.id ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              <RefreshCw className="h-4 w-4" />
                            )}
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="deposits" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Deposits</CardTitle>
            </CardHeader>
            <CardContent>
              {depositsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin" />
                  <span className="ml-2">Loading deposits...</span>
                </div>
              ) : deposits.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No deposits found
                </div>
              ) : (
                <div className="space-y-4">
                  {deposits.map((deposit) => (
                    <div key={deposit.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <p className="font-semibold">{deposit.user_display}</p>
                            <p className="text-sm text-gray-500">ID: {deposit.telegram_id}</p>
                            <p className="text-sm text-gray-500">{deposit.network_code}</p>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          {/* Основные суммы */}
                          <div>
                            <p className="font-bold text-lg">{deposit.amount.toFixed(2)} USDT</p>
                            {deposit.desired_amount && (
                              <p className="text-sm text-gray-500">Desired: {deposit.desired_amount.toFixed(2)} USDT</p>
                            )}
                            {deposit.pay_amount && (
                              <p className="text-sm text-gray-500">Pay Amount: {deposit.pay_amount.toFixed(2)} USDT</p>
                            )}
                            {deposit.merchant_amount && (
                              <p className="text-sm text-gray-500">Received: {deposit.merchant_amount.toFixed(2)} USDT</p>
                            )}
                          </div>

                          {/* Комиссии */}
                          <div>
                            {deposit.platform_fee_percent && deposit.platform_fee_amount ? (
                              <div>
                                <p className="text-sm text-orange-600 font-medium">
                                  Platform Fee: {deposit.platform_fee_percent.toFixed(2)}%
                                </p>
                                <p className="text-sm text-orange-500">
                                  Amount: {deposit.platform_fee_amount.toFixed(4)} USDT
                                </p>
                              </div>
                            ) : (
                              <p className="text-sm text-gray-400">No platform fee</p>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="ml-4 text-right">
                        <Badge className={getStatusColor(deposit.status)}>
                          {getStatusIcon(deposit.status)}
                          <span className="ml-1 capitalize">{deposit.status}</span>
                        </Badge>
                        <p className="text-sm text-gray-500 mt-1">
                          {new Date(deposit.created_at).toLocaleDateString()}
                        </p>
                        <div className="mt-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" size="sm" onClick={() => setSelectedDeposit(deposit)}>
                                Details
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogTitle>Deposit Details</DialogTitle>
                              <div className="space-y-2">
                                <p><strong>User:</strong> {deposit.user_display} (ID: {deposit.telegram_id})</p>
                                <p><strong>Amount:</strong> {deposit.amount} USDT</p>
                                {deposit.desired_amount && (
                                  <p><strong>Desired Amount:</strong> {deposit.desired_amount} USDT</p>
                                )}
                                {deposit.pay_amount && (
                                  <p><strong>Pay Amount:</strong> {deposit.pay_amount} USDT</p>
                                )}
                                {deposit.platform_fee_percent && (
                                  <p><strong>Platform Fee:</strong> {deposit.platform_fee_percent}% ({deposit.platform_fee_amount} USDT)</p>
                                )}
                                <p><strong>Network:</strong> {deposit.network_code}</p>
                                <p><strong>Status:</strong> {deposit.status}</p>
                                <p><strong>Created:</strong> {new Date(deposit.created_at).toLocaleString()}</p>
                                {deposit.address && <p><strong>Address:</strong> {deposit.address}</p>}
                                {deposit.provider_tx_id && <p><strong>Transaction ID:</strong> {deposit.provider_tx_id}</p>}
                              </div>
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tariffs" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Tariff Plans</CardTitle></CardHeader>
            <CardContent>
              <TariffsForm />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="withdrawal-requests" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Principal Withdrawal Requests</CardTitle></CardHeader>
            <CardContent>
              <WithdrawalRequestsForm />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="verifications" className="space-y-4">
          <VerificationsForm />
        </TabsContent>

        <TabsContent value="config" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>App Config</CardTitle></CardHeader>
            <CardContent>
              <ConfigForm />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="providers" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Providers & Services</CardTitle></CardHeader>
            <CardContent>
              <ProvidersForm />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Users</CardTitle></CardHeader>
            <CardContent>
              <UsersForm />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="logs" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Logs</CardTitle></CardHeader>
            <CardContent>
              <LogsView />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="ledger" className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Ledger Adjustments</CardTitle></CardHeader>
            <CardContent>
              <LedgerAdjustForm />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Error Dialog */}
      <ErrorDialog
        isOpen={errorDialog.isOpen}
        onClose={() => setErrorDialog({ ...errorDialog, isOpen: false })}
        title={errorDialog.title}
        errorData={errorDialog.errorData || { error: 'Unknown error' }}
      />
    </div>
  );
}
