import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { nowPayments } from '@/lib/nowpayments';
import { generateRandomFee, calculateDepositWithFee } from '@/lib/utils';
import { v4 as uuidv4 } from 'uuid';

export async function POST(request: NextRequest) {
  let amount: string = '';
  let network: string = '';
  let user_id: string = '';

  try {
    const requestBody = await request.json();
    ({ amount, network, user_id } = requestBody);

    // Валидация входных данных
    if (!amount || !network || !user_id) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Проверяем лимиты для выбранной сети
    const serviceResult = await db.query(
      'SELECT min_amount, max_amount, fee_fixed, fee_percent FROM provider_services WHERE service_type = $1 AND network_code = $2 AND is_available = true',
      ['payment', network]
    );

    if (serviceResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: `Network ${network} is not available for deposits` },
        { status: 400 }
      );
    }

    const service = serviceResult.rows[0];
    const minAmount = parseFloat(String(service.min_amount || '10'));
    const maxAmount = parseFloat(String(service.max_amount || '1000000'));

    if (parseFloat(amount) < minAmount) {
      return NextResponse.json(
        { success: false, error: `Minimum amount is ${minAmount} USDT` },
        { status: 400 }
      );
    }

    if (parseFloat(amount) > maxAmount) {
      return NextResponse.json(
        { success: false, error: `Maximum amount is ${maxAmount} USDT` },
        { status: 400 }
      );
    }

    // Проверяем существование пользователя
    const userResult = await db.query(
      'SELECT id FROM users WHERE telegram_id = $1',
      [user_id]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = userResult.rows[0].id;
    const orderId = `deposit_${userId}_${Date.now()}`;

    // Генерируем случайную комиссию и рассчитываем сумму к оплате
    const desiredAmount = parseFloat(amount); // Сумма которую хочет получить пользователь
    const platformFeePercent = generateRandomFee(); // Случайная комиссия от 1.5% до 2.5%
    const calculation = calculateDepositWithFee(desiredAmount, platformFeePercent);

    const payCurrencyMap: Record<string, string> = {
      'TRON': 'usdttrc20',
      'BSC': 'usdtbsc',
      'ETH': 'usdterc20',
      'POLYGON': 'usdtmatic',
      'TON': 'usdtton',
    };

    // Создаем запись депозита в БД с нашими данными
    const depositResult = await db.query(
      `INSERT INTO deposits
       (user_id, currency, amount, status, provider, provider_order_id, network_code, platform_fee_percent, platform_fee_amount, desired_amount, pay_amount, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, NOW(), NOW())
       RETURNING id`,
      [
        userId,
        'USDT',
        calculation.pay_amount,      // Сумма к оплате (включая нашу комиссию)
        'pending',
        'nowpayments',
        orderId,
        network,
        calculation.fee_percent,     // Процент нашей комиссии
        calculation.fee_amount,      // Размер нашей комиссии
        calculation.desired_amount,  // Желаемая сумма к получению
        calculation.pay_amount       // Сумма к оплате
      ]
    );

    const depositId = depositResult.rows[0].id;

    try {
      // Создаем платеж в NOWPayments на полную сумму с нашей комиссией
      const np = await nowPayments.createPayment({
        price_amount: calculation.pay_amount, // Передаём увеличенную сумму
        price_currency: 'usd',
        pay_currency: payCurrencyMap[network] || 'trx',
        ipn_callback_url: process.env.NOWPAYMENTS_PAYMENT_WEBHOOK_URL,
        order_id: orderId,
        is_fixed_rate: false
      });

      // Обновляем запись депозита с данными от NOWPayments
      await db.query(
        `UPDATE deposits SET
         provider_uuid = $1,
         address = $2,
         url = $3,
         expired_at = $4,
         payment_status = $5,
         updated_at = NOW()
         WHERE id = $6`,
        [
          String(np.payment_id),
          null,
          np.pay_address,
          null,
          np.payment_status,
          depositId
        ]
      );

      // Логируем вызов API
      await db.query(
        `INSERT INTO provider_call_logs
         (provider, endpoint, http_method, request_body, response_body, status_code, related_deposit_id, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
        [
          'nowpayments',
          '/payment',
          'POST',
          JSON.stringify({
            order_id: orderId,
            requested_amount: desiredAmount,
            platform_fee: platformFeePercent,
            pay_amount: calculation.pay_amount,
            network
          }),
          JSON.stringify(np),
          200,
          depositId
        ]
      );

      return NextResponse.json({
        success: true,
        data: {
          deposit_id: depositId,
          order_id: orderId,
          desired_amount: calculation.desired_amount,
          pay_amount: calculation.pay_amount,
          platform_fee_percent: calculation.fee_percent,
          platform_fee_amount: calculation.fee_amount,
          network: network,
          address: np.pay_address,
          payment_url: null,
          expires_at: np.expiration_estimate_date || null,
          status: np.payment_status,
        }
      });

    } catch (cryptomusError: unknown) {
      // Обновляем статус депозита как failed
      await db.query(
        'UPDATE deposits SET status = $1, updated_at = NOW() WHERE id = $2',
        ['failed', depositId]
      );

      console.error('NOWPayments API error:', cryptomusError);

      // Извлекаем детальную информацию об ошибке
      let errorMessage = 'Failed to create payment. Please try again.';
      let errorDetails = '';

      if (cryptomusError instanceof Error) {
        errorMessage = cryptomusError.message;
        errorDetails = `NOWPayments Error: ${cryptomusError.message}`;

        // Если это HTTP ошибка, добавляем больше деталей
        if (cryptomusError.message.includes('NOWPayments error')) {
          const statusMatch = cryptomusError.message.match(/NOWPayments error (\d+)/);
          if (statusMatch) {
            const statusCode = statusMatch[1];
            // 201 это не ошибка - это успешное создание платежа
            if (statusCode === '201') {
              return NextResponse.json(
                { success: false, error: 'Payment response handling error - please contact support' },
                { status: 500 }
              );
            }

            switch (statusCode) {
              case '400':
                errorDetails += ' - Invalid request parameters';
                break;
              case '401':
                errorDetails += ' - Authentication failed';
                break;
              case '403':
                errorDetails += ' - Access forbidden';
                break;
              case '404':
                errorDetails += ' - Payment service not found';
                break;
              case '429':
                errorDetails += ' - Rate limit exceeded';
                break;
              case '500':
                errorDetails += ' - Payment service internal error';
                break;
              case '503':
                errorDetails += ' - Payment service unavailable';
                break;
              default:
                errorDetails += ` - HTTP error ${statusCode}`;
            }
          }
        }
      }

      // Логируем ошибку для администратора
      try {
        await db.query(
          `INSERT INTO provider_call_logs
           (provider, endpoint, http_method, request_body, response_body, status_code, related_deposit_id, created_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
          [
            'nowpayments',
            '/payment',
            'POST',
            JSON.stringify({ order_id: orderId, amount, network }),
            JSON.stringify({ error: errorDetails }),
            0,
            depositId
          ]
        );
      } catch (logError) {
        console.error('Failed to log error:', logError);
      }

      return NextResponse.json(
        {
          success: false,
          error: errorMessage,
          details: errorDetails,
          debugInfo: {
            network,
            payCurrency: payCurrencyMap[network],
            timestamp: new Date().toISOString(),
            orderId
          }
        },
        { status: 500 }
      );
    }

  } catch (error: unknown) {
    console.error('Deposit creation error:', error);

    let errorMessage = 'Internal server error';
    let errorDetails = '';

    if (error instanceof Error) {
      errorMessage = error.message;
      errorDetails = `System Error: ${error.message}`;

      // Добавляем стек трейс в детали для отладки
      if (error.stack) {
        errorDetails += `\nStack: ${error.stack.split('\n').slice(0, 3).join('\n')}`;
      }
    }

    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
        details: errorDetails,
        debugInfo: {
          timestamp: new Date().toISOString(),
          requestBody: { amount, network, user_id }
        }
      },
      { status: 500 }
    );
  }
}
