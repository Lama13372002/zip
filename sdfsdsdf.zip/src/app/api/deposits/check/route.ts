import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { nowPayments } from '@/lib/nowpayments';

export async function POST(request: NextRequest){
  try{
    const { order_id } = await request.json();
    if(!order_id){ return NextResponse.json({ success:false, error:'order_id required' }, {status:400}); }
    const depRes = await db.query('SELECT * FROM deposits WHERE provider_order_id=$1 AND provider=$2', [order_id, 'nowpayments']);
    if(depRes.rows.length===0){ return NextResponse.json({ success:false, error:'not found' }, {status:404}); }
    const d = depRes.rows[0];
    if(d.status !== 'pending'){
      return NextResponse.json({
        success:true,
        data:{
          status: d.status,
          tx_hash: d.provider_tx_id,
          network: d.network_code
        }
      });
    }
    if(!d.provider_uuid){ return NextResponse.json({ success:false, error:'payment_id missing' }, {status:400}); }
    const np = await nowPayments.getPayment(String(d.provider_uuid));
    const statusMap: Record<string,string> = { waiting:'pending', confirming:'pending', confirmed:'confirmed', sending:'confirmed', partially_paid:'confirmed', finished:'confirmed', failed:'failed', expired:'expired', refunded:'failed' };
    const newStatus = statusMap[np.payment_status] || 'pending';

    // Получаем хеш транзакции если доступен
    const txHash = np.payin_extra_id || null;

    await db.query(
      `UPDATE deposits SET payment_status=$1, status=$2, provider_tx_id=$3, updated_at=now() WHERE id=$4`,
      [np.payment_status, newStatus, txHash, d.id]
    );

    return NextResponse.json({
      success:true,
      data:{
        status: newStatus,
        tx_hash: txHash,
        network: d.network_code
      }
    });
  }catch(e){
    return NextResponse.json({ success:false, error:'Internal error' }, {status:500});
  }
}
