import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { UserQueryResult } from '@/types';
import { getApplicantInfo } from '@/lib/sumsub';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId');
    if (!userId) return NextResponse.json({ error: 'userId is required' }, { status: 400 });

    const userRes = await db.query('SELECT id, kyc_status FROM users WHERE telegram_id = $1', [userId]);
    if (userRes.rowCount === 0) return NextResponse.json({ error: 'User not found' }, { status: 404 });
    const u = userRes.rows[0] as UserQueryResult;

    const appRes = await db.query(
      `SELECT id, external_applicant_id, review_status, review_result, created_at, updated_at
       FROM sumsub_applications WHERE user_id = $1 AND external_applicant_id = $2
       ORDER BY updated_at DESC LIMIT 1`,
      [u.id, String(userId)]
    );

    let currentKycStatus = u.kyc_status;

    // Проверяем если статус pending, но в Sumsub нет заявки или она в начальном состоянии
    if (currentKycStatus === 'pending' && appRes.rows.length > 0) {
      const application = appRes.rows[0] as Record<string, unknown>;
      const timeSinceCreated = Date.now() - new Date(application.created_at as string).getTime();
      const oneMinuteInMs = 1 * 60 * 1000; // 1 минута

      // Если заявка создана более 1 минуты назад, проверяем её статус в Sumsub
      if (timeSinceCreated > oneMinuteInMs) {
        try {
          const sumsubInfo = await getApplicantInfo(String(userId));

          // Если в Sumsub нет заявки или пользователь не начал заполнение данных
          // (проверяем есть ли основная информация о заявке)
          const shouldReset = !sumsubInfo ||
                            !sumsubInfo.info ||
                            (!sumsubInfo.info.firstName && !sumsubInfo.info.lastName && !sumsubInfo.info.dob);

          if (shouldReset) {
            // Сбрасываем статус обратно на not_started
            await db.query('UPDATE users SET kyc_status = $1, updated_at = now() WHERE id = $2', ['not_started', u.id]);
            await db.query('DELETE FROM sumsub_applications WHERE user_id = $1 AND external_applicant_id = $2', [u.id, String(userId)]);
            currentKycStatus = 'not_started';
          }
        } catch (error) {
          // Если не удается получить информацию из Sumsub (например, заявка не найдена)
          // сбрасываем статус
          await db.query('UPDATE users SET kyc_status = $1, updated_at = now() WHERE id = $2', ['not_started', u.id]);
          await db.query('DELETE FROM sumsub_applications WHERE user_id = $1 AND external_applicant_id = $2', [u.id, String(userId)]);
          currentKycStatus = 'not_started';
        }
      }
    }

    return NextResponse.json({
      kycStatus: currentKycStatus,
      application: currentKycStatus === 'not_started' ? null : (appRes.rows[0] ?? null),
    });
  } catch (e: unknown) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Internal error' }, { status: 500 });
  }
}
