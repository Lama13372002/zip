import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

function tksort<T>(obj: T): T {
  if (obj && typeof obj === 'object' && !Array.isArray(obj)) {
    const sorted: Record<string, unknown> = {};
    Object.keys(obj as Record<string, unknown>)
      .sort()
      .forEach((k) => {
        const v = (obj as Record<string, unknown>)[k];
        if (v && typeof v === 'object' && !Array.isArray(v)) {
          sorted[k] = tksort(v as Record<string, unknown>);
        } else {
          sorted[k] = v;
        }
      });
    return sorted as unknown as T;
  }
  return obj;
}

// Payment webhook interface
interface NpPaymentIpn {
  payment_id?: string;
  payment_status?: string;
  pay_address?: string;
  pay_amount?: string;
  pay_currency?: string;
  order_id?: string;
  order_description?: string;
  purchase_id?: string;
  outcome_amount?: string;
  outcome_currency?: string;
  payment_hash?: string;
}

// Payout webhook interface
interface NpPayoutIpn {
  id?: string;
  batch_withdrawal_id?: string;
  status?: string;
  error?: string | null;
  currency?: string;
  amount?: string;
  address?: string;
  extra_id?: string | null;
  hash?: string | null;
  ipn_callback_url?: string | null;
  created_at?: string;
  requested_at?: string | null;
  updated_at?: string | null;
  unique_external_id?: string | null;
}

type WebhookBody = NpPaymentIpn | NpPaymentIpn[] | NpPayoutIpn | NpPayoutIpn[];

export async function POST(request: NextRequest) {
  try {
    const sig = request.headers.get('x-nowpayments-sig') || '';
    const body: WebhookBody = await request.json();
    const sorted = JSON.stringify(tksort(body));
    const crypto = await import('crypto');
    const expected = crypto
      .createHmac('sha512', (process.env.NOWPAYMENTS_IPN_SECRET || '').trim())
      .update(sorted)
      .digest('hex');

    console.log('=== NOWPayments Webhook Received ===');
    console.log('Body:', JSON.stringify(body, null, 2));
    console.log('Signature valid:', expected === sig);
    console.log('==================================');

    if (expected !== sig) {
      console.log('Invalid signature. Expected:', expected, 'Got:', sig);
      return NextResponse.json({ success: false, error: 'Invalid signature' }, { status: 400 });
    }

    // Определяем тип webhook по структуре данных
    const item = Array.isArray(body) ? body[0] : body;

    const isPayment = 'payment_id' in item || 'pay_address' in item || 'order_id' in item;
    const isPayout = 'id' in item || 'batch_withdrawal_id' in item || 'unique_external_id' in item;

    if (isPayment) {
      console.log('Processing as PAYMENT webhook');
      return await handlePaymentWebhook(body as NpPaymentIpn | NpPaymentIpn[]);
    } else if (isPayout) {
      console.log('Processing as PAYOUT webhook');
      return await handlePayoutWebhook(body as NpPayoutIpn | NpPayoutIpn[]);
    } else {
      console.log('Unknown webhook type:', body);
      return NextResponse.json({ success: false, error: 'Unknown webhook type' }, { status: 400 });
    }

  } catch (error) {
    console.error('Webhook processing error:', error);
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 });
  }
}

async function handlePaymentWebhook(body: NpPaymentIpn | NpPaymentIpn[]) {
  const item: NpPaymentIpn = Array.isArray(body) ? body[0] : body;
  const paymentId = item?.payment_id || '';

  await db.query(
    `INSERT INTO inbound_webhooks (source, event_type, external_id, payload, received_at, processing_status)
     VALUES ($1,$2,$3,$4::jsonb, now(), $5)`,
    ['nowpayments', 'payment', String(paymentId), JSON.stringify(body), 'pending']
  );

  // Логика обработки платежей - ищем по provider_uuid (не provider_payment_id!)
  console.log('🔍 Поиск депозита по payment_id:', paymentId, 'order_id:', item?.order_id);

  let dRes = await db.query('SELECT * FROM deposits WHERE provider_uuid = $1', [String(paymentId)]);
  if (dRes.rows.length === 0 && item?.order_id) {
    console.log('🔍 Депозит не найден по provider_uuid, ищем по provider_order_id');
    dRes = await db.query('SELECT * FROM deposits WHERE provider_order_id = $1', [String(item.order_id)]);
  }
  if (dRes.rows.length === 0) {
    console.log('❌ No matching deposit found for payment:', paymentId, 'order_id:', item?.order_id);
    console.log('📋 Полный webhook payload:', JSON.stringify(item, null, 2));
    return NextResponse.json({ success: true }, { status: 200 });
  }

  const d = dRes.rows[0];
  console.log('✅ Найден депозит:', {
    id: d.id,
    user_id: d.user_id,
    amount: d.amount,
    current_status: d.status,
    provider_uuid: d.provider_uuid,
    provider_order_id: d.provider_order_id
  });

  const statusRaw = (item?.payment_status || '').toUpperCase();
  console.log('📊 Статус платежа:', statusRaw);
  const statusMap: Record<string, string> = {
    WAITING: 'pending',
    CONFIRMING: 'confirming',
    CONFIRMED: 'confirmed',
    SENDING: 'processing',
    PARTIALLY_PAID: 'partially_paid',
    FINISHED: 'completed',
    FAILED: 'failed',
    REFUNDED: 'refunded',
    EXPIRED: 'expired',
  };
  const newStatus = statusMap[statusRaw] || 'pending';
  console.log('🔄 Обновление статуса:', d.status, '→', newStatus);

  await db.transaction(async (client) => {
    await client.query(
      `UPDATE deposits SET status=$1, provider_tx_id=$2, processed_at=CASE WHEN $3 THEN NOW() ELSE processed_at END, updated_at=now() WHERE id=$4`,
      [newStatus, item?.payment_hash || null, newStatus === 'completed' || newStatus === 'failed', d.id]
    );

    await client.query(
      `UPDATE inbound_webhooks SET processing_status=$1, processed_at=now() WHERE external_id=$2 AND source=$3`,
      ['processed', String(paymentId), 'nowpayments']
    );

    // 🚨 ЗАЧИСЛЕНИЕ ОТКЛЮЧЕНО! Теперь делает только deposit-monitor.js
    if (newStatus === 'confirmed' || newStatus === 'completed') {
      console.log(`✅ Депозит ${d.id} готов к зачислению через deposit-monitor.js`);
      console.log(`💰 Сумма к зачислению: ${parseFloat(String(d.desired_amount || d.amount))} USDT для пользователя ${d.user_id}`);
      console.log(`🔧 Зачисление будет выполнено автоматически через deposit-monitor.js каждые 5 секунд`);
    }
  });

  console.log('Payment webhook processed successfully:', paymentId, newStatus);
  return NextResponse.json({ success: true });
}

async function handlePayoutWebhook(body: NpPayoutIpn | NpPayoutIpn[]) {
  const item: NpPayoutIpn = Array.isArray(body) ? body[0] : body;
  const payoutId = item?.id || '';

  await db.query(
    `INSERT INTO inbound_webhooks (source, event_type, external_id, payload, received_at, processing_status)
     VALUES ($1,$2,$3,$4::jsonb, now(), $5)`,
    ['nowpayments', 'payout', String(payoutId), JSON.stringify(body), 'pending']
  );

  // Ищем withdrawal по provider_uuid или provider_order_id
  let wRes = await db.query('SELECT * FROM withdrawals WHERE provider_uuid = $1', [String(payoutId)]);
  if (wRes.rows.length === 0 && item?.unique_external_id) {
    wRes = await db.query('SELECT * FROM withdrawals WHERE provider_order_id = $1', [String(item.unique_external_id)]);
  }
  if (wRes.rows.length === 0) {
    console.log('No matching withdrawal found for payout:', payoutId, item?.unique_external_id);
    return NextResponse.json({ success: true }, { status: 200 });
  }

  const w = wRes.rows[0];
  const statusRaw = (item?.status || '').toUpperCase();
  const statusMap: Record<string, string> = {
    CREATING: 'processing',
    WAITING: 'processing',
    PROCESSING: 'processing',
    SENDING: 'processing',
    FINISHED: 'completed',
    FAILED: 'failed',
    DECLINED: 'failed',
  };
  const newStatus = statusMap[statusRaw] || 'processing';

  await db.transaction(async (client) => {
    await client.query(
      `UPDATE withdrawals SET status=$1, provider_tx_id=$2, txid=$3, processed_at=CASE WHEN $4 THEN NOW() ELSE processed_at END, updated_at=now() WHERE id=$5`,
      [newStatus, item?.hash || null, item?.hash || null, newStatus === 'completed' || newStatus === 'failed', w.id]
    );

    await client.query(
      `UPDATE inbound_webhooks SET processing_status=$1, processed_at=now() WHERE external_id=$2 AND source=$3`,
      ['processed', String(payoutId), 'nowpayments']
    );

    if (newStatus === 'completed') {
      // При успешном выводе снимаем полную сумму с заблокированных средств
      const totalAmount = parseFloat(String(w.amount)) + parseFloat(String(w.fee || 0));
      await client.query(
        `INSERT INTO ledger_entries
         (user_id, currency, entry_type, amount, balance_available_delta, balance_locked_delta, related_withdrawal_id, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
        [w.user_id, 'USDT', 'withdrawal_out', totalAmount, 0, -totalAmount, w.id]
      );
    }

    if (newStatus === 'failed') {
      // При неудачном выводе возвращаем полную сумму на доступный баланс
      const totalAmount = parseFloat(String(w.amount)) + parseFloat(String(w.fee || 0));
      await client.query(
        `INSERT INTO ledger_entries
         (user_id, currency, entry_type, amount, balance_available_delta, balance_locked_delta, related_withdrawal_id, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
        [w.user_id, 'USDT', 'withdrawal_out', totalAmount, totalAmount, -totalAmount, w.id]
      );
    }
  });

  console.log('Payout webhook processed successfully:', payoutId, newStatus);
  return NextResponse.json({ success: true });
}
