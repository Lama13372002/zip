import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      );
    }

    // Get user
    const userResult = await db.query(
      'SELECT id, kyc_status FROM users WHERE telegram_id = $1',
      [userId]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const user = userResult.rows[0];

    // Get latest verification
    const verificationResult = await db.query(`
      SELECT
        id, status, submitted_at, reviewed_at, rejection_reason,
        first_name, last_name, document_type
      FROM custom_verifications
      WHERE user_id = $1
      ORDER BY submitted_at DESC
      LIMIT 1
    `, [user.id]);

    let verification = null;
    if (verificationResult.rows.length > 0) {
      verification = verificationResult.rows[0];
    }

    // Map custom verification status to legacy KYC status for compatibility
    let mappedKycStatus = user.kyc_status;
    if (verification) {
      switch (verification.status) {
        case 'pending':
        case 'under_review':
          mappedKycStatus = 'pending';
          break;
        case 'approved':
          mappedKycStatus = 'completed';
          break;
        case 'rejected':
          mappedKycStatus = 'declined';
          break;
      }
    }

    return NextResponse.json({
      kycStatus: mappedKycStatus,
      verification: verification,
      isCustomVerification: user.kyc_status === 'custom_verification' || verification !== null
    });

  } catch (error) {
    console.error('Status check error:', error);
    return NextResponse.json(
      { error: 'Failed to check verification status' },
      { status: 500 }
    );
  }
}
