import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      userId,
      firstName,
      lastName,
      dateOfBirth,
      documentType,
      documentNumber,
      documentFrontUrl,
      documentBackUrl,
      selfieUrl,
    } = body;

    // Validate required fields
    if (!userId || !firstName || !lastName || !dateOfBirth ||
        !documentType || !documentNumber || !documentFrontUrl || !selfieUrl) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Get user from database
    const userResult = await db.query(
      'SELECT id FROM users WHERE telegram_id = $1',
      [userId]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const user = userResult.rows[0];

    // Check if user already has a pending or approved verification
    const existingVerification = await db.query(
      'SELECT id, status FROM custom_verifications WHERE user_id = $1 ORDER BY submitted_at DESC LIMIT 1',
      [user.id]
    );

    if (existingVerification.rows.length > 0) {
      const existing = existingVerification.rows[0];
      if (existing.status === 'pending' || existing.status === 'under_review') {
        return NextResponse.json(
          { error: 'You already have a verification request under review' },
          { status: 400 }
        );
      }
      if (existing.status === 'approved') {
        return NextResponse.json(
          { error: 'Your account is already verified' },
          { status: 400 }
        );
      }
    }

    // Insert new verification
    const result = await db.query(`
      INSERT INTO custom_verifications (
        user_id, document_type, document_front_url, document_back_url,
        selfie_url, first_name, last_name, date_of_birth, document_number,
        status, submitted_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'pending', NOW())
      RETURNING id, submitted_at
    `, [
      user.id,
      documentType,
      documentFrontUrl,
      documentBackUrl,
      selfieUrl,
      firstName,
      lastName,
      dateOfBirth,
      documentNumber
    ]);

    // Update user's KYC status
    await db.query(
      'UPDATE users SET kyc_status = $1, updated_at = NOW() WHERE id = $2',
      ['custom_verification', user.id]
    );

    const verification = result.rows[0];

    return NextResponse.json({
      success: true,
      verificationId: verification.id,
      submittedAt: verification.submitted_at,
      message: 'Verification submitted successfully'
    });

  } catch (error) {
    console.error('Verification submission error:', error);
    return NextResponse.json(
      { error: 'Failed to submit verification. Please try again.' },
      { status: 500 }
    );
  }
}
