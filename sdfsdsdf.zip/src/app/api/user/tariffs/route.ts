import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const res = await db.query(
      `SELECT id, code, name_ru, name_en, min_amount, max_amount, term_days, daily_percent, is_active,
              tariff_type, monthly_percent, total_return_percent, is_perpetual, auto_return_principal
       FROM tariff_plans WHERE is_active = true ORDER BY id`
    );

    const tariffs = res.rows.map((r: Record<string, unknown>) => ({
      id: Number(r.id),
      code: String(r.code),
      name_ru: String(r.name_ru),
      name_en: String(r.name_en),
      minAmount: Number(r.min_amount),
      maxAmount: Number(r.max_amount),
      termDays: Number(r.term_days),
      // Для бессрочных тарифов пересчитываем daily_percent из monthly_percent
      dailyPercentFraction: r.is_perpetual && r.monthly_percent ?
        Number(r.monthly_percent) / 30 / 100 : // monthly_percent в %, нужно в доли
        Number(r.daily_percent),
      dailyPercent: r.is_perpetual && r.monthly_percent ?
        Number(r.monthly_percent) / 30 : // monthly_percent уже в %, делим на 30 дней
        Number(r.daily_percent) * 100,
      isActive: Boolean(r.is_active),
      // Новые поля
      tariffType: String(r.tariff_type || 'perpetual'),
      monthlyPercent: r.monthly_percent ? Number(r.monthly_percent) : null,
      totalReturnPercent: r.total_return_percent ? Number(r.total_return_percent) : null,
      isPerpetual: Boolean(r.is_perpetual),
      autoReturnPrincipal: Boolean(r.auto_return_principal),
    }));

    return NextResponse.json({ success: true, data: tariffs });
  } catch (e) {
    console.error('Tariffs fetch error:', e);
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 });
  }
}
