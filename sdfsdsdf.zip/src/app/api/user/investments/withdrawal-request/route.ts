import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { PoolClient } from 'pg';

export async function POST(request: NextRequest) {
  const debugInfo: string[] = [];

  try {
    debugInfo.push('WITHDRAWAL_REQUEST: 1. Parsing request body');
    const body = await request.json().catch(() => null) as { user_id?: string; investment_id?: number; reason?: string } | null;
    const { user_id, investment_id, reason = '' } = body || {};

    debugInfo.push(`WITHDRAWAL_REQUEST: 2. Received: user_id=${user_id}, investment_id=${investment_id}`);

    if (!user_id || !investment_id) {
      debugInfo.push('WITHDRAWAL_REQUEST: 3. ERROR: Missing required fields');
      return NextResponse.json({
        success: false,
        error: 'user_id and investment_id are required',
        debug: debugInfo
      }, { status: 400 });
    }

    debugInfo.push('WITHDRAWAL_REQUEST: 4. Starting database transaction');
    const result = await db.transaction(async (client: PoolClient) => {
      // Проверяем пользователя
      debugInfo.push('WITHDRAWAL_REQUEST: 5. Looking up user');
      const userRes = await client.query('SELECT id FROM users WHERE telegram_id = $1', [user_id]);

      if (userRes.rows.length === 0) {
        debugInfo.push('WITHDRAWAL_REQUEST: 6. ERROR: User not found');
        return { error: 'User not found', debug: debugInfo } as const;
      }

      const uid = Number(userRes.rows[0].id);
      debugInfo.push(`WITHDRAWAL_REQUEST: 7. User internal ID: ${uid}`);

      // Проверяем инвестицию
      debugInfo.push('WITHDRAWAL_REQUEST: 8. Looking up investment');
      const invRes = await client.query(`
        SELECT i.id, i.user_id, i.amount, i.status, i.principal_returned, i.withdrawal_request_id,
               t.tariff_type, t.is_perpetual
        FROM investments i
        JOIN tariff_plans t ON t.id = i.tariff_id
        WHERE i.id = $1 AND i.user_id = $2
      `, [investment_id, uid]);

      if (invRes.rows.length === 0) {
        debugInfo.push('WITHDRAWAL_REQUEST: 9. ERROR: Investment not found');
        return { error: 'Investment not found or not owned by user', debug: debugInfo } as const;
      }

      const investment = invRes.rows[0] as Record<string, unknown>;
      debugInfo.push(`WITHDRAWAL_REQUEST: 10. Investment found: amount=${investment.amount}, status=${investment.status}`);

      // Проверяем, что инвестиция активна
      if (investment.status !== 'active') {
        debugInfo.push(`WITHDRAWAL_REQUEST: 11. ERROR: Investment not active (status: ${investment.status})`);
        return { error: 'Investment is not active', debug: debugInfo } as const;
      }

      // Проверяем, что это бессрочный тариф или тариф с возможностью досрочного возврата
      if (!investment.is_perpetual && investment.tariff_type !== 'perpetual') {
        debugInfo.push('WITHDRAWAL_REQUEST: 12. ERROR: Withdrawal not allowed for this tariff type');
        return { error: 'Principal withdrawal not allowed for this tariff type', debug: debugInfo } as const;
      }

      // Проверяем, что тело еще не возвращено
      if (investment.principal_returned) {
        debugInfo.push('WITHDRAWAL_REQUEST: 13. ERROR: Principal already returned');
        return { error: 'Principal has already been returned', debug: debugInfo } as const;
      }

      // Проверяем, что нет активного запроса на возврат
      if (investment.withdrawal_request_id) {
        debugInfo.push('WITHDRAWAL_REQUEST: 14. ERROR: Withdrawal request already exists');
        return { error: 'Withdrawal request already pending', debug: debugInfo } as const;
      }

      // Создаем запрос на возврат
      debugInfo.push('WITHDRAWAL_REQUEST: 15. Creating withdrawal request');
      const reqRes = await client.query(`
        INSERT INTO withdrawal_requests (user_id, investment_id, amount, status, reason, requested_at)
        VALUES ($1, $2, $3, 'pending', $4, NOW())
        RETURNING id
      `, [uid, investment_id, investment.amount, reason]);

      const requestId = Number(reqRes.rows[0].id);
      debugInfo.push(`WITHDRAWAL_REQUEST: 16. Created withdrawal request ID: ${requestId}`);

      // Обновляем инвестицию
      debugInfo.push('WITHDRAWAL_REQUEST: 17. Updating investment with withdrawal request ID');
      await client.query(`
        UPDATE investments
        SET withdrawal_request_id = $1, status = 'withdrawal_requested', updated_at = NOW()
        WHERE id = $2
      `, [requestId, investment_id]);

      debugInfo.push('WITHDRAWAL_REQUEST: 18. Transaction completed successfully');
      return {
        withdrawal_request_id: requestId,
        message: 'Withdrawal request created successfully. Admin will review it.',
        debug: debugInfo
      } as const;
    });

    if ((result as Record<string, unknown>).error) {
      const errorMsg = (result as Record<string, unknown>).error as string;
      const resultDebug = (result as Record<string, unknown>).debug as string[] || debugInfo;

      return NextResponse.json({
        success: false,
        error: errorMsg,
        debug: resultDebug
      }, { status: 400 });
    }

    return NextResponse.json({
      success: true,
      data: result,
      debug: debugInfo
    });
  } catch (e) {
    debugInfo.push(`WITHDRAWAL_REQUEST: ERROR: ${e instanceof Error ? e.message : String(e)}`);
    console.error('Withdrawal request error:', e);

    return NextResponse.json({
      success: false,
      error: 'Internal server error',
      debug: debugInfo,
      errorDetails: e instanceof Error ? e.message : String(e)
    }, { status: 500 });
  }
}
