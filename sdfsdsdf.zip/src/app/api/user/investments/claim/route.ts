import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { PoolClient } from 'pg';

function toISODate(d: Date): string { return d.toISOString().slice(0,10); }
function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return toISODate(d);
}

export async function POST(request: NextRequest) {
  const debugInfo: string[] = [];
  const body = await request.json().catch(() => null) as { user_id?: string; investment_id?: number } | null;

  try {
    debugInfo.push('CLAIM: 1. Parsing request body');
    const { user_id, investment_id } = body || {};
    debugInfo.push(`CLAIM: 2. Received: user_id=${user_id}, investment_id=${investment_id}`);

    if (!user_id || !investment_id) {
      debugInfo.push('CLAIM: 3. ERROR: Missing required fields');
      return NextResponse.json({
        success: false,
        error: 'user_id and investment_id are required',
        debug: debugInfo
      }, { status: 400 });
    }

    debugInfo.push('CLAIM: 4. Starting database transaction');
    const result = await db.transaction(async (client: PoolClient) => {
      debugInfo.push('CLAIM: 5. Looking up user in database');
      const uRes = await client.query('SELECT id FROM users WHERE telegram_id = $1', [user_id]);
      debugInfo.push(`CLAIM: 6. User lookup result: ${uRes.rows.length} rows`);

      if (uRes.rows.length === 0) {
        debugInfo.push('CLAIM: 7. ERROR: User not found');
        return { error: 'User not found', debug: debugInfo } as const;
      }
      const uid = Number(uRes.rows[0].id);
      debugInfo.push(`CLAIM: 8. User internal ID: ${uid}`);

      debugInfo.push('CLAIM: 9. Looking up investment');
      const invRes = await client.query(
        `SELECT id, user_id, amount, daily_percent, term_days, start_date, end_date, status, created_at
         FROM investments WHERE id = $1 AND user_id = $2`,
        [investment_id, uid]
      );
      debugInfo.push(`CLAIM: 10. Investment lookup result: ${invRes.rows.length} rows`);

      if (invRes.rows.length === 0) {
        debugInfo.push('CLAIM: 11. ERROR: Investment not found');
        return { error: 'Investment not found', debug: debugInfo } as const;
      }

      const inv = invRes.rows[0] as Record<string, unknown>;
      const amount = Number(inv.amount);
      const dailyPercent = Number(inv.daily_percent); // fraction
      const startDate = String(inv.start_date as string);
      const endDate = String(inv.end_date as string);
      const status = String(inv.status as string);
      const createdAt = String(inv.created_at as string);

      debugInfo.push(`CLAIM: 12. Investment details: amount=${amount}, dailyPercent=${dailyPercent}, status=${status}`);
      debugInfo.push(`CLAIM: 13. Raw dates: start="${startDate}", end="${endDate}", created="${createdAt}"`);

      if (status !== 'active') {
        debugInfo.push(`CLAIM: 14. ERROR: Investment is not active (status: ${status})`);
        return { error: 'Investment is not active', debug: debugInfo } as const;
      }

      // Determine last accrued timestamp
      debugInfo.push('CLAIM: 15. Checking for previous accruals');
      const lastAccRes = await client.query(
        `SELECT MAX(created_at) as last_accrual_time FROM accruals WHERE investment_id = $1`,
        [investment_id]
      );
      debugInfo.push(`CLAIM: 16. Previous accruals found: ${lastAccRes.rows.length}`);

      const now = new Date();
      const createdTime = new Date(createdAt);
      debugInfo.push(`CLAIM: 17. Now: ${now.toISOString()}, Created: ${createdTime.toISOString()}`);

      // Calculate 24-hour periods
      let lastAccrualTime: Date;
      let availablePeriods: number;
      try {
        if (lastAccRes.rows.length > 0 && lastAccRes.rows[0].last_accrual_time) {
          lastAccrualTime = new Date(String(lastAccRes.rows[0].last_accrual_time));
          debugInfo.push(`CLAIM: 18. Last accrual time: "${lastAccrualTime.toISOString()}"`);
        } else {
          debugInfo.push('CLAIM: 18. No previous accruals, using creation time');
          lastAccrualTime = createdTime;
        }

        // Calculate how many full 24-hour periods are available to claim
        const hoursSinceLastAccrual = (now.getTime() - lastAccrualTime.getTime()) / (1000 * 60 * 60);
        availablePeriods = Math.floor(hoursSinceLastAccrual / 24);

        debugInfo.push(`CLAIM: 19. Hours since last accrual: ${hoursSinceLastAccrual}, Available periods: ${availablePeriods}`);
      } catch (dateError) {
        debugInfo.push(`CLAIM: 19. ERROR: Date processing failed - ${dateError}`);
        return { error: `Date processing error: ${dateError}`, debug: debugInfo } as const;
      }

      const limitPeriods = 365; // safety cap
      const createdAccrualIds: number[] = [];
      let claimable = 0;

      // Check if investment period has ended
      const endDateParsed = new Date(endDate);
      if (isNaN(endDateParsed.getTime())) {
        debugInfo.push(`CLAIM: 20. ERROR: Invalid end date: ${endDate}`);
        return { error: `Invalid end date: ${endDate}`, debug: debugInfo } as const;
      }

      // Don't allow accruals beyond investment end date
      const maxTime = Math.min(now.getTime(), endDateParsed.getTime());
      const maxHoursSinceCreation = (maxTime - createdTime.getTime()) / (1000 * 60 * 60);
      const maxAvailablePeriods = Math.floor(maxHoursSinceCreation / 24);

      const periodsToProcess = Math.min(availablePeriods, maxAvailablePeriods, limitPeriods);
      debugInfo.push(`CLAIM: 20. Periods to process: ${periodsToProcess} (max: ${maxAvailablePeriods}, available: ${availablePeriods})`);

      debugInfo.push('CLAIM: 21. Starting accrual creation for periods');
      for (let periodIndex = 0; periodIndex < periodsToProcess; periodIndex++) {
        const profit = amount * dailyPercent;
        const accrualTime = new Date(lastAccrualTime.getTime() + ((periodIndex + 1) * 24 * 60 * 60 * 1000));
        const accrualDate = toISODate(accrualTime);

        debugInfo.push(`CLAIM: 21.${periodIndex}: Processing period ${periodIndex + 1}, accrual_date: ${accrualDate}, profit: ${profit}`);

        const accIns = await client.query(
          `INSERT INTO accruals(investment_id, user_id, accrual_date, base_amount, percent, profit_amount, created_at)
           VALUES ($1,$2,$3,$4,$5,$6,$7)
           ON CONFLICT (investment_id, accrual_date) DO NOTHING
           RETURNING id`,
          [investment_id, uid, accrualDate, amount, dailyPercent, profit, accrualTime.toISOString()]
        );

        if (accIns.rows.length) {
          const accrualId = Number((accIns.rows[0] as Record<string, unknown>).id);
          createdAccrualIds.push(accrualId);
          claimable += profit;
          debugInfo.push(`CLAIM: 21.${periodIndex}: Created accrual ID ${accrualId}, running total: ${claimable}`);
        } else {
          debugInfo.push(`CLAIM: 21.${periodIndex}: Accrual already exists for date ${accrualDate}`);
        }
      }

      debugInfo.push(`CLAIM: 22. Accrual loop completed: ${createdAccrualIds.length} new accruals, total claimable: ${claimable}`);

      // Credit available with total claimable
      if (claimable > 0) {
        debugInfo.push(`CLAIM: 23. Adding ${claimable} USDT to user balance`);
        await client.query(
          `INSERT INTO ledger_entries(user_id, currency, entry_type, amount, balance_available_delta, related_investment_id)
           VALUES ($1,$2,'daily_profit',$3,$3,$4)`,
          [uid, 'USDT', claimable, investment_id]
        );
        debugInfo.push('CLAIM: 24. Balance updated successfully');
      } else {
        debugInfo.push('CLAIM: 23. No claimable amount - nothing to add to balance');
      }

      let closed = false;
      if (now >= endDateParsed) {
        debugInfo.push('CLAIM: 25. Investment period ended - closing investment and returning principal');
        // Close and return principal if still active
        await client.query('UPDATE investments SET status = $1 WHERE id = $2 AND status = $3', ['completed', investment_id, 'active']);
        await client.query(
          `INSERT INTO ledger_entries(user_id, currency, entry_type, amount, balance_available_delta, balance_locked_delta, related_investment_id)
           VALUES ($1,$2,'principal_return',$3,$3,$4,$5)`,
          [uid, 'USDT', amount, -amount, investment_id]
        );
        closed = true;
        debugInfo.push(`CLAIM: 26. Investment closed, principal ${amount} USDT returned`);
      } else {
        debugInfo.push('CLAIM: 25. Investment still active - principal remains locked');
      }

      debugInfo.push(`CLAIM: 27. Transaction completed successfully`);
      return { claimed_days: createdAccrualIds.length, claimed_amount: claimable, closed, debug: debugInfo } as const;
    });

    if ((result as Record<string, unknown>).error) {
      const errorMsg = (result as Record<string, unknown>).error as string;
      const resultDebug = (result as Record<string, unknown>).debug as string[] || debugInfo;
      console.error('Investment claim error:', errorMsg);
      console.error('Debug info:', resultDebug);

      return NextResponse.json({
        success: false,
        error: errorMsg,
        debug: resultDebug
      }, { status: 400 });
    }

    console.log('Investment claim success:', result);
    return NextResponse.json({ success: true, data: result });
  } catch (e) {
    debugInfo.push(`CLAIM: ERROR: ${e instanceof Error ? e.message : String(e)}`);
    debugInfo.push(`CLAIM: Stack: ${e instanceof Error ? e.stack : 'No stack trace'}`);

    console.error('Investment claim error:', e);
    console.error('Debug info:', debugInfo);

    return NextResponse.json({
      success: false,
      error: 'Internal server error',
      debug: debugInfo,
      errorDetails: e instanceof Error ? e.message : String(e)
    }, { status: 500 });
  }
}
