import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { BalanceDBResult, InvestmentDBResult } from '@/types';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const user_id = searchParams.get('user_id');

    if (!user_id) {
      return NextResponse.json(
        { success: false, error: 'User ID is required' },
        { status: 400 }
      );
    }

    const userResult = await db.query(
      'SELECT id FROM users WHERE telegram_id = $1',
      [user_id]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'User not found' },
        { status: 404 }
      );
    }

    const userId = Number(userResult.rows[0].id);

    // balance
    const balanceResult = await db.query(
      'SELECT available, bonus, locked FROM users_balance WHERE user_id = $1 AND currency = $2',
      [userId, 'USDT']
    );

    let balance = { available: 0, bonus: 0, locked: 0 };
    if (balanceResult.rows.length > 0) {
      const row = balanceResult.rows[0] as unknown as BalanceDBResult;
      balance = {
        available: parseFloat(row.available),
        bonus: parseFloat(row.bonus),
        locked: parseFloat(row.locked)
      };
    }

    // totals invested (active)
    const investmentsResult = await db.query(
      `SELECT COALESCE(SUM(amount),0) as total_invested
       FROM investments
       WHERE user_id = $1 AND status = $2`,
      [userId, 'active']
    );
    const totalInvested = parseFloat(String((investmentsResult.rows[0] as Record<string, unknown>).total_invested ?? '0'));

    // ROI = total profit / total invested * 100
    const profitResult = await db.query(
      `SELECT COALESCE(SUM(profit_amount),0) as total_profit FROM accruals WHERE user_id = $1`,
      [userId]
    );
    const totalProfit = parseFloat(String((profitResult.rows[0] as Record<string, unknown>).total_profit ?? '0'));
    const roi = totalInvested > 0 ? (totalProfit / totalInvested) * 100 : 0;

    // Weekly growth = profit in last 7 days
    const weeklyRes = await db.query(
      `SELECT COALESCE(SUM(profit_amount),0) as week_profit
       FROM accruals
       WHERE user_id = $1 AND accrual_date >= (CURRENT_DATE - INTERVAL '7 days')`,
      [userId]
    );
    const weeklyGrowth = parseFloat(String((weeklyRes.rows[0] as Record<string, unknown>).week_profit ?? '0'));

    // Active plans count
    const activePlansRes = await db.query(
      `SELECT COUNT(*) as cnt FROM investments WHERE user_id = $1 AND status = 'active'`,
      [userId]
    );
    const activePlans = parseInt(String((activePlansRes.rows[0] as Record<string, unknown>).cnt ?? '0'), 10);

    // Referrals count
    const refsRes = await db.query(`SELECT COUNT(*) as cnt FROM users WHERE referred_by_id = $1`, [userId]);
    const referrals = parseInt(String((refsRes.rows[0] as Record<string, unknown>).cnt ?? '0'), 10);

    return NextResponse.json({
      success: true,
      data: {
        available: balance.available,
        bonus: balance.bonus,
        locked: balance.locked,
        total_invested: totalInvested,
        total_balance: balance.available + balance.bonus + totalInvested,
        roi,
        weekly_growth: weeklyGrowth,
        active_plans: activePlans,
        referrals,
      }
    });

  } catch (error: unknown) {
    console.error('Balance fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
