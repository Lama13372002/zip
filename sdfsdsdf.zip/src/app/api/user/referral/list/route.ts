import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const telegram_id = searchParams.get('telegram_id');
    if (!telegram_id) {
      return NextResponse.json({ success: false, error: 'Telegram ID is required' }, { status: 400 });
    }

    const userRes = await db.query('SELECT id FROM users WHERE telegram_id = $1', [telegram_id]);
    if (userRes.rows.length === 0) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });
    }
    const userId = userRes.rows[0].id as number;

    const refsRes = await db.query(
      `with recursive tree as (
        select id, referred_by_id, created_at, 1 as level from users where referred_by_id = $1
        union all
        select u.id, u.referred_by_id, u.created_at, t.level + 1 from users u
        join tree t on u.referred_by_id = t.id
        where t.level < 3
      )
      select t.id as user_id, t.level, t.created_at as join_date, u.telegram_id
      from tree t
      join users u on u.id = t.id
      order by t.level, t.created_at desc
      limit 100`,
      [userId]
    );

    const items = refsRes.rows.map((r) => ({
      user_id: Number(r.user_id),
      telegram_id: Number(r.telegram_id),
      level: Number(r.level),
      joinDate: r.join_date,
    }));

    return NextResponse.json({ success: true, data: items });
  } catch (e) {
    console.error('Referral list error:', e);
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 });
  }
}
