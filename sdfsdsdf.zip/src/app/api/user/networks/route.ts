import { NextRequest } from 'next/server';
import { db } from '@/lib/db';

interface NetworkRow {
  network_code: string;
  fee_fixed: string | number;
  fee_percent: string | number;
  min_amount: string | number;
  max_amount: string | number;
  is_available: boolean;
  name_ru: string;
  name_en: string;
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const serviceType = searchParams.get('type') || 'payment'; // payment или payout

    // Получаем актуальные данные о сетях из provider_services
    const query = `
      SELECT
        ps.network_code,
        ps.fee_fixed,
        ps.fee_percent,
        ps.min_amount,
        ps.max_amount,
        ps.is_available,
        n.name_ru,
        n.name_en
      FROM provider_services ps
      JOIN networks n ON ps.network_code = n.code
      WHERE ps.service_type = $1
        AND ps.is_available = true
        AND n.is_active = true
      ORDER BY
        CASE WHEN ps.network_code = 'TRON' THEN 0 ELSE 1 END,
        ps.network_code;
    `;

    const result = await db.query(query, [serviceType]);

    const networks = (result.rows as unknown as NetworkRow[]).map((row) => {
      const feeFixed = parseFloat(String(row.fee_fixed || '0'));
      const feePercent = parseFloat(String(row.fee_percent || '0'));
      const minAmount = parseFloat(String(row.min_amount || '0'));
      const maxAmount = parseFloat(String(row.max_amount || '0'));

      return {
        value: String(row.network_code),
        label: String(row.name_en || row.name_ru),
        fee_fixed: feeFixed,
        fee_percent: feePercent,
        min_amount: minAmount,
        max_amount: maxAmount,
        // Форматируем комиссию для отображения
        fee: feeFixed > 0
          ? `${feeFixed.toFixed(2)} USDT`
          : feePercent > 0
            ? `${(feePercent * 100).toFixed(1)}%`
            : '0 USDT'
      };
    });

    return Response.json({
      success: true,
      data: {
        networks,
        service_type: serviceType
      }
    });

  } catch (error) {
    console.error('Networks API error:', error);
    return Response.json({
      success: false,
      error: 'Failed to load networks',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
