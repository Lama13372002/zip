import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get('q');
    let users;
    if (q) {
      users = await db.query(
        `SELECT id, telegram_id, phone, language, kyc_status, ref_code, referred_by_id, created_at FROM users WHERE telegram_id LIKE $1 OR phone LIKE $1 ORDER BY created_at DESC LIMIT 50`,
        [`%${q}%`]
      );
    } else {
      users = await db.query(
        `SELECT id, telegram_id, phone, language, kyc_status, ref_code, referred_by_id, created_at FROM users ORDER BY created_at DESC LIMIT 50`
      );
    }
    return NextResponse.json({ users: users.rows });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch users' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const { id, phone, language, kyc_status, ref_code, referred_by_id } = await req.json();
    if (!id) {
      return NextResponse.json({ error: 'User id is required' }, { status: 400 });
    }
    const fields = [];
    const values = [];
    let idx = 1;
    if (phone !== undefined) {
      fields.push(`phone = $${idx++}`);
      values.push(phone);
    }
    if (language !== undefined) {
      fields.push(`language = $${idx++}`);
      values.push(language);
    }
    if (kyc_status !== undefined) {
      fields.push(`kyc_status = $${idx++}`);
      values.push(kyc_status);
    }
    if (ref_code !== undefined) {
      fields.push(`ref_code = $${idx++}`);
      values.push(ref_code);
    }
    if (referred_by_id !== undefined) {
      fields.push(`referred_by_id = $${idx++}`);
      values.push(referred_by_id);
    }
    if (fields.length === 0) {
      return NextResponse.json({ error: 'No fields to update' }, { status: 400 });
    }
    values.push(id);
    const query = `UPDATE users SET ${fields.join(', ')} WHERE id = $${idx} RETURNING id, telegram_id, phone, language, kyc_status, ref_code, referred_by_id, created_at`;
    const result = await db.query(query, values);
    return NextResponse.json({ user: result.rows[0] });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update user' }, { status: 500 });
  }
}
