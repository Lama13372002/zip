import { NextRequest } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const query = searchParams.get('q')?.trim();

    if (!query) {
      return Response.json({ success: false, error: 'Параметр поиска обязателен' }, { status: 400 });
    }

    let user = null;
    let balance = null;

    // Проверяем если это число (ID пользователя)
    if (/^\d+$/.test(query)) {
      const userId = parseInt(query);

      // Поиск по ID
      const userResult = await db.query(
        'SELECT id, telegram_id, username, phone, created_at FROM users WHERE id = $1',
        [userId]
      );

      if (userResult.rows.length > 0) {
        user = userResult.rows[0];
      }
    } else {
      // Поиск по username (убираем @ если есть)
      const username = query.startsWith('@') ? query.slice(1) : query;

      const userResult = await db.query(
        'SELECT id, telegram_id, username, phone, created_at FROM users WHERE username = $1',
        [username]
      );

      if (userResult.rows.length > 0) {
        user = userResult.rows[0];
      }
    }

    if (!user) {
      return Response.json({
        success: false,
        error: 'Пользователь не найден'
      }, { status: 404 });
    }

    // Получаем баланс пользователя
    const balanceResult = await db.query(
      'SELECT available, bonus, locked FROM users_balance WHERE user_id = $1 AND currency = $2',
      [user.id, 'USDT']
    );

    if (balanceResult.rows.length > 0) {
      balance = balanceResult.rows[0];
    } else {
      // Если баланса нет, создаем запись с нулевым балансом
      await db.query(
        'INSERT INTO users_balance (user_id, currency, available, bonus, locked) VALUES ($1, $2, 0, 0, 0) ON CONFLICT (user_id, currency) DO NOTHING',
        [user.id, 'USDT']
      );
      balance = { available: '0', bonus: '0', locked: '0' };
    }

    return Response.json({
      success: true,
      user: {
        ...user,
        balance
      }
    });

  } catch (error) {
    console.error('Search user error:', error);
    return Response.json({
      success: false,
      error: 'Ошибка поиска пользователя',
      details: (error as Error).message
    }, { status: 500 });
  }
}
