import { NextRequest } from 'next/server';
import { db } from '@/lib/db';

const allowedKeys = new Set([
  'referral_percentages',
  'cron_times',
  'payout_status_mapping',
  'payment_status_mapping',
]);

export async function GET() {
  try {
    const res = await db.query(`SELECT key, value FROM app_config WHERE key = ANY($1)`, [[...allowedKeys]]);
    const data: Record<string, unknown> = {};
    for (const row of res.rows as { key: string; value: unknown }[]) data[row.key] = row.value;
    return Response.json({ success: true, data });
  } catch (e) {
    return Response.json({ success: false, error: 'DB_ERROR', details: (e as Error).message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const entries = Object.entries(body).filter(([k]) => allowedKeys.has(k));
    if (entries.length === 0) return Response.json({ success: false, error: 'NO_VALID_KEYS' }, { status: 400 });

    await db.transaction(async (client) => {
      for (const [k, v] of entries) {
        await client.query(
          `INSERT INTO app_config(key, value) VALUES($1, $2::jsonb) ON CONFLICT(key) DO UPDATE SET value = EXCLUDED.value, updated_at = now()`,
          [k, JSON.stringify(v)]
        );
      }
    });

    return Response.json({ success: true });
  } catch (e) {
    return Response.json({ success: false, error: 'DB_ERROR', details: (e as Error).message }, { status: 500 });
  }
}
