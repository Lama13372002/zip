import { NextRequest } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const provider = searchParams.get('provider');
    const q = provider ? `SELECT * FROM provider_services WHERE provider = $1 ORDER BY id` : `SELECT * FROM provider_services ORDER BY id`;
    const res = await db.query(q, provider ? [provider] : undefined);
    return Response.json({ success: true, data: { items: res.rows } });
  } catch (e) {
    return Response.json({ success: false, error: 'DB_ERROR', details: (e as Error).message }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, ...updates } = body;
    if (!id) return Response.json({ success: false, error: 'BAD_REQUEST' }, { status: 400 });
    const fields = Object.keys(updates);
    const values = Object.values(updates);
    const setSql = fields.map((k, i) => `${k} = $${i + 1}`).join(', ');
    const q = `UPDATE provider_services SET ${setSql}, updated_at = now() WHERE id = $${fields.length + 1} RETURNING *`;
    const res = await db.query(q, [...values, id]);
    return Response.json({ success: true, data: res.rows[0] });
  } catch (e) {
    return Response.json({ success: false, error: 'DB_ERROR', details: (e as Error).message }, { status: 500 });
  }
}
