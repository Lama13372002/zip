import { NextRequest } from 'next/server';
import { db } from '@/lib/db';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const type = searchParams.get('type') || 'audit';
    const limit = Math.min(parseInt(searchParams.get('limit') || '50', 10), 200);

    let q = '';
    if (type === 'audit') q = `SELECT * FROM audit_log ORDER BY id DESC LIMIT $1`;
    else if (type === 'provider') q = `SELECT * FROM provider_call_logs ORDER BY id DESC LIMIT $1`;
    else if (type === 'webhooks') q = `SELECT * FROM inbound_webhooks ORDER BY id DESC LIMIT $1`;
    else return Response.json({ success: false, error: 'UNKNOWN_TYPE' }, { status: 400 });

    const res = await db.query(q, [limit]);
    return Response.json({ success: true, data: { items: res.rows } });
  } catch (e) {
    return Response.json({ success: false, error: 'DB_ERROR', details: (e as Error).message }, { status: 500 });
  }
}
