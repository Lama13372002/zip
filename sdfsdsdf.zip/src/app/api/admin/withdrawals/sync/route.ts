import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { nowPayments } from '@/lib/nowpayments';

export async function POST(request: NextRequest) {
  try {
    const { withdrawal_id, admin_id } = await request.json();

    if (!withdrawal_id || !admin_id) {
      return NextResponse.json(
        { success: false, error: 'Missing withdrawal_id or admin_id' },
        { status: 400 }
      );
    }

    // Получаем данные о выводе
    const withdrawalResult = await db.query(
      `SELECT w.*, u.telegram_id
       FROM withdrawals w
       JOIN users u ON w.user_id = u.id
       WHERE w.id = $1`,
      [withdrawal_id]
    );

    if (withdrawalResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Withdrawal not found' },
        { status: 404 }
      );
    }

    const withdrawal = withdrawalResult.rows[0];

    if (!withdrawal.provider_uuid) {
      return NextResponse.json(
        { success: false, error: 'No NOWPayments payout ID found' },
        { status: 400 }
      );
    }

    // Запрашиваем актуальный статус у NOWPayments
    const payoutStatus = await nowPayments.getPayout(String(withdrawal.provider_uuid));

    if (!payoutStatus || payoutStatus.length === 0) {
      return NextResponse.json(
        { success: false, error: 'Payout not found in NOWPayments' },
        { status: 404 }
      );
    }

    const payout = payoutStatus[0];
    console.log('=== NOWPayments Sync Response ===');
    console.log('Payout data:', JSON.stringify(payout, null, 2));
    console.log('===============================');

    const statusRaw = (payout.status || '').toUpperCase();
    const statusMap: Record<string, string> = {
      CREATING: 'processing',
      WAITING: 'processing',
      PROCESSING: 'processing',
      SENDING: 'processing',
      FINISHED: 'completed',
      FAILED: 'failed',
      DECLINED: 'failed',
    };
    const newStatus = statusMap[statusRaw] || 'processing';

    // Обновляем статус в БД
    await db.transaction(async (client) => {
      await client.query(
        `UPDATE withdrawals SET
         status = $1,
         provider_tx_id = $2,
         txid = $3,
         processed_at = CASE WHEN $4 THEN NOW() ELSE processed_at END,
         updated_at = NOW()
         WHERE id = $5`,
        [newStatus, payout.hash || null, payout.hash || null, newStatus === 'completed' || newStatus === 'failed', withdrawal_id]
      );

      if (newStatus === 'completed' && withdrawal.status !== 'completed') {
        // При успешном выводе снимаем полную сумму с заблокированных средств
        const totalAmount = parseFloat(String(withdrawal.amount)) + parseFloat(String(withdrawal.fee || 0));
        await client.query(
          `INSERT INTO ledger_entries
           (user_id, currency, entry_type, amount, balance_available_delta, balance_locked_delta, related_withdrawal_id, created_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
          [withdrawal.user_id, 'USDT', 'withdrawal_complete', totalAmount, 0, -totalAmount, withdrawal_id]
        );
      }

      if (newStatus === 'failed' && withdrawal.status !== 'failed') {
        // При неудачном выводе возвращаем полную сумму на доступный баланс
        const totalAmount = parseFloat(String(withdrawal.amount)) + parseFloat(String(withdrawal.fee || 0));
        await client.query(
          `INSERT INTO ledger_entries
           (user_id, currency, entry_type, amount, balance_available_delta, balance_locked_delta, related_withdrawal_id, created_at)
           VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
          [withdrawal.user_id, 'USDT', 'withdrawal_revert', totalAmount, totalAmount, -totalAmount, withdrawal_id]
        );
      }

      // Логируем действие админа
      await client.query(
        `INSERT INTO audit_log
         (actor_admin_id, action, target_type, target_id, metadata, created_at)
         VALUES ($1, $2, $3, $4, $5, NOW())`,
        [admin_id, 'withdrawal_synced', 'withdrawal', withdrawal_id, JSON.stringify({
          old_status: withdrawal.status,
          new_status: newStatus,
          nowpayments_data: payout
        })]
      );
    });

    return NextResponse.json({
      success: true,
      data: {
        withdrawal_id: withdrawal_id,
        old_status: withdrawal.status,
        new_status: newStatus,
        nowpayments_status: statusRaw,
        transaction_hash: payout.hash,
        amount: withdrawal.amount,
        address: withdrawal.address,
        network: withdrawal.network_code,
        message: `Status synced from NOWPayments: ${withdrawal.status} → ${newStatus}`
      }
    });

  } catch (error: unknown) {
    console.error('=== Withdrawal Sync Error ===');
    console.error('Error details:', error);
    console.error('============================');

    let errorMessage = 'Failed to sync withdrawal status';
    let errorDetails = '';

    if (error instanceof Error) {
      errorMessage = error.message;

      if (error.message.includes('NOWPayments payout status error 404')) {
        errorDetails = 'Payout не найден в NOWPayments. Возможно ID неверный или payout был удален.';
      } else if (error.message.includes('NOWPayments auth error')) {
        errorDetails = 'Ошибка авторизации с NOWPayments. Проверьте NOWPAYMENTS_EMAIL и NOWPAYMENTS_PASSWORD.';
      } else if (error.message.includes('NOWPayments payout status error')) {
        errorDetails = 'Ошибка API NOWPayments. Проверьте доступность сервиса и правильность настроек.';
      } else {
        errorDetails = `Системная ошибка: ${error.message}`;
      }
    }

    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
        details: errorDetails,
        debugInfo: {
          timestamp: new Date().toISOString(),
          environment: {
            api_key_configured: !!process.env.NOWPAYMENTS_API_KEY,
            email_configured: !!process.env.NOWPAYMENTS_EMAIL,
            password_configured: !!process.env.NOWPAYMENTS_PASSWORD
          }
        }
      },
      { status: 500 }
    );
  }
}

// GET endpoint для массовой синхронизации processing выводов
export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url);
    const limit = parseInt(url.searchParams.get('limit') || '10');

    // Получаем все processing выводы с provider_uuid
    const result = await db.query(
      `SELECT w.id, w.provider_uuid, w.status, w.amount, w.address, w.network_code, w.created_at,
              u.telegram_id
       FROM withdrawals w
       JOIN users u ON w.user_id = u.id
       WHERE w.status = 'processing'
         AND w.provider_uuid IS NOT NULL
       ORDER BY w.created_at DESC
       LIMIT $1`,
      [limit]
    );

    const syncResults = [];

    for (const withdrawal of result.rows) {
      try {
        const payoutStatus = await nowPayments.getPayout(String(withdrawal.provider_uuid));

        if (payoutStatus && payoutStatus.length > 0) {
          const payout = payoutStatus[0];
          const statusRaw = (payout.status || '').toUpperCase();
          const statusMap: Record<string, string> = {
            CREATING: 'processing',
            WAITING: 'processing',
            PROCESSING: 'processing',
            SENDING: 'processing',
            FINISHED: 'completed',
            FAILED: 'failed',
            DECLINED: 'failed',
          };
          const newStatus = statusMap[statusRaw] || 'processing';

          syncResults.push({
            withdrawal_id: withdrawal.id,
            provider_uuid: withdrawal.provider_uuid,
            old_status: withdrawal.status,
            new_status: newStatus,
            nowpayments_status: statusRaw,
            needs_update: newStatus !== withdrawal.status,
            transaction_hash: payout.hash,
            amount: withdrawal.amount,
            user: withdrawal.telegram_id
          });
        } else {
          syncResults.push({
            withdrawal_id: withdrawal.id,
            provider_uuid: withdrawal.provider_uuid,
            old_status: withdrawal.status,
            error: 'Payout not found in NOWPayments',
            needs_update: false
          });
        }
      } catch (error) {
        syncResults.push({
          withdrawal_id: withdrawal.id,
          provider_uuid: withdrawal.provider_uuid,
          old_status: withdrawal.status,
          error: error instanceof Error ? error.message : 'Unknown error',
          needs_update: false
        });
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        total_checked: syncResults.length,
        needs_update: syncResults.filter(r => r.needs_update).length,
        results: syncResults
      }
    });

  } catch (error) {
    console.error('Bulk sync error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to perform bulk sync' },
      { status: 500 }
    );
  }
}
