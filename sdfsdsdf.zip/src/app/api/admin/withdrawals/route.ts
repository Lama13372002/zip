import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { WithdrawalDBResult } from '@/types';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    const status = searchParams.get('status');
    const user_id = searchParams.get('user_id');

    let whereClause = 'WHERE 1=1';
    const queryParams: (string | number)[] = [];
    let paramIndex = 1;

    if (status) {
      whereClause += ` AND w.status = $${paramIndex}`;
      queryParams.push(status);
      paramIndex++;
    }

    if (user_id) {
      whereClause += ` AND u.telegram_id = $${paramIndex}`;
      queryParams.push(user_id);
      paramIndex++;
    }

    // Получаем выводы с информацией о пользователях
    const withdrawalsResult = await db.query(
      `SELECT
         w.*,
         (w.amount - COALESCE(w.fee, 0)) AS net_amount,
         u.telegram_id,
         u.phone,
         COALESCE(u.phone, 'User ' || u.telegram_id) as user_display
       FROM withdrawals w
       JOIN users u ON w.user_id = u.id
       ${whereClause}
       ORDER BY w.created_at DESC
       LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`,
      [...queryParams, limit, offset]
    );

    // Получаем общее количество
    const countResult = await db.query(
      `SELECT COUNT(*) as total
       FROM withdrawals w
       JOIN users u ON w.user_id = u.id
       ${whereClause}`,
      queryParams
    );

    const total = parseInt((countResult.rows[0] as { total: string }).total);

    // Форматируем выводы
    interface WithdrawalRow extends WithdrawalDBResult {
      net_amount?: string | number;
      user_display: string;
      phone?: string;
    }
    const withdrawals = (withdrawalsResult.rows as unknown as WithdrawalRow[]).map((withdrawal: WithdrawalRow) => ({
      id: withdrawal.id,
      user_id: withdrawal.user_id,
      telegram_id: withdrawal.telegram_id,
      user_display: withdrawal.user_display,
      amount: parseFloat(String(withdrawal.amount)), // gross
      net_amount: parseFloat(
        String(
          withdrawal.net_amount ??
            (parseFloat(String(withdrawal.amount)) - parseFloat(String(withdrawal.fee || '0')))
        )
      ),
      payer_amount:
        withdrawal.payer_amount != null
          ? parseFloat(String(withdrawal.payer_amount))
          : null,
      address: withdrawal.address,
      fee: parseFloat(String(withdrawal.fee)),
      currency: withdrawal.currency,
      status: withdrawal.status,
      network_code: withdrawal.network_code,
      provider: withdrawal.provider,
      provider_order_id: withdrawal.provider_order_id,
      provider_uuid: withdrawal.provider_uuid,
      provider_tx_id: withdrawal.provider_tx_id,
      txid: withdrawal.txid ?? null,
      is_subtract: withdrawal.is_subtract,
      is_final: withdrawal.is_final,
      requested_at: withdrawal.requested_at,
      processed_at: withdrawal.processed_at ?? null,
      created_at: withdrawal.created_at,
      updated_at: withdrawal.updated_at
    }));

    // Получаем статистику
    type StatsRow = {
      status: string;
      count: string;
      total_amount: string | null;
      total_fees: string | null;
      total_net: string | null;
    };

    // Получаем статистику
    const statsResult = await db.query(
      `SELECT
         w.status,
         COUNT(*) as count,
         SUM(w.amount) as total_amount,
         SUM(COALESCE(w.fee, 0)) as total_fees,
         SUM(w.amount - COALESCE(w.fee, 0)) as total_net
       FROM withdrawals w
       JOIN users u ON w.user_id = u.id
       ${whereClause}
       GROUP BY w.status`,
      queryParams
    );

    const stats = (statsResult.rows as StatsRow[]).reduce(
      (
        acc: Record<
          string,
          { count: number; total_amount: number; total_fees: number; total_net: number }
        >,
        row: StatsRow
      ) => {
        acc[row.status] = {
          count: parseInt(row.count),
          total_amount: parseFloat(String(row.total_amount ?? '0')),
          total_fees: parseFloat(String(row.total_fees ?? '0')),
          total_net: parseFloat(String(row.total_net ?? '0'))
        };
        return acc;
      },
      {}
    );

    // Получаем количество pending выводов для уведомлений
    const pendingResult = await db.query(
      'SELECT COUNT(*) as pending_count FROM withdrawals WHERE status = $1',
      ['pending']
    );

    const pendingCount = parseInt((pendingResult.rows[0] as { pending_count: string }).pending_count);

    return NextResponse.json({
      success: true,
      data: {
        withdrawals,
        pagination: {
          total,
          limit,
          offset,
          has_more: offset + limit < total
        },
        stats,
        pending_count: pendingCount
      }
    });

  } catch (error: unknown) {
    console.error('Admin withdrawals fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
