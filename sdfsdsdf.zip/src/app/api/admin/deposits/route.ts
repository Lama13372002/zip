import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { DepositDBResult, CountResult, StatsDBResult, StatsAccumulator } from '@/types';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');
    const status = searchParams.get('status');
    const user_id = searchParams.get('user_id');

    let whereClause = 'WHERE 1=1';
    const queryParams: (string | number)[] = [];
    let paramIndex = 1;

    if (status) {
      whereClause += ` AND d.status = $${paramIndex}`;
      queryParams.push(status);
      paramIndex++;
    }

    if (user_id) {
      whereClause += ` AND u.telegram_id = $${paramIndex}`;
      queryParams.push(user_id);
      paramIndex++;
    }

    // Получаем депозиты с информацией о пользователях и новыми полями
    const depositsResult = await db.query(
      `SELECT
         d.*,
         u.telegram_id,
         u.phone,
         COALESCE(u.phone, 'User ' || u.telegram_id) as user_display
       FROM deposits d
       JOIN users u ON d.user_id = u.id
       ${whereClause}
       ORDER BY d.created_at DESC
       LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`,
      [...queryParams, limit, offset]
    );

    // Получаем общее количество
    const countResult = await db.query(
      `SELECT COUNT(*) as total
       FROM deposits d
       JOIN users u ON d.user_id = u.id
       ${whereClause}`,
      queryParams
    );

    const total = parseInt((countResult.rows[0] as unknown as CountResult).total);

    // Форматируем депозиты с новыми полями
    const deposits = (depositsResult.rows as unknown as DepositDBResult[]).map((deposit: DepositDBResult) => ({
      id: deposit.id,
      user_id: deposit.user_id,
      telegram_id: deposit.telegram_id,
      user_display: deposit.user_display,
      amount: parseFloat(deposit.amount),
      desired_amount: deposit.desired_amount ? parseFloat(deposit.desired_amount) : null,
      pay_amount: deposit.pay_amount ? parseFloat(deposit.pay_amount) : null,
      platform_fee_percent: deposit.platform_fee_percent ? parseFloat(deposit.platform_fee_percent) : null,
      platform_fee_amount: deposit.platform_fee_amount ? parseFloat(deposit.platform_fee_amount) : null,
      merchant_amount: deposit.merchant_amount ? parseFloat(deposit.merchant_amount) : null,
      payer_amount: deposit.payer_amount ? parseFloat(deposit.payer_amount) : null,
      currency: deposit.currency,
      status: deposit.status,
      payment_status: deposit.payment_status,
      provider: deposit.provider,
      provider_order_id: deposit.provider_order_id,
      provider_uuid: deposit.provider_uuid,
      network_code: deposit.network_code,
      address: deposit.address,
      from_address: deposit.from_address,
      provider_tx_id: deposit.provider_tx_id,
      url: deposit.url,
      confirmed_at: deposit.confirmed_at,
      expired_at: deposit.expired_at,
      created_at: deposit.created_at,
      updated_at: deposit.updated_at
    }));

    // Получаем статистику с учетом новых полей
    const statsResult = await db.query(
      `SELECT
         d.status,
         COUNT(*) as count,
         SUM(CASE
           WHEN d.desired_amount IS NOT NULL THEN d.desired_amount
           WHEN d.merchant_amount IS NOT NULL THEN d.merchant_amount
           ELSE d.amount
         END) as total_amount,
         SUM(CASE
           WHEN d.platform_fee_amount IS NOT NULL THEN d.platform_fee_amount
           ELSE 0
         END) as total_platform_fees
       FROM deposits d
       JOIN users u ON d.user_id = u.id
       GROUP BY d.status
       ORDER BY d.status`
    );

    const stats = (statsResult.rows as unknown as (StatsDBResult & { total_platform_fees: string })[]).reduce((acc: StatsAccumulator & { [key: string]: { platform_fees?: number } }, row) => {
      acc[row.status] = {
        count: parseInt(row.count),
        total_amount: parseFloat(row.total_amount || '0'),
        platform_fees: parseFloat(row.total_platform_fees || '0')
      };
      return acc;
    }, {});

    return NextResponse.json({
      success: true,
      data: {
        deposits,
        pagination: {
          total,
          limit,
          offset,
          has_more: offset + limit < total
        },
        stats
      }
    });

  } catch (error: unknown) {
    console.error('Admin deposits fetch error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
