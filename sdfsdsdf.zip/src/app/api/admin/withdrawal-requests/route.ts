import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { PoolClient } from 'pg';

// Получение списка запросов на возврат
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status'); // pending, approved, rejected

    let whereClause = '';
    const params: unknown[] = [];

    if (status) {
      whereClause = 'WHERE wr.status = $1';
      params.push(status);
    }

    const query = `
      SELECT
        wr.id,
        wr.user_id,
        wr.investment_id,
        wr.amount,
        wr.status,
        wr.reason,
        wr.requested_at,
        wr.processed_at,
        wr.admin_notes,
        u.telegram_id,
        COALESCE(u.phone, CAST(u.telegram_id AS TEXT)) as user_display,
        i.amount as investment_amount,
        t.code as tariff_code,
        t.name_ru as tariff_name
      FROM withdrawal_requests wr
      JOIN users u ON u.id = wr.user_id
      JOIN investments i ON i.id = wr.investment_id
      JOIN tariff_plans t ON t.id = i.tariff_id
      ${whereClause}
      ORDER BY wr.requested_at DESC
    `;

    const result = await db.query(query, params);

    // Преобразуем числовые поля в числа
    const items = result.rows.map(row => ({
      ...row,
      amount: Number(row.amount),
      investment_amount: Number(row.investment_amount)
    }));

    return NextResponse.json({
      success: true,
      data: { items }
    });
  } catch (e) {
    console.error('Get withdrawal requests error:', e);
    return NextResponse.json({
      success: false,
      error: 'Database error',
      details: (e as Error).message
    }, { status: 500 });
  }
}

// Обработка запроса на возврат (одобрение или отклонение)
export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, action, admin_notes = '' } = body; // action: 'approve' | 'reject'

    if (!id || !action || !['approve', 'reject'].includes(action)) {
      return NextResponse.json({
        success: false,
        error: 'Invalid parameters. Required: id, action (approve|reject)'
      }, { status: 400 });
    }

    const result = await db.transaction(async (client: PoolClient) => {
      // Получаем информацию о запросе
      const reqRes = await client.query(`
        SELECT wr.*, i.user_id, i.amount as investment_amount
        FROM withdrawal_requests wr
        JOIN investments i ON i.id = wr.investment_id
        WHERE wr.id = $1 AND wr.status = 'pending'
      `, [id]);

      if (reqRes.rows.length === 0) {
        throw new Error('Withdrawal request not found or already processed');
      }

      const request = reqRes.rows[0] as Record<string, unknown>;
      const userId = Number(request.user_id);
      const investmentId = Number(request.investment_id);
      const amount = Number(request.investment_amount);

      if (action === 'approve') {
        // Одобряем запрос - возвращаем тело из locked в available
        await client.query(`
          INSERT INTO ledger_entries(
            user_id, currency, entry_type, amount,
            balance_available_delta, balance_locked_delta,
            related_investment_id
          )
          VALUES ($1, 'USDT', 'principal_return', $2, $2, $3, $4)
        `, [userId, amount, -amount, investmentId]);

        // Обновляем инвестицию
        await client.query(`
          UPDATE investments
          SET status = 'completed', principal_returned = true, updated_at = NOW()
          WHERE id = $1
        `, [investmentId]);

        // Обновляем запрос
        await client.query(`
          UPDATE withdrawal_requests
          SET status = 'approved', processed_at = NOW(), admin_notes = $1
          WHERE id = $2
        `, [admin_notes, id]);

        return {
          message: `Withdrawal request approved. ${amount} USDT returned to user balance.`,
          action: 'approved',
          amount
        };
      } else {
        // Отклоняем запрос
        await client.query(`
          UPDATE withdrawal_requests
          SET status = 'rejected', processed_at = NOW(), admin_notes = $1
          WHERE id = $2
        `, [admin_notes, id]);

        // Возвращаем инвестицию в активное состояние
        await client.query(`
          UPDATE investments
          SET status = 'active', withdrawal_request_id = NULL, updated_at = NOW()
          WHERE id = $1
        `, [investmentId]);

        return {
          message: 'Withdrawal request rejected. Investment returned to active status.',
          action: 'rejected'
        };
      }
    });

    return NextResponse.json({
      success: true,
      data: result
    });
  } catch (e) {
    console.error('Process withdrawal request error:', e);
    return NextResponse.json({
      success: false,
      error: 'Processing error',
      details: (e as Error).message
    }, { status: 500 });
  }
}

// Получение статистики по запросам
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action } = body;

    if (action === 'stats') {
      const statsQuery = `
        SELECT
          status,
          COUNT(*) as count,
          SUM(amount) as total_amount
        FROM withdrawal_requests
        GROUP BY status
      `;

      const result = await db.query(statsQuery);

      const stats = result.rows.reduce((acc: Record<string, unknown>, row: Record<string, unknown>) => {
        acc[String(row.status)] = {
          count: Number(row.count),
          total_amount: Number(row.total_amount)
        };
        return acc;
      }, {});

      return NextResponse.json({
        success: true,
        data: { stats }
      });
    }

    return NextResponse.json({
      success: false,
      error: 'Invalid action'
    }, { status: 400 });
  } catch (e) {
    console.error('Withdrawal requests stats error:', e);
    return NextResponse.json({
      success: false,
      error: 'Database error',
      details: (e as Error).message
    }, { status: 500 });
  }
}
