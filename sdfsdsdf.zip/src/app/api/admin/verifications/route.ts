import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  console.log('🚀 API call started:', request.url);
  try {
    // Check DATABASE_URL
    console.log('🔌 DATABASE_URL configured:', !!process.env.DATABASE_URL);
    console.log('🔌 DATABASE_URL starts with:', process.env.DATABASE_URL?.substring(0, 20) + '...');

    // Test database connection first
    console.log('🔌 Testing database connection...');
    await db.query('SELECT 1');
    console.log('✅ Database connection successful');

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || 'all';
    const page = Math.max(1, parseInt(searchParams.get('page') || '1'));
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get('limit') || '10')));
    const offset = (page - 1) * limit;

    console.log('📊 Query parameters:', { status, page, limit, offset });

    // Build WHERE clause
    let whereClause = '';
    const params: (string | number)[] = [];

    if (status !== 'all') {
      whereClause = 'WHERE cv.status = $1';
      params.push(status);
    }

    // Add limit and offset parameters
    const limitParam = params.length + 1;
    const offsetParam = params.length + 2;
    params.push(limit, offset);

    // Get verifications with user info
    const verificationsQuery = `
      SELECT
        cv.id,
        cv.status,
        cv.first_name,
        cv.last_name,
        cv.date_of_birth,
        cv.document_type,
        cv.document_number,
        cv.document_front_url,
        cv.document_back_url,
        cv.selfie_url,
        cv.submitted_at,
        cv.reviewed_at,
        cv.rejection_reason,
        cv.admin_notes,
        u.telegram_id,
        u.username,
        u.phone,
        admin.email as reviewed_by_username
      FROM custom_verifications cv
      JOIN users u ON cv.user_id = u.id
      LEFT JOIN admin_users admin ON cv.reviewed_by = admin.id
      ${whereClause}
      ORDER BY cv.submitted_at DESC
      LIMIT $${limitParam} OFFSET $${offsetParam}
    `;

    console.log('🔍 Executing verifications query with params:', params);
    const verifications = await db.query(verificationsQuery, params);
    console.log('✅ Verifications query completed, rows:', verifications.rows.length);

    // Get total count
    const countQuery = `
      SELECT COUNT(*) as total
      FROM custom_verifications cv
      ${whereClause}
    `;

    const countParams = status !== 'all' ? [status] : [];
    console.log('🔍 Executing count query with params:', countParams);
    const countResult = await db.query(countQuery, countParams);
    console.log('✅ Count query completed, result:', countResult.rows[0]);
    const total = parseInt(String(countResult.rows[0].total));

    // Get status counts
    console.log('🔍 Executing status counts query');
    const statusCounts = await db.query(`
      SELECT
        status,
        COUNT(*) as count
      FROM custom_verifications
      GROUP BY status
    `);
    console.log('✅ Status counts query completed, rows:', statusCounts.rows.length);

    const counts = statusCounts.rows.reduce((acc, row) => {
      acc[String(row.status)] = parseInt(String(row.count));
      return acc;
    }, {} as Record<string, number>);

    return NextResponse.json({
      verifications: verifications.rows,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit)
      },
      statusCounts: counts
    });

  } catch (error) {
    console.error('❌ Get verifications error:', error);
    console.error('❌ Error message:', error instanceof Error ? error.message : String(error));
    console.error('❌ Error stack:', error instanceof Error ? error.stack : 'No stack trace');
    return NextResponse.json(
      { error: 'Failed to fetch verifications', details: error instanceof Error ? error.message : String(error) },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  console.log('🚀 PATCH API call started:', request.url);
  try {
    const body = await request.json();
    console.log('📋 Request body:', body);
    const { verificationId, action, notes } = body;

    if (!verificationId || !action) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    if (!['approve', 'reject'].includes(action)) {
      return NextResponse.json(
        { error: 'Invalid action' },
        { status: 400 }
      );
    }

    // Get verification details
    const verificationResult = await db.query(
      'SELECT user_id, status FROM custom_verifications WHERE id = $1',
      [verificationId]
    );

    if (verificationResult.rows.length === 0) {
      return NextResponse.json(
        { error: 'Verification not found' },
        { status: 404 }
      );
    }

    const verification = verificationResult.rows[0];

    if (verification.status !== 'pending' && verification.status !== 'under_review') {
      return NextResponse.json(
        { error: 'Verification already processed' },
        { status: 400 }
      );
    }

    const newStatus = action === 'approve' ? 'approved' : 'rejected';
    const newKycStatus = action === 'approve' ? 'completed' : 'declined';

    // Update verification
    await db.query(`
      UPDATE custom_verifications
      SET
        status = $1,
        reviewed_at = NOW(),
        admin_notes = $2,
        rejection_reason = $3,
        updated_at = NOW()
      WHERE id = $4
    `, [
      newStatus,
      notes || null,
      action === 'reject' ? notes : null,
      verificationId
    ]);

    // Update user's KYC status
    await db.query(
      'UPDATE users SET kyc_status = $1, updated_at = NOW() WHERE id = $2',
      [newKycStatus, verification.user_id]
    );

    return NextResponse.json({
      success: true,
      status: newStatus,
      message: `Verification ${action}d successfully`
    });

  } catch (error) {
    console.error('❌ Update verification error:', error);
    console.error('❌ Error message:', error instanceof Error ? error.message : String(error));
    console.error('❌ Error stack:', error instanceof Error ? error.stack : 'No stack trace');
    return NextResponse.json(
      { error: 'Failed to update verification', details: error instanceof Error ? error.message : String(error) },
      { status: 500 }
    );
  }
}
