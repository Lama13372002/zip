import { NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { PoolClient } from 'pg';

function today(): string { return new Date().toISOString().slice(0,10); }

export async function POST() {
  try {
    const res = await db.transaction(async (client: PoolClient) => {
      const todayStr = today();
      const invRes = await client.query(
        `SELECT id, user_id, amount, daily_percent, end_date
         FROM investments
         WHERE status = 'active'`
      );
      let accrualsCreated = 0;
      let completed = 0;
      for (const r of invRes.rows as Array<Record<string, unknown>>) {
        const investmentId = Number(r.id);
        const userId = Number(r.user_id);
        const amount = Number(r.amount);
        const dailyPercent = Number(r.daily_percent);
        if (new Date(todayStr) >= new Date(String(r.end_date))) {
          await client.query('UPDATE investments SET status = $1 WHERE id = $2 AND status = $3', ['completed', investmentId, 'active']);
          await client.query(
            `INSERT INTO ledger_entries(user_id, currency, entry_type, amount, balance_available_delta, balance_locked_delta, related_investment_id)
             VALUES ($1,$2,'principal_return',$3,$3,$4,$5)`,
            [userId, 'USDT', amount, -amount, investmentId]
          );
          completed++;
          continue;
        }
        const accExists = await client.query(
          'SELECT 1 FROM accruals WHERE investment_id = $1 AND accrual_date = $2',
          [investmentId, todayStr]
        );
        if (accExists.rows.length) continue;
        const profit = amount * dailyPercent;
        const accRes = await client.query(
          `INSERT INTO accruals(investment_id, user_id, accrual_date, base_amount, percent, profit_amount)
           VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
          [investmentId, userId, todayStr, amount, dailyPercent, profit]
        );
        const accrualId = Number(accRes.rows[0].id);
        await client.query(
          `INSERT INTO ledger_entries(user_id, currency, entry_type, amount, balance_available_delta, related_investment_id, related_accrual_id)
           VALUES ($1,$2,'daily_profit',$3,$3,$4,$5)`,
          [userId, 'USDT', profit, investmentId, accrualId]
        );
        const refPercRow = await client.query("SELECT value->>'L1' as l1, value->>'L2' as l2, value->>'L3' as l3 FROM app_config WHERE key = 'referral_percentages'");
        const l1 = Number(refPercRow.rows?.[0]?.l1 || 0);
        const l2 = Number(refPercRow.rows?.[0]?.l2 || 0);
        const l3 = Number(refPercRow.rows?.[0]?.l3 || 0);
        const upline = await client.query(
          `WITH RECURSIVE chain AS (
             SELECT id, referred_by_id, 1 AS lvl FROM users WHERE id = $1
             UNION ALL
             SELECT u.id, u.referred_by_id, c.lvl + 1 FROM users u JOIN chain c ON u.id = c.referred_by_id WHERE c.lvl < 4
           ) SELECT id, referred_by_id, lvl FROM chain`,
          [userId]
        );
        const levelMap: Array<{to_user_id:number, level:number, percent:number}> = [];
        const rows = upline.rows as Array<Record<string, unknown>>;
        const selfIdx = rows.findIndex(r => Number(r.id) === userId);
        if (selfIdx !== -1) {
          const baseLvl = Number(rows[selfIdx].lvl);
          const l1user = rows.find(r => Number(r.lvl) === baseLvl + 1);
          const l2user = rows.find(r => Number(r.lvl) === baseLvl + 2);
          const l3user = rows.find(r => Number(r.lvl) === baseLvl + 3);
          if (l1user && l1 > 0) levelMap.push({ to_user_id: Number(l1user.id), level: 1, percent: l1 });
          if (l2user && l2 > 0) levelMap.push({ to_user_id: Number(l2user.id), level: 2, percent: l2 });
          if (l3user && l3 > 0) levelMap.push({ to_user_id: Number(l3user.id), level: 3, percent: l3 });
        }
        for (const item of levelMap) {
          // Check if the user who should receive the commission has active investments
          const hasActiveInvestment = await client.query(
            'SELECT 1 FROM investments WHERE user_id = $1 AND status = $2 LIMIT 1',
            [item.to_user_id, 'active']
          );

          // Only give commission if the user has an active investment
          if (hasActiveInvestment.rows.length === 0) {
            continue; // Skip this user - no active investment
          }

          const reward = profit * item.percent;
          const rr = await client.query(
            `INSERT INTO referral_rewards(from_user_id, to_user_id, level, accrual_id, investment_id, percent, amount)
             VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
            [userId, item.to_user_id, item.level, accrualId, investmentId, item.percent, reward]
          );
          const rrId = Number(rr.rows[0].id);
          await client.query(
            `INSERT INTO ledger_entries(user_id, currency, entry_type, amount, balance_bonus_delta, related_referral_reward_id, related_accrual_id, related_investment_id)
             VALUES ($1,$2,'referral_bonus',$3,$3,$4,$5,$6)`,
            [item.to_user_id, 'USDT', reward, rrId, accrualId, investmentId]
          );
        }
        accrualsCreated++;
      }
      return { accrualsCreated, completed };
    });
    return NextResponse.json({ success: true, data: res });
  } catch (e) {
    console.error('Accruals run error:', e);
    return NextResponse.json({ success: false, error: 'Internal server error' }, { status: 500 });
  }
}
