import { NextRequest } from 'next/server';
import { db } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const { user_id, amount, reason, is_bonus = false } = await req.json();
    if (!user_id || !amount || !reason) return Response.json({ success: false, error: 'BAD_REQUEST' }, { status: 400 });

    const amt = Number(amount);
    const entryType = amt >= 0 ? 'admin_adjustment_plus' : 'admin_adjustment_minus';
    const deltaAvail = is_bonus ? 0 : amt;
    const deltaBonus = is_bonus ? amt : 0;

    const res = await db.query(
      `INSERT INTO ledger_entries(user_id, currency, entry_type, amount, balance_available_delta, balance_bonus_delta, balance_locked_delta, description) VALUES($1,'USDT',$2,$3,$4,$5,0,$6) RETURNING *`,
      [user_id, entryType, Math.abs(amt), deltaAvail, deltaBonus, reason]
    );

    await db.query(
      `INSERT INTO audit_log(actor_admin_id, action, target_type, target_id, metadata) VALUES($1,$2,$3,$4,$5::jsonb)`,
      [1, 'ledger_adjust', 'user', String(user_id), JSON.stringify({ amount: amt, is_bonus, reason })]
    );

    return Response.json({ success: true, data: res.rows[0] });
  } catch (e) {
    return Response.json({ success: false, error: 'DB_ERROR', details: (e as Error).message }, { status: 500 });
  }
}
