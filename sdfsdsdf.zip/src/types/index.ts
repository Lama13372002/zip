// User Types
export interface User {
  id: number;
  telegram_id: number;
  phone?: string;
  language: 'ru' | 'en';
  agreed_to_terms_at?: string;
  kyc_status: 'not_started' | 'pending' | 'completed' | 'declined';
  ref_code: string;
  referred_by_id?: number;
  created_at: string;
  updated_at: string;
}

export interface UserBalance {
  user_id: number;
  currency: 'USDT';
  available: number;
  bonus: number;
  locked: number;
  updated_at: string;
}

// Tariff Plans
export interface TariffPlan {
  id: number;
  code: string;
  name_ru: string;
  name_en: string;
  min_amount: number;
  max_amount: number;
  term_days: number;
  daily_percent: number;
  // Новые поля для новой логики тарифов
  tariff_type: 'perpetual' | 'fixed_term_instant' | 'fixed_term_monthly' | 'fixed_term_6months' | 'fixed_term_12months';
  monthly_percent?: number; // Процент в месяц для бессрочных и ежемесячных тарифов
  total_return_percent?: number; // Общий процент возврата для фиксированных тарифов
  is_perpetual: boolean; // Бессрочный ли тариф
  auto_return_principal: boolean; // Автоматический возврат тела в конце срока
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

// Investments
export interface Investment {
  id: number;
  user_id: number;
  tariff_id: number;
  amount: number;
  daily_percent: number;
  term_days: number;
  start_date: string;
  end_date: string;
  status: 'active' | 'completed' | 'cancelled' | 'withdrawal_requested';
  // Новые поля для отслеживания возврата тела
  principal_returned: boolean;
  withdrawal_request_id?: number;
  created_at: string;
  updated_at: string;
  tariff?: TariffPlan;
  withdrawal_request?: WithdrawalRequest;
}

// Deposits
export interface Deposit {
  id: number;
  user_id: number;
  currency: string;
  amount: number;
  desired_amount?: number;        // Желаемая сумма к получению
  pay_amount?: number;           // Сумма к оплате
  platform_fee_percent?: number; // Процент платформенной комиссии
  platform_fee_amount?: number;  // Размер платформенной комиссии
  status: string;
  provider: string;
  provider_tx_id?: string;
  address?: string;
  confirmed_at?: string;
  created_at: string;
  updated_at: string;
  provider_order_id?: string;
  provider_uuid?: string;
  network_code?: string;
  payer_currency?: string;
  payer_amount?: number;
  merchant_amount?: number;
  payment_status?: string;
  from_address?: string;
  url?: string;
  expired_at?: string;
}

// Withdrawals
export interface Withdrawal {
  id: number;
  user_id: number;
  currency: 'USDT';
  amount: number;
  address: string;
  fee: number;
  status: 'pending' | 'approved' | 'processing' | 'completed' | 'rejected' | 'failed';
  network_code: string;
  provider?: string;
  provider_tx_id?: string;
  requested_at: string;
  processed_at?: string;
  created_at: string;
  updated_at: string;
}

// Referral Types
export interface ReferralReward {
  id: number;
  from_user_id: number;
  to_user_id: number;
  level: 1 | 2 | 3;
  percent: number;
  amount: number;
  created_at: string;
}

export interface ReferralStats {
  total_referrals: number;
  level1_count: number;
  level2_count: number;
  level3_count: number;
  total_earned: number;
  commission_rate: number;
}

// API Response Types
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

// Telegram WebApp Types
export interface TelegramWebApp {
  ready: () => void;
  close: () => void;
  expand: () => void;
  MainButton: {
    text: string;
    color: string;
    textColor: string;
    isVisible: boolean;
    isActive: boolean;
    show: () => void;
    hide: () => void;
    enable: () => void;
    disable: () => void;
    onClick: (callback: () => void) => void;
    offClick: (callback: () => void) => void;
  };
  BackButton: {
    isVisible: boolean;
    show: () => void;
    hide: () => void;
    onClick: (callback: () => void) => void;
    offClick: (callback: () => void) => void;
  };
  initData: string;
  initDataUnsafe: {
    user?: {
      id: number;
      first_name: string;
      last_name?: string;
      username?: string;
      language_code?: string;
    };
    start_param?: string;
  };
  version: string;
  platform: string;
  colorScheme: 'light' | 'dark';
  themeParams: {
    bg_color: string;
    text_color: string;
    hint_color: string;
    link_color: string;
    button_color: string;
    button_text_color: string;
  };
}

// Dashboard Data
export interface DashboardData {
  user: User;
  balance: UserBalance;
  activeInvestments: Investment[];
  totalProfit: number;
  dailyProfit: number;
  referralStats: ReferralStats;
}

// Form Types
export interface DepositForm {
  amount: number;
  currency: 'USDT';
  network: string;
}

export interface WithdrawForm {
  amount: number;
  address: string;
  network: string;
}

export interface InvestmentForm {
  tariff_id: number;
  amount: number;
}

// Navigation Types
export interface NavItem {
  key: string;
  label: string;
  icon: string;
  href: string;
}

// Database Result Types
export interface WithdrawalDBResult {
  id: number;
  user_id: number;
  telegram_id: string;
  user_display: string;
  amount: string; // numeric(38,18) returns as string
  address: string;
  fee: string; // numeric(38,18) returns as string
  currency: string;
  status: string;
  network_code: string;
  provider?: string;
  provider_tx_id?: string;
  provider_order_id?: string;
  provider_uuid?: string;
  payer_currency?: string;
  payer_amount?: string; // numeric(38,18) returns as string
  is_subtract?: boolean;
  is_final?: boolean;
  txid?: string;
  requested_at: string;
  processed_at?: string;
  created_at: string;
  updated_at: string;
}

export interface WithdrawalStatsDBResult {
  status: string;
  count: string;
  total_amount: string;
  total_fees?: string;
}

export interface WithdrawalStatsAccumulator {
  [key: string]: {
    count: number;
    total_amount: number;
    total_fees: number;
  };
}

export interface TransactionDBResult {
  id: number;
  user_id: number;
  currency: string;
  type: string;
  amount: string;
  balance_before: string;
  balance_after: string;
  balance_change: string;
  reference_id?: string;
  reference_type?: string;
  fee?: string;
  description?: string;
  date: string;
  created_at: string;
}

export interface BalanceDBResult {
  available: string;
  bonus: string;
  locked: string;
}

export interface DepositDBResult {
  id: number;
  user_id: number;
  telegram_id: number;
  user_display: string;
  currency: string;
  amount: string;
  desired_amount?: string;        // Желаемая сумма к получению
  pay_amount?: string;           // Сумма к оплате
  platform_fee_percent?: string; // Процент платформенной комиссии
  platform_fee_amount?: string;  // Размер платформенной комиссии
  status: string;
  payment_status?: string;
  provider: string;
  provider_order_id?: string;
  provider_uuid?: string;
  network_code?: string;
  address?: string;
  from_address?: string;
  provider_tx_id?: string;
  payer_currency?: string;
  payer_amount?: string;
  merchant_amount?: string;
  url?: string;
  confirmed_at?: string;
  expired_at?: string;
  created_at: string;
  updated_at: string;
}

export interface CountResult {
  total: string;
  pending_count?: string;
}

export interface InvestmentDBResult {
  amount: string; // numeric(38,18) returns as string
}

export interface StatsDBResult {
  status: string;
  count: string;
  total_amount: string;
}

export interface StatsAccumulator {
  [key: string]: {
    count: number;
    total_amount: number;
  };
}

// Sumsub API Types
export interface SumsubWebSdkLinkResponse {
  url: string;
}

export interface SumsubAccessTokenResponse {
  token: string;
  userId: string;
}

export interface SumsubWebhookEvent {
  type: string;
  reviewResult?: {
    reviewAnswer: string;
    rejectType?: string;
  };
  applicantId: string;
  inspectionId: string;
  applicantType: string;
  correlationId: string;
  levelName: string;
  sandboxMode?: boolean;
  videoIdentReviewStatus?: string;
}

// Database query result types
export interface UserQueryResult {
  id: number;
  telegram_id: number;
  kyc_status: 'not_started' | 'pending' | 'completed' | 'declined';
  [key: string]: unknown;
}

// Admin types
export interface ConfigData {
  referral_percentages?: Record<string, number>;
  cron_times?: Record<string, string>;
  payout_status_mapping?: Record<string, string>;
  payment_status_mapping?: Record<string, string>;
}

export interface LogItem {
  id: number;
  type: string;
  level?: string;
  message?: string;
  data?: Record<string, unknown>;
  created_at: string;
  [key: string]: unknown;
}

export interface ProviderSetting {
  provider: string;
  key: string;
  value: unknown;
  updated_at: string;
}

export interface ProviderService {
  id: number;
  provider: string;
  service_type: string;
  currency: string;
  network_code: string;
  min_amount: number;
  max_amount: number;
  fee_fixed: number;
  fee_percent: number;
  is_available: boolean;
}

export interface UserListItem {
  id: number;
  telegram_id: number;
  phone?: string;
  language: string;
  kyc_status: string;
  ref_code: string;
  referred_by_id?: number;
  created_at: string;
}

export interface TariffFormData {
  code: string;
  name_ru: string;
  name_en: string;
  min_amount: number;
  max_amount: number;
  term_days: number;
  daily_percent: number;
  // Новые поля для формы тарифов
  tariff_type: 'perpetual' | 'fixed_term_instant' | 'fixed_term_monthly' | 'fixed_term_6months' | 'fixed_term_12months';
  monthly_percent?: number;
  total_return_percent?: number;
  is_perpetual: boolean;
  auto_return_principal: boolean;
  is_active: boolean;
}

// Запросы на возврат тела инвестиций
export interface WithdrawalRequest {
  id: number;
  user_id: number;
  investment_id: number;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  reason?: string;
  requested_at: string;
  processed_at?: string;
  processed_by_admin_id?: number;
  admin_notes?: string;
  created_at: string;
  updated_at: string;
  // Связанные данные
  user?: User;
  investment?: Investment;
}

export interface WithdrawalRequestForm {
  investment_id: number;
  reason?: string;
}

export interface NetworkInfo {
  value: string;
  label: string;
  fee_fixed: number;
  fee_percent: number;
  min_amount: number;
  max_amount: number;
  fee: string;
}

// Process Deposits Result Types
export interface ProcessDepositsSuccess {
  processed: number;
  total: number;
  success: true;
}

export interface ProcessDepositsError {
  processed: number;
  total: number;
  success: false;
  error: string;
}

export type ProcessDepositsResult = ProcessDepositsSuccess | ProcessDepositsError;
