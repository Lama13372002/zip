'use client';

// Global error logging utility
export class ErrorLogger {
  private static instance: ErrorLogger;
  private originalFetch: typeof fetch;

  constructor() {
    this.originalFetch = window.fetch;
    this.setupGlobalErrorHandlers();
    this.setupFetchInterceptor();
  }

  static getInstance(): ErrorLogger {
    if (!ErrorLogger.instance) {
      ErrorLogger.instance = new ErrorLogger();
    }
    return ErrorLogger.instance;
  }

  private setupGlobalErrorHandlers() {
    // Global unhandled error handler
    window.addEventListener('error', (event) => {
      console.group('🚨 Global Unhandled Error');
      console.error('Message:', event.message);
      console.error('Source:', event.filename);
      console.error('Line:', event.lineno);
      console.error('Column:', event.colno);
      console.error('Error object:', event.error);
      console.error('Stack:', event.error?.stack);
      console.groupEnd();

      this.logToConsole('GLOBAL_ERROR', {
        message: event.message,
        source: event.filename,
        line: event.lineno,
        column: event.colno,
        stack: event.error?.stack,
        timestamp: new Date().toISOString(),
      });
    });

    // Global unhandled promise rejection handler
    window.addEventListener('unhandledrejection', (event) => {
      console.group('🚨 Unhandled Promise Rejection');
      console.error('Reason:', event.reason);
      console.error('Promise:', event.promise);
      console.groupEnd();

      this.logToConsole('PROMISE_REJECTION', {
        reason: event.reason?.toString(),
        stack: event.reason?.stack,
        timestamp: new Date().toISOString(),
      });
    });
  }

  private setupFetchInterceptor() {
    window.fetch = async (...args) => {
      const [resource, config] = args;
      const startTime = Date.now();

      try {
        console.group(`🌐 API Request: ${typeof resource === 'string'
          ? resource
          : resource instanceof URL
            ? resource.href
            : (resource as Request).url}`);
        console.log('Method:', config?.method || 'GET');
        console.log('Headers:', config?.headers);
        console.log('Body:', config?.body);
        console.log('Start time:', new Date().toISOString());
        console.groupEnd();

        const response = await this.originalFetch(...args);
        const duration = Date.now() - startTime;

        if (!response.ok) {
          await this.handleApiError(resource, config, response, duration);
        } else {
          console.group(`✅ API Success: ${typeof resource === 'string'
            ? resource
            : resource instanceof URL
              ? resource.href
              : (resource as Request).url}`);
          console.log('Status:', response.status);
          console.log('Duration:', `${duration}ms`);
          console.groupEnd();
        }

        return response;
      } catch (error) {
        const duration = Date.now() - startTime;
        await this.handleNetworkError(resource, config, error, duration);
        throw error;
      }
    };
  }

  private async handleApiError(
    resource: RequestInfo | URL,
    config: RequestInit | undefined,
    response: Response,
    duration: number
  ) {
    const url = typeof resource === 'string'
      ? resource
      : resource instanceof URL
        ? resource.href
        : (resource as Request).url;
    let responseText = '';
    let responseJson: unknown = null;

    try {
      responseText = await response.clone().text();
      try {
        responseJson = JSON.parse(responseText);
      } catch {
        // Not JSON, keep as text
      }
    } catch (e) {
      responseText = 'Could not read response body';
    }

    console.group(`❌ API Error: ${url}`);
    console.error('Status:', response.status, response.statusText);
    console.error('Duration:', `${duration}ms`);
    console.error('Request Method:', config?.method || 'GET');
    console.error('Request Headers:', config?.headers);
    console.error('Request Body:', config?.body);
    console.error('Response Headers:', Object.fromEntries(response.headers.entries()));
    console.error('Response Text:', responseText);
    console.error('Response JSON:', responseJson);
    console.groupEnd();

    this.logToConsole('API_ERROR', {
      url,
      method: config?.method || 'GET',
      status: response.status,
      statusText: response.statusText,
      duration,
      requestHeaders: config?.headers,
      requestBody: config?.body,
      responseHeaders: Object.fromEntries(response.headers.entries()),
      responseText,
      responseJson,
      timestamp: new Date().toISOString(),
    });
  }

  private async handleNetworkError(
    resource: RequestInfo | URL,
    config: RequestInit | undefined,
    error: unknown,
    duration: number
  ) {
    const url = typeof resource === 'string'
      ? resource
      : resource instanceof URL
        ? resource.href
        : (resource as Request).url;
    const errorObj = error as Error;

    console.group(`🔥 Network Error: ${url}`);
    console.error('Error:', error);
    console.error('Duration:', `${duration}ms`);
    console.error('Request Method:', config?.method || 'GET');
    console.error('Request Headers:', config?.headers);
    console.error('Request Body:', config?.body);
    console.error('Stack:', errorObj?.stack);
    console.groupEnd();

    this.logToConsole('NETWORK_ERROR', {
      url,
      method: config?.method || 'GET',
      duration,
      requestHeaders: config?.headers,
      requestBody: config?.body,
      error: errorObj?.message,
      stack: errorObj?.stack,
      timestamp: new Date().toISOString(),
    });
  }

  private logToConsole(type: string, data: Record<string, unknown>) {
    console.group(`📝 Error Log [${type}]`);
    console.table(data);
    console.groupEnd();
  }

  // Method to manually log errors with context
  public logError(
    title: string,
    error: unknown,
    context?: Record<string, unknown>
  ) {
    const errorObj = error as Error;
    console.group(`🚨 Manual Error Log: ${title}`);
    console.error('Error:', error);
    console.error('Context:', context);
    console.error('Stack:', errorObj?.stack);
    console.error('Timestamp:', new Date().toISOString());
    console.groupEnd();

    this.logToConsole('MANUAL_ERROR', {
      title,
      error: errorObj?.message || String(error),
      stack: errorObj?.stack,
      context,
      timestamp: new Date().toISOString(),
    });
  }

  // Method to create detailed error information for dialogs
  public createErrorDetails(
    error: unknown,
    context?: Record<string, unknown>
  ): {
    error: string;
    details?: string;
    debugInfo?: Record<string, unknown>;
    timestamp: string;
  } {
    const errorObj = error as Error;
    return {
      error: errorObj?.message || String(error),
      details: errorObj?.stack || undefined,
      debugInfo: {
        ...context,
        errorName: errorObj?.name,
        userAgent: navigator.userAgent,
        url: window.location.href,
        timestamp: new Date().toISOString(),
      },
      timestamp: new Date().toISOString(),
    };
  }
}

// Initialize global error logger
export const initializeErrorLogger = () => {
  return ErrorLogger.getInstance();
};

// Export convenience functions
export const logError = (title: string, error: unknown, context?: Record<string, unknown>) => {
  ErrorLogger.getInstance().logError(title, error, context);
};

export const createErrorDetails = (error: unknown, context?: Record<string, unknown>) => {
  return ErrorLogger.getInstance().createErrorDetails(error, context);
};
