import * as speakeasy from 'speakeasy';
import * as https from 'https';

export interface NowPaymentsCreatePaymentReq {
  price_amount: number;
  price_currency: string;
  pay_currency: string;
  ipn_callback_url?: string;
  order_id?: string;
  order_description?: string;
  is_fixed_rate?: boolean;
  is_fee_paid_by_user?: boolean;
}

export interface NowPaymentsCreatePaymentRes {
  payment_id: string;
  payment_status: string;
  pay_address: string;
  price_amount: number;
  price_currency: string;
  pay_amount: number;
  pay_currency: string;
  order_id?: string;
  ipn_callback_url?: string;
  created_at: string;
  updated_at: string;
  purchase_id?: string;
  amount_received?: number | null;
  payin_extra_id?: string | null;
  network?: string;
  expiration_estimate_date?: string | null;
}

export interface NowPaymentsWebhookPayment {
  payment_id: number;
  parent_payment_id?: number | null;
  invoice_id?: string | null;
  payment_status: string;
  pay_address?: string;
  payin_extra_id?: string | null;
  price_amount: number;
  price_currency: string;
  pay_amount: number;
  actually_paid: number;
  actually_paid_at_fiat: number;
  pay_currency: string;
  order_id?: string | null;
  order_description?: string | null;
  purchase_id?: string;
  outcome_amount?: number;
  outcome_currency?: string;
  payment_extra_ids?: string[] | null;
  fee?: unknown;
}

export interface NowPaymentsAuthRes {
  token: string;
}

export interface NowPaymentsPayoutRes {
  id: string;
  batch_withdrawal_id?: string;
  status: string;
  error?: string | null;
  currency: string;
  amount: string;
  address: string;
  extra_id?: string | null;
  hash?: string | null;
  created_at: string;
}

export interface NowPaymentsPayoutBatchRes {
  id: string;
  withdrawals: NowPaymentsPayoutRes[];
}

export interface NowPaymentsVerifyPayoutRes {
  success: boolean;
  message?: string;
}

class NowPaymentsAPI {
  private apiKey: string;
  private baseUrl = 'https://api.nowpayments.io/v1';
  private jwtToken: string | undefined;
  private jwtExpiresAt: number = 0;

  constructor() {
    this.apiKey = process.env.NOWPAYMENTS_API_KEY || '';
  }

  private headers(extra: Record<string, string> = {}) {
    return {
      'x-api-key': this.apiKey,
      'Content-Type': 'application/json',
      ...extra,
    };
  }

  async status() {
    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'api.nowpayments.io',
        port: 443,
        path: '/v1/status',
        method: 'GET'
      };

      const req = https.request(options, (res) => {
        let responseBody = '';

        res.on('data', (chunk) => {
          responseBody += chunk;
        });

        res.on('end', () => {
          try {
            const statusData = JSON.parse(responseBody);
            resolve(statusData);
          } catch (parseError) {
            reject(new Error(`Failed to parse status response: ${parseError}`));
          }
        });
      });

      req.on('error', (error) => {
        reject(new Error(`NOWPayments status network error: ${error.message}`));
      });

      req.end();
    });
  }

  async createPayment(
    data: NowPaymentsCreatePaymentReq
  ): Promise<NowPaymentsCreatePaymentRes> {
    return new Promise((resolve, reject) => {
      const requestData = JSON.stringify(data);

      const options = {
        hostname: 'api.nowpayments.io',
        port: 443,
        path: '/v1/payment',
        method: 'POST',
        headers: {
          'x-api-key': this.apiKey,
          'Content-Type': 'application/json',
          'Content-Length': requestData.length
        }
      };

      const req = https.request(options, (res) => {
        let responseBody = '';

        res.on('data', (chunk) => {
          responseBody += chunk;
        });

        res.on('end', () => {
          // NOWPayments returns 201 for successfully created payments
          if (res.statusCode !== 200 && res.statusCode !== 201) {
            reject(new Error(`NOWPayments error ${res.statusCode}: ${responseBody}`));
            return;
          }

          try {
            const paymentData = JSON.parse(responseBody) as NowPaymentsCreatePaymentRes;
            resolve(paymentData);
          } catch (parseError) {
            reject(new Error(`Failed to parse payment response: ${parseError}`));
          }
        });
      });

      req.on('error', (error) => {
        reject(new Error(`NOWPayments payment network error: ${error.message}`));
      });

      req.write(requestData);
      req.end();
    });
  }

  async getPayment(payment_id: string) {
    const r = await fetch(`${this.baseUrl}/payment/${payment_id}`, {
      headers: this.headers(),
    });
    if (!r.ok) throw new Error(`NOWPayments error ${r.status}`);
    return r.json() as Promise<NowPaymentsCreatePaymentRes>;
  }

  private async ensureJwt(): Promise<string> {
    const now = Date.now();
    if (this.jwtToken && now < this.jwtExpiresAt - 15000) return this.jwtToken;

    const email = process.env.NOWPAYMENTS_EMAIL || '';
    const password = process.env.NOWPAYMENTS_PASSWORD || '';

    console.log('🔑 Getting JWT token...');

    return new Promise((resolve, reject) => {
      const data = JSON.stringify({ email, password });

      const options = {
        hostname: 'api.nowpayments.io',
        port: 443,
        path: '/v1/auth',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Content-Length': data.length
        }
      };

      const req = https.request(options, (res) => {
        let responseBody = '';

        res.on('data', (chunk) => {
          responseBody += chunk;
        });

        res.on('end', () => {
          console.log('🔑 JWT Status Code:', res.statusCode);

          if (res.statusCode !== 200) {
            reject(new Error(`NOWPayments auth error ${res.statusCode}: ${responseBody}`));
            return;
          }

          try {
            const authData = JSON.parse(responseBody) as NowPaymentsAuthRes;
            this.jwtToken = authData.token;
            this.jwtExpiresAt = now + 5 * 60 * 1000;
            console.log('✅ JWT token obtained successfully');
            resolve(this.jwtToken);
          } catch (parseError) {
            reject(new Error(`Failed to parse JWT response: ${parseError}`));
          }
        });
      });

      req.on('error', (error) => {
        console.error('❌ JWT request failed:', error.message);
        reject(new Error(`NOWPayments auth network error: ${error.message}`));
      });

      req.write(data);
      req.end();
    });
  }

  async createPayout(params: {
    address: string;
    currency: string;
    amount: string;
    ipn_callback_url?: string;
    unique_external_id?: string;
    payout_description?: string;
  }): Promise<NowPaymentsPayoutBatchRes> {
    const token = await this.ensureJwt();

    console.log('💰 Creating payout with params:', params);

    return new Promise((resolve, reject) => {
      const data = JSON.stringify({ withdrawals: [params] });

      const options = {
        hostname: 'api.nowpayments.io',
        port: 443,
        path: '/v1/payout',
        method: 'POST',
        headers: {
          'x-api-key': this.apiKey,
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'Content-Length': data.length
        }
      };

      console.log('📤 Sending payout request...');

      const req = https.request(options, (res) => {
        let responseBody = '';

        res.on('data', (chunk) => {
          responseBody += chunk;
        });

        res.on('end', () => {
          console.log('💰 Payout Status Code:', res.statusCode);
          console.log('💰 Payout Response:', responseBody);

          if (res.statusCode !== 200) {
            reject(new Error(`NOWPayments payout error ${res.statusCode}: ${responseBody}`));
            return;
          }

          try {
            const payoutData = JSON.parse(responseBody) as NowPaymentsPayoutBatchRes;
            console.log('✅ Payout created successfully');
            resolve(payoutData);
          } catch (parseError) {
            reject(new Error(`Failed to parse payout response: ${parseError}`));
          }
        });
      });

      req.on('error', (error) => {
        console.error('❌ Payout request failed:', error.message);
        reject(new Error(`NOWPayments payout network error: ${error.message}`));
      });

      req.write(data);
      req.end();
    });
  }

  async getPayout(payout_id: string): Promise<NowPaymentsPayoutRes[]> {
    const token = await this.ensureJwt();

    return new Promise((resolve, reject) => {
      const options = {
        hostname: 'api.nowpayments.io',
        port: 443,
        path: `/v1/payout/${payout_id}`,
        method: 'GET',
        headers: {
          'x-api-key': this.apiKey,
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        }
      };

      const req = https.request(options, (res) => {
        let responseBody = '';

        res.on('data', (chunk) => {
          responseBody += chunk;
        });

        res.on('end', () => {
          if (res.statusCode !== 200) {
            reject(new Error(`NOWPayments payout status error ${res.statusCode}: ${responseBody}`));
            return;
          }

          try {
            const payoutData = JSON.parse(responseBody) as NowPaymentsPayoutRes[];
            resolve(payoutData);
          } catch (parseError) {
            reject(new Error(`Failed to parse payout status response: ${parseError}`));
          }
        });
      });

      req.on('error', (error) => {
        reject(new Error(`NOWPayments payout status network error: ${error.message}`));
      });

      req.end();
    });
  }

  async verifyPayout(batchWithdrawalId: string, verificationCode: string): Promise<NowPaymentsVerifyPayoutRes> {
    const token = await this.ensureJwt();

    return new Promise((resolve, reject) => {
      const data = JSON.stringify({ verification_code: verificationCode });

      const options = {
        hostname: 'api.nowpayments.io',
        port: 443,
        path: `/v1/payout/${batchWithdrawalId}/verify`,
        method: 'POST',
        headers: {
          'x-api-key': this.apiKey,
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
          'Content-Length': data.length
        }
      };

      const req = https.request(options, (res) => {
        let responseBody = '';

        res.on('data', (chunk) => {
          responseBody += chunk;
        });

        res.on('end', () => {
          if (res.statusCode !== 200) {
            reject(new Error(`NOWPayments payout verification error ${res.statusCode}: ${responseBody}`));
            return;
          }

          try {
            const verifyData = JSON.parse(responseBody) as NowPaymentsVerifyPayoutRes;
            resolve(verifyData);
          } catch (parseError) {
            reject(new Error(`Failed to parse verification response: ${parseError}`));
          }
        });
      });

      req.on('error', (error) => {
        reject(new Error(`NOWPayments verification network error: ${error.message}`));
      });

      req.write(data);
      req.end();
    });
  }

  generate2FACode(): string | null {
    const secret = process.env.NOWPAYMENTS_2FA_SECRET;
    if (!secret) return null;

    try {
      return speakeasy.totp({
        secret: secret,
        encoding: 'base32',
      });
    } catch (error) {
      console.error('Failed to generate 2FA code:', error);
      return null;
    }
  }
}

export const nowPayments = new NowPaymentsAPI();
