// Sumsub signing and client helper
import crypto from 'crypto';

export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';

export function getEnv(name: string, fallback?: string): string {
  const v = process.env[name] ?? fallback;
  if (!v) throw new Error(`Missing env: ${name}`);
  return v;
}

function hmacSha256Hex(secret: string, message: string): string {
  return crypto.createHmac('sha256', secret).update(Buffer.from(message, 'utf8')).digest('hex');
}

export async function sumsubFetch(path: string, options: { method?: HttpMethod; body?: unknown } = {}) {
  const method = (options.method ?? 'GET').toUpperCase() as HttpMethod;
  const bodyString = options.body ? JSON.stringify(options.body) : '';
  const ts = Math.floor(Date.now() / 1000).toString();

  const baseUrl = getEnv('SUMSUB_BASE_URL', 'https://api.sumsub.com');
  const appToken = getEnv('SUMSUB_APP_TOKEN');
  const secret = getEnv('SUMSUB_SECRET_KEY');

  const stringToSign = ts + method + path + bodyString;
  const signature = hmacSha256Hex(secret, stringToSign);

  const res = await fetch(`${baseUrl}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      'X-App-Token': appToken,
      'X-App-Access-Sig': signature,
      'X-App-Access-Ts': ts,
    },
    body: bodyString || undefined,
    // Avoid Next.js caching for server actions
    cache: 'no-store',
  } as RequestInit);

  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`Sumsub API error ${res.status}: ${text}`);
  }

  const ct = res.headers.get('content-type') || '';
  if (ct.includes('application/json')) return res.json();
  return res.text();
}

export async function createWebSdkLink(params: {
  levelName: string;
  userId: string;
  applicantIdentifiers?: { email?: string; phone?: string };
  ttlInSecs?: number;
}) {
  const body = {
    levelName: params.levelName,
    userId: params.userId,
    applicantIdentifiers: params.applicantIdentifiers,
    ttlInSecs: params.ttlInSecs ?? 1800,
  };
  return sumsubFetch('/resources/sdkIntegrations/levels/-/websdkLink', { method: 'POST', body });
}

export async function createAccessToken(params: {
  levelName: string;
  userId: string;
  applicantIdentifiers?: { email?: string; phone?: string };
  ttlInSecs?: number;
}) {
  const body = {
    levelName: params.levelName,
    userId: params.userId,
    applicantIdentifiers: params.applicantIdentifiers,
    ttlInSecs: params.ttlInSecs ?? 600,
  };
  return sumsubFetch('/resources/accessTokens/sdk', { method: 'POST', body });
}

export async function getApplicantInfo(applicantId: string) {
  try {
    return await sumsubFetch(`/resources/applicants/${applicantId}/one`);
  } catch (error) {
    // If applicant not found, return null
    return null;
  }
}

export function mapSumsubAnswerToStatus(answer?: string, rejectType?: string): 'completed' | 'declined' | 'pending' {
  if (!answer) return 'pending';
  if (answer === 'GREEN') return 'completed';
  if (answer === 'RED') return 'declined';
  return 'pending';
}
