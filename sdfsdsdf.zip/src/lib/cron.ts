import cron from 'node-cron';
import { db } from './db';
import type { ProcessDepositsResult } from '@/types';

// Функция обработки confirmed депозитов
async function processConfirmedDeposits(): Promise<ProcessDepositsResult> {
  console.log('🔍 Проверка confirmed депозитов...');

  try {
    return await db.transaction(async (client) => {
      // Находим confirmed депозиты без записей в ledger
      const unprocessedDeposits = await client.query(`
        SELECT d.*
        FROM deposits d
        WHERE d.status = 'confirmed'
        AND d.id NOT IN (
          SELECT DISTINCT related_deposit_id
          FROM ledger_entries
          WHERE related_deposit_id IS NOT NULL
          AND entry_type = 'deposit_in'
        )
        ORDER BY d.created_at ASC
      `);

      console.log(`💰 Найдено ${unprocessedDeposits.rows.length} необработанных confirmed депозитов`);

      if (unprocessedDeposits.rows.length === 0) {
        return { processed: 0, total: 0, success: true };
      }

      let processedCount = 0;

      for (const deposit of unprocessedDeposits.rows) {
        try {
          console.log(`💰 Обработка депозита ID: ${deposit.id} - ${deposit.desired_amount} ${deposit.currency} для пользователя ${deposit.user_id}`);

          // Используем desired_amount - сумму, которую пользователь хотел внести
          const amountToCredit = parseFloat(String(deposit.desired_amount || deposit.amount));

          // 1. Создаем или обновляем баланс пользователя
          await client.query(`
            INSERT INTO users_balance (user_id, currency, available, bonus, locked, updated_at)
            VALUES ($1, $2, $3, 0, 0, NOW())
            ON CONFLICT (user_id, currency)
            DO UPDATE SET
              available = users_balance.available + $3,
              updated_at = NOW()
          `, [deposit.user_id, deposit.currency, amountToCredit]);

          // 2. Создаем запись в ledger_entries
          await client.query(`
            INSERT INTO ledger_entries (
              user_id,
              currency,
              entry_type,
              amount,
              balance_available_delta,
              balance_bonus_delta,
              balance_locked_delta,
              related_deposit_id,
              idempotency_key,
              created_at
            ) VALUES ($1, $2, 'deposit_in', $3, $3, 0, 0, $4, $5, NOW())
          `, [
            deposit.user_id,
            deposit.currency,
            amountToCredit,
            deposit.id,
            `auto_deposit_${deposit.id}_${Date.now()}`
          ]);

          console.log(`✅ Зачислено ${amountToCredit} ${deposit.currency} пользователю ${deposit.user_id}`);
          processedCount++;

        } catch (error) {
          console.error(`❌ Ошибка обработки депозита ${deposit.id}:`, error);
        }
      }

      console.log(`🎉 Обработано депозитов: ${processedCount} из ${unprocessedDeposits.rows.length}`);

      return {
        processed: processedCount,
        total: unprocessedDeposits.rows.length,
        success: true
      };
    });

  } catch (error) {
    console.error('❌ Ошибка при обработке депозитов:', error);
    return {
      processed: 0,
      total: 0,
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    };
  }
}

let isRunning = false;
let cronSettings: {
  mode: string;
  check_interval_minutes: number;
  timezone: string;
  grace_period_minutes: number;
} | null = null;

// Загрузка настроек из базы данных
async function loadCronSettings() {
  try {
    const result = await db.query("SELECT value FROM app_config WHERE key = 'accrual_precision_settings'");
    if (result.rows.length > 0) {
      cronSettings = result.rows[0].value as {
        mode: string;
        check_interval_minutes: number;
        timezone: string;
        grace_period_minutes: number;
      };
      console.log('📋 Loaded cron settings:', cronSettings);
    } else {
      // Настройки по умолчанию
      cronSettings = {
        mode: "precise_24h_from_creation",
        check_interval_minutes: 10,
        timezone: "UTC",
        grace_period_minutes: 5
      };
      console.log('⚠️ Using default cron settings');
    }
  } catch (error) {
    console.error('❌ Failed to load cron settings, using defaults:', error);
    cronSettings = {
      mode: "precise_24h_from_creation",
      check_interval_minutes: 10,
      timezone: "UTC",
      grace_period_minutes: 5
    };
  }
}

// Функция автоматических начислений (с депозитами - для совместимости)
async function runAccruals() {
  if (isRunning) {
    console.log('⏳ Accruals already running, skipping...');
    return;
  }

  try {
    isRunning = true;
    console.log('🚀 Starting automatic processing...');

    // 1. ОТКЛЮЧЕНО: обработка депозитов теперь только в deposit-monitor.js
    console.log('⚠️ Обработка депозитов отключена в cron - используется deposit-monitor.js');

    // 2. Затем запускаем начисления
    await runAccrualsOnly();
  } catch (error) {
    console.error('❌ Automatic processing error:', error);
  } finally {
    isRunning = false;
  }
}

// Функция только начислений (без депозитов)
async function runAccrualsOnly() {
  try {
    console.log('📈 Запуск автоматических начислений...');
    const response = await fetch(`${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/api/admin/accruals/auto-run`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'Internal-Cron'
      }
    });

    const result = await response.json();

    if (result.success) {
      console.log('✅ Accruals completed:', result.message);
    } else {
      console.error('❌ Accruals failed:', result.error);
    }
  } catch (error) {
    console.error('❌ Accruals error:', error);
  }
}

// Инициализация cron задач
export async function initializeCron() {
  // Загружаем настройки из базы данных
  await loadCronSettings();

  // Только в production и если не в Vercel/Netlify (у них нет постоянных процессов)
  if (process.env.NODE_ENV === 'production' &&
      !process.env.VERCEL &&
      !process.env.NETLIFY) {

    console.log('📅 Initializing cron jobs...');

    const interval = cronSettings?.check_interval_minutes || 10;
    const timezone = cronSettings?.timezone || "UTC";

    // 1. ОТКЛЮЧЕНО: быстрая обработка депозитов - теперь только deposit-monitor.js
    console.log('⚠️ Быстрая обработка депозитов отключена - используется deposit-monitor.js');

    // 2. Основные начисления по расписанию
    const schedulePattern = `*/${interval} * * * *`;
    console.log(`⏰ Accruals schedule: ${schedulePattern} (timezone: ${timezone})`);

    cron.schedule(schedulePattern, async () => {
      await runAccrualsOnly(); // Новая функция только для начислений
    }, {
      timezone: timezone
    });

    console.log('✅ Cron jobs initialized: fast deposits (5s) + accruals (schedule)');
  } else {
    console.log('⚠️ Cron jobs disabled (development or serverless environment)');
  }
}

// Для ручного запуска
export { runAccruals, runAccrualsOnly, processConfirmedDeposits };
