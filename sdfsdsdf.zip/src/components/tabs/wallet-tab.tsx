'use client';

import { useState, useEffect, useCallback } from 'react';
import { ArrowDownRight, ArrowUpRight, Copy, ExternalLink, Clock, CheckCircle, XCircle, AlertCircle, Wallet, Loader2, Settings, UserPlus, UserMinus } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ToastAction } from '@/components/ui/toast';
import { ErrorDialog } from '@/components/ui/error-dialog';
import { useToast } from '@/hooks/use-toast';
import { useTelegram } from '@/components/providers/telegram-provider';
import { NetworkInfo } from '@/types';
import { DepositEstimate } from '@/components/ui/deposit-estimate';
import { getExplorerUrl, getExplorerName, isExplorerSupported } from '@/lib/explorer-utils';
import { useVerificationStatus } from '@/hooks/use-verification-status';
import { useDepositEstimate } from '@/hooks/use-deposit-estimate';

interface UserBalance {
  available: number;
  bonus: number;
  locked: number;
  total_invested: number;
  total_balance: number;
}

interface Transaction {
  id: number;
  type: 'deposit' | 'withdrawal' | 'admin_credit' | 'admin_debit';
  amount: number;
  status: string;
  network: string;
  tx_hash?: string;
  date: string;
  fee: number;
  description?: string;
  balance_available_delta?: number;
  balance_bonus_delta?: number;
}

export function WalletTab() {
  const { user } = useTelegram();
  const { isVerified } = useVerificationStatus();
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawAddress, setWithdrawAddress] = useState('');
  const [selectedNetwork, setSelectedNetwork] = useState('TRON');
  const [isDepositDialogOpen, setIsDepositDialogOpen] = useState(false);
  const [isWithdrawDialogOpen, setIsWithdrawDialogOpen] = useState(false);
  const [isDepositLoading, setIsDepositLoading] = useState(false);
  const [isWithdrawLoading, setIsWithdrawLoading] = useState(false);
  const [balance, setBalance] = useState<UserBalance>({
    available: 0,
    bonus: 0,
    locked: 0,
    total_invested: 0,
    total_balance: 0
  });
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isBalanceLoading, setIsBalanceLoading] = useState(true);
  const [isTransactionsLoading, setIsTransactionsLoading] = useState(true);
  const { toast } = useToast();

  const [generatedOrderId, setGeneratedOrderId] = useState<string | null>(null);
  const [generatedAddress, setGeneratedAddress] = useState<string | null>(null);
  const [isCheckingDeposit, setIsCheckingDeposit] = useState(false);
  const [depositTxHash, setDepositTxHash] = useState<string | null>(null);
  const [depositNetwork, setDepositNetwork] = useState<string | null>(null);

  const [depositNetworks, setDepositNetworks] = useState<NetworkInfo[]>([]);
  const [withdrawNetworks, setWithdrawNetworks] = useState<NetworkInfo[]>([]);
  const [isNetworksLoading, setIsNetworksLoading] = useState(true);
  const [cancelLockTime, setCancelLockTime] = useState<number | null>(null);
  const [depositAmountWithFee, setDepositAmountWithFee] = useState<string>('');

  // Хук для получения расчета депозита с комиссией
  const { estimate, fetchEstimate } = useDepositEstimate();

  // Error dialog state
  const [errorDialog, setErrorDialog] = useState<{
    isOpen: boolean;
    title: string;
    error: string;
    details?: string;
    debugInfo?: Record<string, unknown>;
    timestamp?: string;
  }>({
    isOpen: false,
    title: '',
    error: '',
  });

  const copyToClipboard = useCallback((text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Copied to clipboard",
    });
  }, [toast]);

  // Загрузка сетей из API
  const loadNetworks = useCallback(async () => {
    try {
      setIsNetworksLoading(true);
      const [depositRes, withdrawRes] = await Promise.all([
        fetch('/api/user/networks?type=payment', { cache: 'no-store' }),
        fetch('/api/user/networks?type=payout', { cache: 'no-store' })
      ]);

      const [depositData, withdrawData] = await Promise.all([
        depositRes.json(),
        withdrawRes.json()
      ]);

      if (depositData.success) {
        setDepositNetworks(depositData.data.networks);
      }
      if (withdrawData.success) {
        setWithdrawNetworks(withdrawData.data.networks);
      }

      // Устанавливаем TRON как выбранную сеть, если доступна, иначе первую доступную
      if (depositData.success && depositData.data.networks.length > 0) {
        const tronNetwork = depositData.data.networks.find((n: NetworkInfo) => n.value === 'TRON');
        setSelectedNetwork(tronNetwork ? 'TRON' : depositData.data.networks[0].value);
      }
    } catch (error) {
      const errorDetails = error instanceof Error ? error.message : String(error);
      toast({
        title: "Error",
        description: "Failed to load payment networks",
        variant: "destructive",
        action: (
          <ToastAction
            altText="Copy error details"
            onClick={() => copyToClipboard(`Load Networks Error: Failed to load payment networks\nDetails: ${errorDetails}\nTimestamp: ${new Date().toISOString()}`)}
          >
            Copy
          </ToastAction>
        )
      });
    } finally {
      setIsNetworksLoading(false);
    }
  }, [toast, copyToClipboard]);

  // Helper function to show error dialog with copy functionality
  const showErrorDialog = (title: string, error: string, details?: string, debugInfo?: Record<string, unknown>) => {
    setErrorDialog({
      isOpen: true,
      title,
      error,
      details,
      debugInfo,
      timestamp: new Date().toISOString(),
    });
  };

  // Загрузка баланса пользователя
  const loadBalance = useCallback(async () => {
    if (!user?.id) return;

    try {
      setIsBalanceLoading(true);
      const response = await fetch(`/api/user/balance?user_id=${user.id}`);
      const result = await response.json();

      if (result.success) {
        setBalance(result.data);
      } else {
        const errorMsg = result.error || "Failed to load balance";
        toast({
          title: "Error",
          description: errorMsg,
          variant: "destructive",
          action: (
            <ToastAction
              altText="Copy error details"
              onClick={() => copyToClipboard(`Load Balance Error: ${errorMsg}\nUser ID: ${user?.id}\nTimestamp: ${new Date().toISOString()}`)}
            >
              Copy
            </ToastAction>
          )
        });
      }
    } catch (error) {
      const errorDetails = error instanceof Error ? error.message : String(error);
      toast({
        title: "Error",
        description: "Failed to load balance",
        variant: "destructive",
        action: (
          <ToastAction
            altText="Copy error details"
            onClick={() => copyToClipboard(`Load Balance Error: Failed to load balance\nDetails: ${errorDetails}\nUser ID: ${user?.id}\nTimestamp: ${new Date().toISOString()}`)}
          >
            Copy
          </ToastAction>
        )
      });
    } finally {
      setIsBalanceLoading(false);
    }
  }, [user, toast, copyToClipboard]);

  // Загрузка истории транзакций
  const loadTransactions = useCallback(async () => {
    if (!user?.id) return;

    try {
      setIsTransactionsLoading(true);
      const response = await fetch(`/api/user/transactions?user_id=${user.id}&limit=10`);
      const result = await response.json();

      if (result.success) {
        setTransactions(result.data.transactions);
      } else {
        const errorMsg = result.error || "Failed to load transactions";
        toast({
          title: "Error",
          description: errorMsg,
          variant: "destructive",
          action: (
            <ToastAction
              altText="Copy error details"
              onClick={() => copyToClipboard(`Load Transactions Error: ${errorMsg}\nUser ID: ${user?.id}\nTimestamp: ${new Date().toISOString()}`)}
            >
              Copy
            </ToastAction>
          )
        });
      }
    } catch (error) {
      const errorDetails = error instanceof Error ? error.message : String(error);
      toast({
        title: "Error",
        description: "Failed to load transactions",
        variant: "destructive",
        action: (
          <ToastAction
            altText="Copy error details"
            onClick={() => copyToClipboard(`Load Transactions Error: Failed to load transactions\nDetails: ${errorDetails}\nUser ID: ${user?.id}\nTimestamp: ${new Date().toISOString()}`)}
          >
            Copy
          </ToastAction>
        )
      });
    } finally {
      setIsTransactionsLoading(false);
    }
  }, [user, toast, copyToClipboard]);

  useEffect(() => {
    loadNetworks();
  }, [loadNetworks]);

  // Автоматическая проверка депозита в реальном времени
  useEffect(() => {
    if (!generatedOrderId || isCheckingDeposit) return;

    const interval = setInterval(async () => {
      try {
        const res = await fetch('/api/deposits/check', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ order_id: generatedOrderId })
        });
        const data = await res.json();
        if (data.success) {
          const status = data.data?.status;
          const txHash = data.data?.tx_hash;
          const network = data.data?.network;

          // Сохраняем данные о транзакции если они есть
          if (txHash && !depositTxHash) {
            setDepositTxHash(txHash);
            toast({ title: 'Transaction detected', description: 'Transaction found in blockchain scanner!' });
          }
          if (network) {
            setDepositNetwork(network);
          }

          if (status === 'confirmed') {
            toast({ title: 'Deposit confirmed', description: 'Funds have been credited to your balance.' });
            setIsDepositDialogOpen(false);
            setGeneratedOrderId(null);
            setGeneratedAddress(null);
            setDepositTxHash(null);
            setDepositNetwork(null);
            // Перезагружаем баланс и транзакции
            if (user?.id) {
              try {
                const [balanceRes, transactionsRes] = await Promise.all([
                  fetch(`/api/user/balance?user_id=${user.id}`),
                  fetch(`/api/user/transactions?user_id=${user.id}&limit=10`)
                ]);
                const [balanceData, transactionsData] = await Promise.all([
                  balanceRes.json(),
                  transactionsRes.json()
                ]);
                if (balanceData.success) {
                  setBalance(balanceData.data);
                }
                if (transactionsData.success) {
                  setTransactions(transactionsData.data.transactions);
                }
              } catch {}
            }
          }
        }
      } catch (e) {
        // Игнорируем ошибки автоматической проверки
      }
    }, 5000); // Проверяем каждые 5 секунд

    return () => clearInterval(interval);
  }, [generatedOrderId, isCheckingDeposit, depositTxHash, toast, user?.id]);

  useEffect(() => {
    if (user?.id) {
      loadBalance();
      loadTransactions();
    }
  }, [user?.id, loadBalance, loadTransactions]);

  // 5-секундный лок кнопки Cancel при генерации адреса
  useEffect(() => {
    if (generatedAddress) {
      setCancelLockTime(5);
      const interval = setInterval(() => {
        setCancelLockTime(prev => {
          if (prev === null || prev <= 1) {
            clearInterval(interval);
            return null;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    } else {
      setCancelLockTime(null);
    }
  }, [generatedAddress]);

  // Получаем расчет депозита когда изменяется сумма или сеть
  useEffect(() => {
    if (depositAmount && parseFloat(depositAmount) > 0) {
      fetchEstimate(depositAmount, selectedNetwork);
    }
  }, [depositAmount, selectedNetwork, fetchEstimate]);

  // Обновляем сумму с комиссией когда получили расчет
  useEffect(() => {
    if (estimate?.pay_amount) {
      setDepositAmountWithFee(estimate.pay_amount.toFixed(2));
    }
  }, [estimate]);

  const handleDeposit = async () => {
    if (!user?.id) {
      toast({
        title: "Error",
        description: "User not authenticated",
        variant: "destructive",
        action: (
          <ToastAction
            altText="Copy error details"
            onClick={() => copyToClipboard(`Authentication Error: User not authenticated\nTimestamp: ${new Date().toISOString()}`)}
          >
            Copy
          </ToastAction>
        )
      });
      return;
    }

    const selectedNetworkInfo = depositNetworks.find(n => n.value === selectedNetwork);
    const minAmount = selectedNetworkInfo?.min_amount || 10;

    if (!depositAmount || parseFloat(depositAmount) < minAmount) {
      toast({
        title: "Invalid Amount",
        description: `Minimum deposit amount is ${minAmount} USDT`,
        variant: "destructive",
        action: (
          <ToastAction
            altText="Copy error details"
            onClick={() => copyToClipboard(`Validation Error: Minimum deposit amount is ${minAmount} USDT\nProvided: ${depositAmount}\nNetwork: ${selectedNetwork}\nTimestamp: ${new Date().toISOString()}`)}
          >
            Copy
          </ToastAction>
        )
      });
      return;
    }

    try {
      setIsDepositLoading(true);

      const response = await fetch('/api/deposits/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: depositAmount,
          network: selectedNetwork,
          user_id: user.id,
        }),
      });

      const result = await response.json();

      if (result.success) {
        toast({
          title: "Deposit Created",
          description: "Payment address generated successfully",
        });

        // Показываем адрес для оплаты
        if (result.data.address) {
          setGeneratedAddress(result.data.address);
          setGeneratedOrderId(result.data.order_id || null);
        }

        // Оставляем диалог открытым, чтобы показать адрес и кнопку проверки
        setDepositAmount('');

        // Обновляем транзакции (добавится pending депозит)
        loadTransactions();
      } else {
        // Show detailed error dialog for deposit creation errors
        showErrorDialog(
          "Deposit Creation Failed",
          result.error || "Failed to create deposit",
          `Network: ${selectedNetwork}\nAmount: ${depositAmount} USDT\nUser ID: ${user.id}`,
          {
            response: result,
            request: {
              amount: depositAmount,
              network: selectedNetwork,
              user_id: user.id,
            },
            timestamp: new Date().toISOString(),
          }
        );
      }
    } catch (error) {
      // Show detailed error dialog for network/other errors
      showErrorDialog(
        "Network Error",
        "Failed to create deposit. Please try again.",
        `Network: ${selectedNetwork}\nAmount: ${depositAmount} USDT\nError: ${error instanceof Error ? error.message : String(error)}`,
        {
          error: error instanceof Error ? {
            name: error.name,
            message: error.message,
            stack: error.stack,
          } : error,
          request: {
            amount: depositAmount,
            network: selectedNetwork,
            user_id: user.id,
          },
          timestamp: new Date().toISOString(),
        }
      );
    } finally {
      setIsDepositLoading(false);
    }
  };

  const handleCheckDeposit = async () => {
    if (!generatedOrderId) return;
    try {
      setIsCheckingDeposit(true);
      const res = await fetch('/api/deposits/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ order_id: generatedOrderId })
      });
      const data = await res.json();
      if (data.success) {
        const status = data.data?.status;
        const txHash = data.data?.tx_hash;
        const network = data.data?.network;

        // Сохраняем данные о транзакции если они есть
        if (txHash) {
          setDepositTxHash(txHash);
        }
        if (network) {
          setDepositNetwork(network);
        }

        if (status === 'confirmed') {
          toast({ title: 'Deposit confirmed', description: 'Funds have been credited to your balance.' });
          setIsDepositDialogOpen(false);
          setGeneratedOrderId(null);
          setGeneratedAddress(null);
          setDepositTxHash(null);
          setDepositNetwork(null);
          await loadBalance();
        } else if (status === 'pending') {
          toast({ title: 'Awaiting confirmations', description: 'Please wait for blockchain confirmations.' });
        } else if (status === 'failed' || status === 'expired') {
          toast({ title: 'Payment not completed', description: 'The payment failed or expired.', variant: 'destructive' });
        }
        loadTransactions();
      } else {
        const errorMsg = data.error || 'Failed to check deposit';
        toast({
          title: 'Error',
          description: errorMsg,
          variant: 'destructive',
          action: (
            <ToastAction
              altText="Copy error details"
              onClick={() => copyToClipboard(`Check Deposit Error: ${errorMsg}\nOrder ID: ${generatedOrderId}\nTimestamp: ${new Date().toISOString()}`)}
            >
              Copy
            </ToastAction>
          )
        });
      }
    } catch (e) {
      const errorMsg = 'Failed to check deposit';
      const errorDetails = e instanceof Error ? e.message : String(e);
      toast({
        title: 'Error',
        description: errorMsg,
        variant: 'destructive',
        action: (
          <ToastAction
            altText="Copy error details"
            onClick={() => copyToClipboard(`Check Deposit Error: ${errorMsg}\nDetails: ${errorDetails}\nOrder ID: ${generatedOrderId}\nTimestamp: ${new Date().toISOString()}`)}
          >
            Copy
          </ToastAction>
        )
      });
    } finally {
      setIsCheckingDeposit(false);
    }
  };

  const handleWithdraw = async () => {
    if (!user?.id) {
      toast({
        title: "Error",
        description: "User not authenticated",
        variant: "destructive",
        action: (
          <ToastAction
            altText="Copy error details"
            onClick={() => copyToClipboard(`Authentication Error: User not authenticated\nTimestamp: ${new Date().toISOString()}`)}
          >
            Copy
          </ToastAction>
        )
      });
      return;
    }

    // Check verification status before allowing withdrawal
    if (!isVerified) {
      toast({
        title: "Verification Required",
        description: "You need to complete verification before making withdrawals. Please verify your identity first.",
        variant: "destructive",
      });
      return;
    }

    if (!withdrawAmount || !withdrawAddress) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
        action: (
          <ToastAction
            altText="Copy error details"
            onClick={() => copyToClipboard(`Validation Error: Please fill in all required fields\nAmount: ${withdrawAmount || 'missing'}\nAddress: ${withdrawAddress || 'missing'}\nNetwork: ${selectedNetwork}\nTimestamp: ${new Date().toISOString()}`)}
          >
            Copy
          </ToastAction>
        )
      });
      return;
    }

    const amount = parseFloat(withdrawAmount);
    const selectedNetworkInfo = withdrawNetworks.find(n => n.value === selectedNetwork);
    const minAmount = selectedNetworkInfo?.min_amount || 10;

    if (amount < minAmount) {
      toast({
        title: "Invalid Amount",
        description: `Minimum withdrawal amount is ${minAmount} USDT`,
        variant: "destructive",
        action: (
          <ToastAction
            altText="Copy error details"
            onClick={() => copyToClipboard(`Validation Error: Minimum withdrawal amount is ${minAmount} USDT\nProvided: ${amount}\nNetwork: ${selectedNetwork}\nTimestamp: ${new Date().toISOString()}`)}
          >
            Copy
          </ToastAction>
        )
      });
      return;
    }

    if (amount > balance.available) {
      toast({
        title: "Insufficient Balance",
        description: "You don't have enough available balance for this withdrawal",
        variant: "destructive",
        action: (
          <ToastAction
            altText="Copy error details"
            onClick={() => copyToClipboard(`Balance Error: You don't have enough available balance for this withdrawal\nRequested: ${amount} USDT\nAvailable: ${balance.available} USDT\nNetwork: ${selectedNetwork}\nTimestamp: ${new Date().toISOString()}`)}
          >
            Copy
          </ToastAction>
        )
      });
      return;
    }

    try {
      setIsWithdrawLoading(true);

      // Compute fee and net client-side (mirror of server)
      const feeFixed = selectedNetworkInfo?.fee_fixed || 0;
      const feePercent = selectedNetworkInfo?.fee_percent || 0;
      const feeTotal = Math.round(((feeFixed) + (feePercent > 0 ? amount * feePercent : 0)) * 100) / 100;
      const netAmount = Math.round((amount - feeTotal) * 100) / 100;

      const response = await fetch('/api/withdrawals/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          amount: amount,
          address: withdrawAddress,
          network: selectedNetwork,
          user_id: user.id,
          // extra fields (server recalculates, but useful for logging/compat)
          gross_amount: amount,
          fee: feeTotal,
          net_amount: netAmount,
        }),
      });

      const result = await response.json();

      if (result.success) {
        const data = result.data || {};
        toast({
          title: "Withdrawal Request Submitted",
          description: `Gross: ${(data.gross_amount ?? amount).toFixed(2)} USDT, Fee: ${(data.fee ?? feeTotal).toFixed(2)} USDT, You will receive: ${(data.net_amount ?? netAmount).toFixed(2)} USDT`,
        });

        setIsWithdrawDialogOpen(false);
        setWithdrawAmount('');
        setWithdrawAddress('');
        await loadBalance();
        await loadTransactions();
      } else {
        const errorMsg = result.error || "Failed to create withdrawal";
        toast({
          title: "Error",
          description: errorMsg,
          variant: "destructive",
          action: (
            <ToastAction
              altText="Copy error details"
              onClick={() => copyToClipboard(`Withdrawal Error: ${errorMsg}\nAmount: ${amount} USDT\nAddress: ${withdrawAddress}\nNetwork: ${selectedNetwork}\nUser ID: ${user.id}\nTimestamp: ${new Date().toISOString()}`)}
            >
              Copy
            </ToastAction>
          )
        });
      }
    } catch (error) {
      const errorDetails = error instanceof Error ? error.message : String(error);
      toast({
        title: "Error",
        description: "Failed to create withdrawal. Please try again.",
        variant: "destructive",
        action: (
          <ToastAction
            altText="Copy error details"
            onClick={() => copyToClipboard(`Withdrawal Network Error: Failed to create withdrawal\nDetails: ${errorDetails}\nAmount: ${amount} USDT\nAddress: ${withdrawAddress}\nNetwork: ${selectedNetwork}\nTimestamp: ${new Date().toISOString()}`)}
          >
            Copy
          </ToastAction>
        )
      });
    } finally {
      setIsWithdrawLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle size={16} className="text-primary" />;
      case 'pending':
        return <Clock size={16} className="text-warning" />;
      case 'failed':
        return <XCircle size={16} className="text-destructive" />;
      default:
        return <AlertCircle size={16} className="text-muted-foreground" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'text-primary border-primary/20';
      case 'pending':
        return 'text-warning border-warning/20';
      case 'failed':
        return 'text-destructive border-destructive/20';
      default:
        return 'text-muted-foreground border-border';
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'deposit':
        return <ArrowDownRight size={22} className="text-primary" />;
      case 'withdrawal':
        return <ArrowUpRight size={22} className="text-destructive" />;
      case 'admin_credit':
        return <UserPlus size={22} className="text-emerald-500" />;
      case 'admin_debit':
        return <UserMinus size={22} className="text-orange-500" />;
      default:
        return <Settings size={22} className="text-muted-foreground" />;
    }
  };

  const getTransactionLabel = (type: string) => {
    switch (type) {
      case 'deposit':
        return 'Deposit';
      case 'withdrawal':
        return 'Withdrawal';
      case 'admin_credit':
        return 'Admin Credit';
      case 'admin_debit':
        return 'Admin Debit';
      default:
        return 'Transaction';
    }
  };

  const getTransactionAmountColor = (type: string) => {
    switch (type) {
      case 'deposit':
      case 'admin_credit':
        return 'text-primary';
      case 'withdrawal':
      case 'admin_debit':
        return 'text-destructive';
      default:
        return 'text-foreground';
    }
  };

  const getTransactionAmountSign = (type: string) => {
    switch (type) {
      case 'deposit':
      case 'admin_credit':
        return '+';
      case 'withdrawal':
      case 'admin_debit':
        return '-';
      default:
        return '';
    }
  };

  return (
    <div className="space-y-6">
      {/* Balance Overview */}
      <Card className="border border-border/60 bg-card shadow-sm hover:shadow-md rounded-2xl">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold flex items-center">
            <div className="w-6 h-6 rounded-full bg-muted/40 flex items-center justify-center mr-2">
              <Wallet size={14} className="text-primary" />
            </div>
            Wallet Balance
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="text-center pt-2">
              {isBalanceLoading ? (
                <div className="flex items-center justify-center">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : (
                <>
                  <p className="text-4xl font-bold tracking-tight">
                    {balance.available.toFixed(2)} USDT
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">Available Balance</p>
                </>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 rounded-xl bg-card/60 border border-border/60">
                <p className="text-lg font-bold text-warning">
                  {isBalanceLoading ? '--' : balance.total_invested.toFixed(2)} USDT
                </p>
                <p className="text-xs text-muted-foreground mt-1">Locked in Investments</p>
              </div>
              <div className="text-center p-4 rounded-xl bg-card/60 border border-border/60">
                <p className="text-lg font-bold text-primary">
                  {isBalanceLoading ? '--' : balance.bonus.toFixed(2)} USDT
                </p>
                <p className="text-xs text-muted-foreground mt-1">Referral Bonus</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-4">
        <Dialog open={isDepositDialogOpen} onOpenChange={(open) => {
          setIsDepositDialogOpen(open);
          if (!open) {
            setGeneratedOrderId(null);
            setGeneratedAddress(null);
            setDepositAmount('');
            setDepositTxHash(null);
            setDepositNetwork(null);
            setDepositAmountWithFee('');
          }
        }}>
          <DialogTrigger asChild>
            <Button className="h-16 flex-col space-y-1 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90">
              <ArrowDownRight size={24} />
              <span>Deposit</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md mx-auto max-h-[90vh] overflow-y-auto bg-card border border-border/60 shadow-xl rounded-2xl">
            <DialogHeader className="pb-3 border-b border-border/60">
              <DialogTitle className="text-xl font-semibold flex items-center">
                <div className="mr-3 rounded-full p-2 border border-border/60 bg-card">
                  <ArrowDownRight size={20} className="text-primary" />
                </div>
                Deposit USDT
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-6 pt-2">
              {!generatedAddress && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="deposit-amount" className="text-sm font-medium text-white">Amount (USDT)</Label>
                    <Input
                      id="deposit-amount"
                      type="number"
                      placeholder={`Minimum: ${depositNetworks.find(n => n.value === selectedNetwork)?.min_amount || 10} USDT`}
                      value={depositAmount}
                      onChange={(e) => setDepositAmount(e.target.value)}
                      className="h-12 rounded-xl bg-card/60 border border-border/60 focus-visible:ring-1 focus-visible:ring-primary text-white"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="deposit-network" className="text-sm font-medium text-white">Network</Label>
                    <Select value={selectedNetwork} onValueChange={setSelectedNetwork}>
                      <SelectTrigger className="h-12 rounded-xl bg-card/60 border border-border/60 focus-visible:ring-1 focus-visible:ring-primary text-white">
                        <SelectValue placeholder="Select network" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border border-border/60 rounded-xl shadow-lg">
                        {depositNetworks.map((network) => (
                          <SelectItem key={network.value} value={network.value} className="focus:bg-muted/30 text-white">
                            {network.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <DepositEstimate amount={depositAmount} network={selectedNetwork} className="" />

                  <div className="rounded-2xl p-4 border border-border/60 bg-card/50">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-muted-foreground font-medium">Network:</span>
                      <span className="text-foreground font-semibold">{depositNetworks.find(n => n.value === selectedNetwork)?.label}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground font-medium">Static Fee:</span>
                      <span className="text-foreground font-semibold">{depositNetworks.find(n => n.value === selectedNetwork)?.fee}</span>
                    </div>
                  </div>
                </>
              )}

              {generatedAddress && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label className="text-sm text-white">Payment address</Label>
                    <div className="flex items-center justify-between rounded-xl border border-border/60 bg-card/60 px-3 py-2">
                      <span className="text-sm break-all pr-4 text-white">{generatedAddress}</span>
                      <Button variant="secondary" size="sm" onClick={() => copyToClipboard(generatedAddress!)} className="ml-3 flex-shrink-0">Copy</Button>
                    </div>
                  </div>

                  {/* Блок с суммой для отправки */}
                  <div className="rounded-xl border border-yellow-500/30 bg-yellow-500/10 p-4">
                    <div className="space-y-3">
                      <Label className="text-sm font-medium text-yellow-200">Amount to send</Label>
                      <div className="flex items-center justify-between rounded-lg border border-yellow-500/30 bg-card/60 px-3 py-2">
                        <span className="text-lg font-bold text-yellow-100">{depositAmountWithFee || depositAmount} USDT</span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => copyToClipboard(depositAmountWithFee || depositAmount)}
                          className="ml-3 flex-shrink-0 border-yellow-500/30 text-yellow-200 hover:bg-yellow-500/20"
                        >
                          Copy
                        </Button>
                      </div>
                      <p className="text-xs text-yellow-200/80 font-medium">
                        You must send amount not lower than those specified here.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Button onClick={handleCheckDeposit} disabled={isCheckingDeposit} className="flex-1">
                      {isCheckingDeposit ? <Loader2 className="mr-2 h-4 w-4 animate-spin"/> : null}
                      Check payment
                    </Button>
                    <Button
                      variant="ghost"
                      disabled={!depositTxHash || !depositNetwork}
                      onClick={() => {
                        if (depositTxHash && depositNetwork) {
                          const explorerUrl = getExplorerUrl(depositNetwork, depositTxHash);
                          if (explorerUrl) {
                            window.open(explorerUrl, '_blank');
                          }
                        }
                      }}
                    >
                      <ExternalLink className="h-4 w-4 mr-2"/>
                      {depositNetwork ? getExplorerName(depositNetwork) : 'Explorer'}
                    </Button>
                  </div>
                </div>
              )}

              <div className="flex gap-3 pt-2">
                <Button
                  variant="outline"
                  disabled={!!generatedAddress && cancelLockTime !== null}
                  onClick={() => {
                    setIsDepositDialogOpen(false);
                    setGeneratedOrderId(null);
                    setGeneratedAddress(null);
                    setDepositAmount('');
                    setDepositTxHash(null);
                    setDepositNetwork(null);
                    setDepositAmountWithFee('');
                  }}
                  className="flex-1 h-11 rounded-xl text-white border-white/20 hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {!!generatedAddress && cancelLockTime !== null ? `Cancel (${cancelLockTime}s)` : 'Cancel'}
                </Button>
                {!generatedAddress && (
                  <Button
                    onClick={handleDeposit}
                    disabled={isDepositLoading}
                    className="flex-1 h-11 rounded-xl bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    {isDepositLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Creating...
                      </>
                    ) : (
                      'Generate Address'
                    )}
                  </Button>
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={isWithdrawDialogOpen} onOpenChange={setIsWithdrawDialogOpen}>
          <DialogTrigger asChild>
            <Button
              className="h-16 flex-col space-y-1 rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={(e) => {
                if (!isVerified) {
                  e.preventDefault();
                  toast({
                    title: "Verification Required",
                    description: "You need to complete verification before making withdrawals. Please verify your identity first.",
                    variant: "destructive",
                  });
                }
              }}
            >
              <ArrowUpRight size={24} />
              <span>Withdraw</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md mx-auto max-h-[90vh] overflow-y-auto bg-card border border-border/60 shadow-xl rounded-2xl">
            <DialogHeader className="pb-3 border-b border-border/60">
              <DialogTitle className="text-xl font-semibold flex items-center">
                <div className="mr-3 rounded-full p-2 border border-border/60 bg-card">
                  <ArrowUpRight size={20} className="text-destructive" />
                </div>
                Withdraw USDT
              </DialogTitle>
            </DialogHeader>

            <div className="space-y-6 pt-2">
              <div className="space-y-2">
                <Label htmlFor="withdraw-amount" className="text-sm font-medium text-white">Amount (USDT)</Label>
                <Input
                  id="withdraw-amount"
                  type="number"
                  placeholder={`Minimum: ${withdrawNetworks.find(n => n.value === selectedNetwork)?.min_amount || 10} USDT`}
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  className="h-12 rounded-xl bg-card/60 border border-border/60 focus-visible:ring-1 focus-visible:ring-destructive text-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="withdraw-address" className="text-sm font-medium text-white">Wallet Address</Label>
                <Input
                  id="withdraw-address"
                  placeholder="Enter your wallet address"
                  value={withdrawAddress}
                  onChange={(e) => setWithdrawAddress(e.target.value)}
                  className="h-12 rounded-xl bg-card/60 border border-border/60 focus-visible:ring-1 focus-visible:ring-destructive text-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="withdraw-network" className="text-sm font-medium text-white">Network</Label>
                <Select value={selectedNetwork} onValueChange={setSelectedNetwork}>
                  <SelectTrigger className="h-12 rounded-xl bg-card/60 border border-border/60 focus-visible:ring-1 focus-visible:ring-destructive text-white">
                    <SelectValue placeholder="Select network" />
                  </SelectTrigger>
                  <SelectContent className="bg-card border border-border/60 rounded-xl shadow-lg">
                    {withdrawNetworks.map((network) => (
                      <SelectItem key={network.value} value={network.value} className="focus:bg-muted/30 text-white">
                        {network.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="rounded-2xl p-4 border border-border/60 bg-card/50">
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground font-medium">Amount:</span>
                  <span className="font-semibold text-white">{withdrawAmount || '0'} USDT</span>
                </div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-muted-foreground font-medium">Fee:</span>
                  <span className="font-semibold text-white">{(() => {
                    if (!withdrawAmount) return '0 USDT';
                    const amount = parseFloat(withdrawAmount);
                    const networkInfo = withdrawNetworks.find(n => n.value === selectedNetwork);
                    if (!networkInfo) return '0 USDT';
                    let totalFee = networkInfo.fee_fixed || 0;
                    if (networkInfo.fee_percent > 0) {
                      totalFee += amount * networkInfo.fee_percent;
                    }
                    return `${totalFee.toFixed(2)} USDT`;
                  })()}</span>
                </div>
                <div className="flex justify-between text-sm font-medium border-t border-border/60 pt-3">
                  <span className="text-muted-foreground">You will receive:</span>
                  <span className="text-destructive font-bold text-lg">{(() => {
                    if (!withdrawAmount) return '0';
                    const amount = parseFloat(withdrawAmount);
                    const networkInfo = withdrawNetworks.find(n => n.value === selectedNetwork);
                    if (!networkInfo) return amount.toFixed(2);
                    let totalFee = networkInfo.fee_fixed || 0;
                    if (networkInfo.fee_percent > 0) {
                      totalFee += amount * networkInfo.fee_percent;
                    }
                    return (amount - totalFee).toFixed(2);
                  })()} USDT</span>
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <Button
                  variant="outline"
                  onClick={() => setIsWithdrawDialogOpen(false)}
                  className="flex-1 h-11 rounded-xl text-white border-white/20 hover:bg-white/10"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleWithdraw}
                  disabled={isWithdrawLoading}
                  className="flex-1 h-11 rounded-xl bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  {isWithdrawLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    'Submit Withdrawal'
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Transaction History */}
      <Card className="border border-border/60 bg-card shadow-sm rounded-2xl overflow-hidden">
        <CardHeader className="pb-2">
          <CardTitle className="text-base font-semibold flex items-center">
            <div className="w-6 h-6 rounded-full bg-muted/40 flex items-center justify-center mr-2">
              <Clock size={14} className="text-primary" />
            </div>
            Transaction History
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 pt-2">
            {isTransactionsLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
                <span className="ml-2 text-muted-foreground">Loading transactions...</span>
              </div>
            ) : transactions.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No transactions yet</p>
              </div>
            ) : (
              transactions.map((tx) => (
                <div key={tx.id} className="flex items-center justify-between p-4 rounded-xl bg-card/60 border border-border/60">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center bg-muted/40">
                      {getTransactionIcon(tx.type)}
                    </div>
                    <div>
                      <p className="font-semibold">{getTransactionLabel(tx.type)}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(tx.date).toLocaleDateString()} {new Date(tx.date).toLocaleTimeString()}
                      </p>
                      {tx.type === 'admin_credit' || tx.type === 'admin_debit' ? (
                        tx.description && (
                          <p className="text-xs text-muted-foreground font-medium">
                            {tx.description}
                          </p>
                        )
                      ) : (
                        <p className="text-xs text-muted-foreground">{tx.network}</p>
                      )}
                    </div>
                  </div>

                  <div className="text-right">
                    <p className={`font-bold text-lg ${getTransactionAmountColor(tx.type)}`}>
                      {getTransactionAmountSign(tx.type)}{tx.amount.toFixed(2)} USDT
                    </p>
                    <div className="flex items-center space-x-2 justify-end mt-1">
                      <Badge variant="outline" className={`${getStatusColor(tx.status)} px-2 py-0.5`}>
                        {getStatusIcon(tx.status)}
                        <span className="ml-1 capitalize">{tx.status}</span>
                      </Badge>
                    </div>
                    {tx.tx_hash && (tx.type === 'deposit' || tx.type === 'withdrawal') && (
                      <div className="flex gap-1 mt-1.5">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(tx.tx_hash!)}
                          className="text-xs h-6 p-1 text-primary/80 hover:text-primary"
                        >
                          <Copy size={12} className="mr-1" />
                          Hash
                        </Button>
                        {isExplorerSupported(tx.network) && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              const explorerUrl = getExplorerUrl(tx.network, tx.tx_hash!);
                              if (explorerUrl) {
                                window.open(explorerUrl, '_blank');
                              }
                            }}
                            className="text-xs h-6 p-1 text-primary/80 hover:text-primary"
                          >
                            <ExternalLink size={12} className="mr-1" />
                            {getExplorerName(tx.network)}
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Error Dialog with Copy Functionality */}
      <ErrorDialog
        isOpen={errorDialog.isOpen}
        onClose={() => setErrorDialog(prev => ({ ...prev, isOpen: false }))}
        title={errorDialog.title}
        errorData={{
          error: errorDialog.error,
          details: errorDialog.details,
          debugInfo: errorDialog.debugInfo,
          timestamp: errorDialog.timestamp,
        }}
      />
    </div>
  );
}
