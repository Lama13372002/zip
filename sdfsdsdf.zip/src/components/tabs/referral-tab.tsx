'use client';

import { useState, useEffect } from 'react';
import { Users, Copy, Share, Gift, TrendingUp, ExternalLink } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { useTelegram } from '@/components/providers/telegram-provider';
import type { ApiResponse } from '@/types';

export function ReferralTab() {
  const { user } = useTelegram();
  const [referralLink, setReferralLink] = useState('');
  const [stats, setStats] = useState<null | {
    totalEarned: number;
    thisMonth: number;
    totalReferrals: number;
    level1: number;
    level2: number;
    level3: number;
    commissionRates: { level1: number; level2: number; level3: number };
  }>(null);
  const [referrals, setReferrals] = useState<Array<{ user_id: number; telegram_id: number; level: number; joinDate: string }>>([]);
  const [earnings, setEarnings] = useState<Array<{ id: number; amount: number; level: number; date: string; from_telegram_id: number }>>([]);
  const [teamInvestments, setTeamInvestments] = useState<null | {
    level1: { totalInvested: number; usersCount: number; investmentsCount: number };
    level2: { totalInvested: number; usersCount: number; investmentsCount: number };
    level3: { totalInvested: number; usersCount: number; investmentsCount: number };
    totalInvested: number;
    totalUsers: number;
    totalInvestments: number;
  }>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (!user?.id) return;
    const tgId = user.id;
    async function loadAll() {
      try {
        const [linkRes, statsRes, listRes, earnRes, teamInvRes] = await Promise.all([
          fetch(`/api/user/referral/link?telegram_id=${tgId}`),
          fetch(`/api/user/referral/stats?telegram_id=${tgId}`),
          fetch(`/api/user/referral/list?telegram_id=${tgId}`),
          fetch(`/api/user/referral/earnings?telegram_id=${tgId}`),
          fetch(`/api/user/referral/team-investments?telegram_id=${tgId}`),
        ]);

        if (linkRes.ok) {
          const d: ApiResponse<{ link: string; ref_code: string }> = await linkRes.json();
          if (d.success && d.data) setReferralLink(d.data.link);
        }
        if (statsRes.ok) {
          const d: ApiResponse<{
            totalEarned: number;
            thisMonth: number;
            totalReferrals: number;
            level1: number;
            level2: number;
            level3: number;
            commissionRates: { level1: number; level2: number; level3: number };
          }> = await statsRes.json();
          if (d.success && d.data) setStats(d.data);
        }
        if (listRes.ok) {
          const d: ApiResponse<Array<{ user_id: number; telegram_id: number; level: number; joinDate: string }>> = await listRes.json();
          if (d.success && d.data) setReferrals(d.data);
        }
        if (earnRes.ok) {
          const d: ApiResponse<Array<{ id: number; amount: number; level: number; date: string; from_telegram_id: number }>> = await earnRes.json();
          if (d.success && d.data) setEarnings(d.data);
        }
        if (teamInvRes.ok) {
          const d: ApiResponse<{
            level1: { totalInvested: number; usersCount: number; investmentsCount: number };
            level2: { totalInvested: number; usersCount: number; investmentsCount: number };
            level3: { totalInvested: number; usersCount: number; investmentsCount: number };
            totalInvested: number;
            totalUsers: number;
            totalInvestments: number;
          }> = await teamInvRes.json();
          if (d.success && d.data) setTeamInvestments(d.data);
        }
      } catch (e) {
        console.warn('Referral load error', e);
      }
    }
    loadAll();
  }, [user?.id]);

  const copyReferralLink = () => {
    navigator.clipboard.writeText(referralLink);
    toast({
      title: "Copied!",
      description: "Referral link copied to clipboard",
    });
  };

  const shareReferralLink = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join Quantum Investment',
          text: 'Start earning with AI-powered investments!',
          url: referralLink,
        });
      } catch (error) {
        copyReferralLink();
      }
    } else {
      copyReferralLink();
    }
  };

  const getLevelColor = (level: number) => {
    switch (level) {
      case 1:
        return 'text-primary border-primary/20 bg-primary/5';
      case 2:
        return 'text-warning border-warning/20 bg-warning/5';
      case 3:
        return 'text-purple-500 border-purple-500/20 bg-purple-500/5';
      default:
        return 'text-muted-foreground border-border';
    }
  };

  return (
    <div className="space-y-6">
      {/* Referral Stats Overview */}
      <Card className="balance-card glow-effect overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-primary/10 to-transparent opacity-30 -z-10"></div>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-bold text-white/95 flex items-center">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-2">
              <Gift size={16} className="text-primary" />
            </div>
            Referral Earnings
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="text-center pt-2">
              <p className="text-4xl font-bold text-primary quantum-glow tracking-wide">{stats?.totalEarned?.toFixed(2)} USDT</p>
              <p className="text-sm text-white/60 mt-1">Total Earned</p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 rounded-lg glass-card border border-white/5 hover:border-primary/30 hover:bg-primary/5 transition-all duration-300 group">
                <p className="text-lg font-bold text-primary quantum-glow">{stats?.thisMonth?.toFixed(2)} USDT</p>
                <p className="text-xs text-white/60 mt-1 group-hover:text-primary/80 transition-colors duration-300">This Month</p>
              </div>
              <div className="text-center p-4 rounded-lg glass-card border border-white/5 hover:border-primary/30 hover:bg-primary/5 transition-all duration-300 group">
                <p className="text-lg font-bold text-primary quantum-glow">{stats?.totalReferrals}</p>
                <p className="text-xs text-white/60 mt-1 group-hover:text-primary/80 transition-colors duration-300">Total Referrals</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Commission Structure */}
      <Card className="glass-card overflow-hidden">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-bold text-white/95 flex items-center">
            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center mr-2">
              <TrendingUp size={14} className="text-primary" />
            </div>
            Commission Structure
          </CardTitle>
          <p className="text-sm text-white/60 mt-1">Commission rates by level</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-5 pt-2">
            <div className="grid gap-4">
              <div className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-primary/10 to-transparent border border-primary/20 hover:border-primary/40 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 group">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary/70 text-primary-foreground flex items-center justify-center text-sm font-bold shadow-lg shadow-primary/20 group-hover:scale-110 transition-all duration-300">
                    1
                  </div>
                  <div>
                    <p className="font-bold text-white/90">Level 1</p>
                    <p className="text-sm text-white/60 group-hover:text-primary/80 transition-colors duration-300">{stats?.level1} referrals</p>
                  </div>
                </div>
                <Badge variant="outline" className="text-primary border-primary/30 bg-primary/5 px-3 py-1.5 text-base font-bold">
                  {stats?.commissionRates.level1.toFixed(2)}%
                </Badge>
              </div>

              <div className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-warning/10 to-transparent border border-warning/20 hover:border-warning/40 transition-all duration-300 hover:shadow-lg hover:shadow-warning/5 group">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-warning to-warning/70 text-warning-foreground flex items-center justify-center text-sm font-bold shadow-lg shadow-warning/20 group-hover:scale-110 transition-all duration-300">
                    2
                  </div>
                  <div>
                    <p className="font-bold text-white/90">Level 2</p>
                    <p className="text-sm text-white/60 group-hover:text-warning/80 transition-colors duration-300">{stats?.level2} referrals</p>
                  </div>
                </div>
                <Badge variant="outline" className="text-warning border-warning/30 bg-warning/5 px-3 py-1.5 text-base font-bold">
                  {stats?.commissionRates.level2.toFixed(2)}%
                </Badge>
              </div>

              <div className="flex items-center justify-between p-4 rounded-xl bg-gradient-to-r from-purple-500/10 to-transparent border border-purple-500/20 hover:border-purple-500/40 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/5 group">
                <div className="flex items-center space-x-4">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-purple-600/70 text-white flex items-center justify-center text-sm font-bold shadow-lg shadow-purple-500/20 group-hover:scale-110 transition-all duration-300">
                    3
                  </div>
                  <div>
                    <p className="font-bold text-white/90">Level 3</p>
                    <p className="text-sm text-white/60 group-hover:text-purple-400/80 transition-colors duration-300">{stats?.level3} referrals</p>
                  </div>
                </div>
                <Badge variant="outline" className="text-purple-400 border-purple-500/30 bg-purple-500/5 px-3 py-1.5 text-base font-bold">
                  {stats?.commissionRates.level3.toFixed(2)}%
                </Badge>
              </div>
            </div>

            <div className="bg-gradient-to-r from-primary/5 to-transparent rounded-xl p-4 border border-primary/10">
              <p className="text-sm text-white/80">
                Earn commission from the daily profits of your referrals and their referrals up to 3 levels deep!
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Team Investments Overview */}
      <Card className="balance-card glow-effect overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-purple-500/10 to-transparent opacity-30 -z-10"></div>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-bold text-white/95 flex items-center">
            <div className="w-8 h-8 rounded-full bg-purple-500/10 flex items-center justify-center mr-2">
              <TrendingUp size={16} className="text-purple-400" />
            </div>
            Team Investments
            <Badge variant="outline" className="ml-auto text-xs text-purple-400 border-purple-500/30 bg-purple-500/5">
              Live
            </Badge>
          </CardTitle>
          <p className="text-sm text-white/60 mt-1">Total investments of your referral network</p>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="text-center pt-2">
              <p className="text-4xl font-bold text-purple-400 quantum-glow tracking-wide">
                {teamInvestments?.totalInvested?.toFixed(2) || '0.00'} USDT
              </p>
              <p className="text-sm text-white/60 mt-1">Total Team Investments</p>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="text-center p-3 rounded-lg glass-card border border-white/5 hover:border-purple-400/30 hover:bg-purple-500/5 transition-all duration-300 group">
                <p className="text-lg font-bold text-purple-400 quantum-glow">
                  {teamInvestments?.level1?.totalInvested?.toFixed(2) || '0.00'}
                </p>
                <p className="text-xs text-white/60 mt-1 group-hover:text-purple-400/80 transition-colors duration-300">
                  Level 1
                </p>
                <p className="text-xs text-white/40 mt-0.5">
                  {teamInvestments?.level1?.usersCount || 0} users
                </p>
              </div>
              <div className="text-center p-3 rounded-lg glass-card border border-white/5 hover:border-purple-400/30 hover:bg-purple-500/5 transition-all duration-300 group">
                <p className="text-lg font-bold text-purple-400 quantum-glow">
                  {teamInvestments?.level2?.totalInvested?.toFixed(2) || '0.00'}
                </p>
                <p className="text-xs text-white/60 mt-1 group-hover:text-purple-400/80 transition-colors duration-300">
                  Level 2
                </p>
                <p className="text-xs text-white/40 mt-0.5">
                  {teamInvestments?.level2?.usersCount || 0} users
                </p>
              </div>
              <div className="text-center p-3 rounded-lg glass-card border border-white/5 hover:border-purple-400/30 hover:bg-purple-500/5 transition-all duration-300 group">
                <p className="text-lg font-bold text-purple-400 quantum-glow">
                  {teamInvestments?.level3?.totalInvested?.toFixed(2) || '0.00'}
                </p>
                <p className="text-xs text-white/60 mt-1 group-hover:text-purple-400/80 transition-colors duration-300">
                  Level 3
                </p>
                <p className="text-xs text-white/40 mt-0.5">
                  {teamInvestments?.level3?.usersCount || 0} users
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4 rounded-lg glass-card border border-white/5 hover:border-purple-400/30 hover:bg-purple-500/5 transition-all duration-300 group">
                <p className="text-lg font-bold text-purple-400 quantum-glow">{teamInvestments?.totalUsers || 0}</p>
                <p className="text-xs text-white/60 mt-1 group-hover:text-purple-400/80 transition-colors duration-300">
                  Total Users
                </p>
              </div>
              <div className="text-center p-4 rounded-lg glass-card border border-white/5 hover:border-purple-400/30 hover:bg-purple-500/5 transition-all duration-300 group">
                <p className="text-lg font-bold text-purple-400 quantum-glow">{teamInvestments?.totalInvestments || 0}</p>
                <p className="text-xs text-white/60 mt-1 group-hover:text-purple-400/80 transition-colors duration-300">
                  Total Investments
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-r from-purple-500/5 to-transparent rounded-xl p-4 border border-purple-500/10">
              <p className="text-sm text-white/80">
                Track your team's investment performance in real-time!
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Referral Link */}
      <Card className="glass-card shine-effect overflow-hidden">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-bold text-white/95 flex items-center">
            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center mr-2">
              <Share size={14} className="text-primary" />
            </div>
            Your Referral Link
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-5 pt-2">
            <div className="space-y-3">
              <Label htmlFor="referral-link" className="text-white/90 font-medium">Share this link to earn commissions</Label>
              <div className="flex space-x-2">
                <Input
                  id="referral-link"
                  value={referralLink}
                  readOnly
                  className="flex-1 border-white/10 bg-white/5 focus:border-primary/50 transition-all duration-300 h-12"
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={copyReferralLink}
                  className="h-12 w-12 border-white/10 bg-white/5 hover:bg-primary/10 hover:text-primary hover:border-primary/30 transition-all duration-300"
                >
                  <Copy size={18} />
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={copyReferralLink}
                variant="outline"
                className="h-12 rounded-xl border-white/10 hover:bg-white/5 hover:text-white transition-all duration-300"
              >
                <Copy size={18} className="mr-2" />
                Copy Link
              </Button>
              <Button
                onClick={shareReferralLink}
                className="promote-button h-12 rounded-xl"
              >
                <Share size={18} className="mr-2" />
                Share
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Referrals */}
      <Card className="glass-card overflow-hidden">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-bold text-white/95 flex items-center">
            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center mr-2">
              <Users size={14} className="text-primary" />
            </div>
            Your Referrals
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 pt-2">
            {referrals.map((referral) => (
              <div key={referral.telegram_id} className="flex items-center justify-between p-4 rounded-lg glass-card border border-white/5 hover:border-primary/20 transition-all duration-300 group">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center shadow-lg shadow-primary/10 group-hover:scale-110 transition-all duration-300">
                    <Users size={22} className="text-primary" />
                  </div>
                  <div>
                    <p className="font-bold text-white/90">{referral.telegram_id}</p>
                    <p className="text-sm text-white/60 group-hover:text-primary/70 transition-colors duration-300">Joined {referral.joinDate}</p>
                    {/* <p className="text-xs text-white/50">Invested: {referral.investment} USDT</p> */}
                  </div>
                </div>

                <div className="text-right">
                  {/* <p className="font-bold text-lg text-primary quantum-glow">+{referral.earnings} USDT</p> */}
                  <Badge variant="outline" className={`${getLevelColor(referral.level)} px-2 py-0.5 group-hover:bg-white/5 transition-all duration-300`}>
                    Level {referral.level}
                  </Badge>
                  {/* <p className="text-xs text-primary mt-1 opacity-80 group-hover:opacity-100 transition-opacity duration-300">{referral.status}</p> */}
                </div>
              </div>
            ))}

            {referrals.length === 0 && (
              <div className="text-center py-10">
                <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mx-auto mb-4">
                  <Users size={32} className="text-primary/70" />
                </div>
                <p className="text-white/80 font-medium">No referrals yet</p>
                <p className="text-sm text-white/60 mt-1">Share your link to start earning!</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Recent Earnings */}
      <Card className="glass-card overflow-hidden">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-bold text-white/95 flex items-center">
            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center mr-2">
              <Gift size={14} className="text-primary" />
            </div>
            Recent Earnings
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 pt-2">
            {earnings.map((earning) => (
              <div key={earning.id} className="flex items-center justify-between p-4 rounded-lg glass-card border border-white/5 hover:border-primary/20 transition-all duration-300 group">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center shadow-lg shadow-primary/10 group-hover:scale-110 transition-all duration-300">
                    <TrendingUp size={22} className="text-primary" />
                  </div>
                  <div>
                    <p className="font-bold text-white/90">From {earning.from_telegram_id}</p>
                    {/* <p className="text-sm text-white/60 group-hover:text-primary/70 transition-colors duration-300">{earning.type}</p> */}
                    <p className="text-xs text-white/50">{earning.date}</p>
                  </div>
                </div>

                <div className="text-right">
                  <p className="font-bold text-lg text-primary quantum-glow">+{earning.amount?.toFixed(2)} USDT</p>
                  <Badge variant="outline" className={`${getLevelColor(earning.level)} px-2 py-0.5 group-hover:bg-white/5 transition-all duration-300`}>
                    Level {earning.level}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
