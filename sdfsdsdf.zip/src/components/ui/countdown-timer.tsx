'use client';

import { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';

interface CountdownTimerProps {
  createdAt: string; // ISO timestamp when investment was created
  className?: string;
}

export function CountdownTimer({ createdAt, className = '' }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState({
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date();
      const created = new Date(createdAt);

      // Calculate how many full 24-hour periods have passed
      const hoursSinceCreated = (now.getTime() - created.getTime()) / (1000 * 60 * 60);
      const fullDaysPassed = Math.floor(hoursSinceCreated / 24);

      // Calculate next 24-hour mark from creation time
      const nextAccrualTime = new Date(created.getTime() + ((fullDaysPassed + 1) * 24 * 60 * 60 * 1000));

      const difference = nextAccrualTime.getTime() - now.getTime();

      if (difference > 0) {
        const hours = Math.floor(difference / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        setTimeLeft({ hours, minutes, seconds });
      } else {
        setTimeLeft({ hours: 0, minutes: 0, seconds: 0 });
      }
    };

    // Calculate immediately
    calculateTimeLeft();

    // Update every second
    const interval = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(interval);
  }, [createdAt]);

  const formatTime = (value: number) => value.toString().padStart(2, '0');

  return (
    <div className={`flex items-center text-sm text-white/60 bg-gradient-to-r from-primary/5 to-transparent p-2 rounded-lg ${className}`}>
      <Clock size={14} className="mr-1.5 text-primary/80" />
      <span className="mr-2">Next accrual in:</span>
      <div className="flex items-center space-x-1 font-mono text-primary font-medium">
        <span>{formatTime(timeLeft.hours)}</span>
        <span className="animate-pulse">:</span>
        <span>{formatTime(timeLeft.minutes)}</span>
        <span className="animate-pulse">:</span>
        <span>{formatTime(timeLeft.seconds)}</span>
      </div>
    </div>
  );
}
