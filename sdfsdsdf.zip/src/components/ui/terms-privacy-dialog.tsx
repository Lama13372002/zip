'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

import { FileText, Shield } from 'lucide-react';

interface TermsPrivacyDialogProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TermsPrivacyDialog({ isOpen, onClose }: TermsPrivacyDialogProps) {
  const [activeTab, setActiveTab] = useState('terms');

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[75vh] w-[90vw]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText size={24} className="text-primary" />
            Legal Documents
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="terms" className="flex items-center gap-2">
              <FileText size={16} />
              Terms of Service
            </TabsTrigger>
            <TabsTrigger value="privacy" className="flex items-center gap-2">
              <Shield size={16} />
              Privacy Policy
            </TabsTrigger>
          </TabsList>

          <TabsContent value="terms" className="mt-6">
            <div className="h-[45vh] overflow-y-auto pr-4 scrollbar-thin scrollbar-thumb-white/20 scrollbar-track-transparent">
              <div className="space-y-6 text-white/90">
                <div>
                  <h3 className="text-lg font-bold text-primary mb-3">Terms of Service</h3>
                  <p className="text-sm text-white/70 mb-4">Last updated: August 30, 2025</p>
                </div>

                <section>
                  <h4 className="font-semibold text-white mb-2">1. Acceptance of Terms</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    By accessing and using Quantum xAI investment platform ("Service"), you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to abide by the above, please do not use this service.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">2. Service Description</h4>
                  <p className="text-sm text-white/80 leading-relaxed mb-2">
                    Quantum xAI is an investment platform that provides:
                  </p>
                  <ul className="text-sm text-white/80 leading-relaxed ml-4 space-y-1">
                    <li>• Investment opportunities</li>
                    <li>• Investment products</li>
                    <li>• Portfolio management tools</li>
                    <li>• Referral and earnings programs</li>
                  </ul>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">3. Investment Risks</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    All investments carry inherent risks, including the possibility of losing principal. Past performance does not guarantee future results. You should carefully assess your financial situation and risk tolerance before making any investment decisions.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">4. User Eligibility</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    You must be at least 18 years old and legally capable of entering into binding contracts. You must complete our KYC (Know Your Customer) verification process before accessing certain features. Users from restricted jurisdictions may not be able to use all services.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">5. Account Security</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    You are responsible for maintaining the confidentiality of your account credentials. You must immediately notify us of any unauthorized use of your account. We are not liable for any losses resulting from unauthorized access to your account due to your negligence.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">6. Deposits and Withdrawals</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    All deposits and withdrawals are subject to our verification procedures and applicable fees. Withdrawal requests may take up to 24-48 hours to process. We reserve the right to request additional verification before processing large transactions.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">7. Prohibited Activities</h4>
                  <p className="text-sm text-white/80 leading-relaxed mb-2">
                    Users are prohibited from:
                  </p>
                  <ul className="text-sm text-white/80 leading-relaxed ml-4 space-y-1">
                    <li>• Money laundering or financing terrorism</li>
                    <li>• Using the platform for illegal activities</li>
                    <li>• Attempting to manipulate or exploit system vulnerabilities</li>
                    <li>• Creating multiple accounts to abuse referral programs</li>
                    <li>• Providing false or misleading information</li>
                  </ul>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">8. Service Availability</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    We strive to maintain service availability but do not guarantee uninterrupted access. The platform may be temporarily unavailable due to maintenance, technical issues, or other factors beyond our control.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">9. Limitation of Liability</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    Our liability is limited to the maximum extent permitted by law. We are not liable for any indirect, incidental, special, or consequential damages arising from your use of the service or any investment losses incurred.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">10. Governing Law</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    These terms are governed by and construed in accordance with applicable laws. Any disputes will be resolved through binding arbitration in accordance with the rules of the jurisdiction where our company is incorporated.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">11. Changes to Terms</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    We reserve the right to modify these terms at any time. Users will be notified of significant changes via email or platform notifications. Continued use of the service after changes constitutes acceptance of the new terms.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">12. Contact Information</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    For questions about these terms, please contact our support team through the Help Center in the application.
                  </p>
                </section>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="privacy" className="mt-6">
            <div className="h-[45vh] overflow-y-auto pr-4 scrollbar-thin scrollbar-thumb-white/20 scrollbar-track-transparent">
              <div className="space-y-6 text-white/90">
                <div>
                  <h3 className="text-lg font-bold text-primary mb-3">Privacy Policy</h3>
                  <p className="text-sm text-white/70 mb-4">Last updated: August 30, 2025</p>
                </div>

                <section>
                  <h4 className="font-semibold text-white mb-2">1. Information We Collect</h4>
                  <p className="text-sm text-white/80 leading-relaxed mb-2">
                    We collect the following types of information:
                  </p>
                  <ul className="text-sm text-white/80 leading-relaxed ml-4 space-y-1">
                    <li>• Personal identification information</li>
                    <li>• Financial information</li>
                    <li>• Technical information</li>
                    <li>• KYC verification documents</li>
                    <li>• Communication records</li>
                  </ul>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">2. How We Use Your Information</h4>
                  <p className="text-sm text-white/80 leading-relaxed mb-2">
                    Your information is used to:
                  </p>
                  <ul className="text-sm text-white/80 leading-relaxed ml-4 space-y-1">
                    <li>• Provide and maintain our investment services</li>
                    <li>• Process transactions and verify your identity</li>
                    <li>• Comply with legal and regulatory requirements</li>
                    <li>• Improve our platform and user experience</li>
                    <li>• Send important updates and security notifications</li>
                    <li>• Provide customer support and respond to inquiries</li>
                  </ul>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">3. Information Sharing</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    We do not sell your personal information. We may share your information with trusted third-party service providers who assist us in operating our platform, conducting business, or providing services to you. We may also disclose information when required by law or to protect our rights and safety.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">4. Data Security</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    We implement industry-standard security measures to protect your personal information, including encryption, secure servers, and regular security audits. However, no method of transmission over the internet is 100% secure, and we cannot guarantee absolute security.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">5. Data Retention</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    We retain your personal information for as long as necessary to provide our services and comply with legal obligations. KYC documents and transaction records may be retained for extended periods as required by financial regulations.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">6. Your Rights</h4>
                  <p className="text-sm text-white/80 leading-relaxed mb-2">
                    Depending on your jurisdiction, you may have the right to:
                  </p>
                  <ul className="text-sm text-white/80 leading-relaxed ml-4 space-y-1">
                    <li>• Access your personal information</li>
                    <li>• Correct inaccurate or incomplete information</li>
                    <li>• Request deletion of your information (subject to legal requirements)</li>
                    <li>• Object to or restrict processing of your information</li>
                    <li>• Data portability (receive a copy of your information)</li>
                  </ul>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">7. Cookies and Tracking</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    We use cookies and similar technologies to analyze usage patterns and improve our services.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">8. Third-Party Services</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    Our platform integrates with third-party services for payment processing, KYC verification, and analytics. These services have their own privacy policies, and we encourage you to review them.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">9. International Transfers</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    Your information may be transferred to and processed in countries other than your country of residence. We ensure appropriate safeguards are in place to protect your information during international transfers.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">10. Children's Privacy</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    Our services are not intended for individuals under 18 years of age. We do not knowingly collect personal information from children under 18. If you become aware that a child has provided us with personal information, please contact us immediately.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">11. Changes to Privacy Policy</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    We may update this privacy policy from time to time. We will notify you of any material changes by posting the updated policy on our platform and sending notifications to registered users.
                  </p>
                </section>

                <section>
                  <h4 className="font-semibold text-white mb-2">12. Contact Us</h4>
                  <p className="text-sm text-white/80 leading-relaxed">
                    If you have any questions about this privacy policy or our data practices, please contact our support team through the Help Center in the application or send us a message through the platform.
                  </p>
                </section>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
