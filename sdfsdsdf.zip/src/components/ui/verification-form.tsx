'use client';

import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Upload, Camera, FileImage, CheckCircle, AlertCircle, User, Calendar, CreditCard } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface VerificationFormProps {
  userId: string;
  onSubmitSuccess: () => void;
  onCancel: () => void;
}

interface UploadedFile {
  file: File;
  preview: string;
}

export function VerificationForm({ userId, onSubmitSuccess, onCancel }: VerificationFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form data
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    documentType: '',
    documentNumber: ''
  });

  // File uploads
  const [documentFront, setDocumentFront] = useState<UploadedFile | null>(null);
  const [documentBack, setDocumentBack] = useState<UploadedFile | null>(null);
  const [selfie, setSelfie] = useState<UploadedFile | null>(null);

  const frontInputRef = useRef<HTMLInputElement>(null);
  const backInputRef = useRef<HTMLInputElement>(null);
  const selfieInputRef = useRef<HTMLInputElement>(null);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleFileUpload = (
    file: File,
    setFile: React.Dispatch<React.SetStateAction<UploadedFile | null>>,
    type: string
  ) => {
    if (!file.type.startsWith('image/')) {
      toast({
        title: 'Invalid file type',
        description: 'Please upload an image file',
        variant: 'destructive'
      });
      return;
    }

    if (file.size > 10 * 1024 * 1024) { // 10MB limit
      toast({
        title: 'File too large',
        description: 'Please upload a file smaller than 10MB',
        variant: 'destructive'
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setFile({
        file,
        preview: reader.result as string
      });
      toast({
        title: 'File uploaded',
        description: `${type} uploaded successfully`,
      });
    };
    reader.readAsDataURL(file);
  };

  const uploadToServer = async (file: File, type: string): Promise<string> => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('type', type);
    formData.append('userId', userId);

    const response = await fetch('/api/verification/upload', {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Failed to upload file');
    }

    const data = await response.json();
    return data.url;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!documentFront || !selfie) {
      toast({
        title: 'Missing files',
        description: 'Please upload document front and selfie',
        variant: 'destructive'
      });
      return;
    }

    if (formData.documentType === 'passport' && !documentBack) {
      // For some document types, back might not be required
    }

    setIsSubmitting(true);

    try {
      // Upload files
      const documentFrontUrl = await uploadToServer(documentFront.file, 'document-front');
      const selfieUrl = await uploadToServer(selfie.file, 'selfie');
      const documentBackUrl = documentBack ? await uploadToServer(documentBack.file, 'document-back') : null;

      // Submit verification
      const response = await fetch('/api/verification/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId,
          firstName: formData.firstName,
          lastName: formData.lastName,
          dateOfBirth: formData.dateOfBirth,
          documentType: formData.documentType,
          documentNumber: formData.documentNumber,
          documentFrontUrl,
          documentBackUrl,
          selfieUrl,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to submit verification');
      }

      toast({
        title: 'Verification submitted',
        description: 'Your documents have been submitted for review',
      });

      onSubmitSuccess();
    } catch (error) {
      toast({
        title: 'Submission failed',
        description: error instanceof Error ? error.message : 'Please try again',
        variant: 'destructive'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const FileUploadCard = ({
    title,
    description,
    file,
    onUpload,
    inputRef,
    icon: Icon,
    required = true
  }: {
    title: string;
    description: string;
    file: UploadedFile | null;
    onUpload: () => void;
    inputRef: React.RefObject<HTMLInputElement>;
    icon: React.ElementType;
    required?: boolean;
  }) => (
    <Card className="glass-card border-white/10 hover:border-primary/20 transition-all duration-300">
      <CardContent className="p-4">
        <div className="flex items-center space-x-3 mb-3">
          <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
            <Icon size={16} className="text-primary" />
          </div>
          <div>
            <h4 className="font-medium text-white/90">{title}</h4>
            <p className="text-xs text-white/60">{description}</p>
          </div>
        </div>

        {!file ? (
          <Button
            onClick={onUpload}
            variant="outline"
            className="w-full h-20 border-dashed border-white/20 hover:border-primary/40 hover:bg-primary/5 transition-all duration-300"
          >
            <div className="text-center">
              <Upload size={20} className="mx-auto mb-1 text-primary" />
              <span className="text-sm text-white/80">Click to upload</span>
            </div>
          </Button>
        ) : (
          <div className="space-y-2">
            <div className="relative">
              <img
                src={file.preview}
                alt={title}
                className="w-full h-20 object-cover rounded-lg border border-white/10"
              />
              <div className="absolute top-1 right-1 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                <CheckCircle size={14} className="text-white" />
              </div>
            </div>
            <Button
              onClick={onUpload}
              variant="outline"
              size="sm"
              className="w-full border-white/20 hover:border-primary/40"
            >
              Replace
            </Button>
          </div>
        )}

        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            const selectedFile = e.target.files?.[0];
            if (selectedFile) {
              handleFileUpload(selectedFile,
                title.includes('Front') ? setDocumentFront :
                title.includes('Back') ? setDocumentBack : setSelfie,
                title
              );
            }
          }}
        />
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="glass-card border-white/10">
        <CardHeader className="text-center">
          <CardTitle className="text-xl font-bold text-white/95 flex items-center justify-center">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center mr-2">
              <User size={18} className="text-primary" />
            </div>
            Identity Verification
          </CardTitle>
          <p className="text-sm text-white/60 mt-2">
            Please provide your personal information and upload the required documents
          </p>
        </CardHeader>
      </Card>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Personal Information */}
        <Card className="glass-card border-white/10">
          <CardHeader>
            <CardTitle className="text-lg font-bold text-white/95 flex items-center">
              <User size={16} className="text-primary mr-2" />
              Personal Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName" className="text-white/80">First Name *</Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => handleInputChange('firstName', e.target.value)}
                  className="bg-white/5 border-white/10 text-white"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName" className="text-white/80">Last Name *</Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => handleInputChange('lastName', e.target.value)}
                  className="bg-white/5 border-white/10 text-white"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="dateOfBirth" className="text-white/80 flex items-center">
                <Calendar size={14} className="mr-1" />
                Date of Birth *
              </Label>
              <Input
                id="dateOfBirth"
                type="date"
                value={formData.dateOfBirth}
                onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
                className="bg-white/5 border-white/10 text-white"
                required
              />
            </div>
          </CardContent>
        </Card>

        {/* Document Information */}
        <Card className="glass-card border-white/10">
          <CardHeader>
            <CardTitle className="text-lg font-bold text-white/95 flex items-center">
              <CreditCard size={16} className="text-primary mr-2" />
              Document Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="documentType" className="text-white/80">Document Type *</Label>
              <Select value={formData.documentType} onValueChange={(value) => handleInputChange('documentType', value)}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue placeholder="Select document type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="passport">Passport</SelectItem>
                  <SelectItem value="id_card">National ID Card</SelectItem>
                  <SelectItem value="drivers_license">Driver's License</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="documentNumber" className="text-white/80">Document Number *</Label>
              <Input
                id="documentNumber"
                value={formData.documentNumber}
                onChange={(e) => handleInputChange('documentNumber', e.target.value)}
                className="bg-white/5 border-white/10 text-white"
                placeholder="Enter document number"
                required
              />
            </div>
          </CardContent>
        </Card>

        {/* Document Upload */}
        <Card className="glass-card border-white/10">
          <CardHeader>
            <CardTitle className="text-lg font-bold text-white/95 flex items-center">
              <FileImage size={16} className="text-primary mr-2" />
              Document Upload
            </CardTitle>
            <p className="text-sm text-white/60">
              Please upload clear, high-quality photos of your documents
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FileUploadCard
                title="Document Front"
                description="Front side of your document"
                file={documentFront}
                onUpload={() => frontInputRef.current?.click()}
                inputRef={frontInputRef}
                icon={FileImage}
              />

              {formData.documentType !== 'passport' && (
                <FileUploadCard
                  title="Document Back"
                  description="Back side of your document"
                  file={documentBack}
                  onUpload={() => backInputRef.current?.click()}
                  inputRef={backInputRef}
                  icon={FileImage}
                  required={false}
                />
              )}
            </div>

            <FileUploadCard
              title="Selfie Photo"
              description="Clear photo of yourself"
              file={selfie}
              onUpload={() => selfieInputRef.current?.click()}
              inputRef={selfieInputRef}
              icon={Camera}
            />
          </CardContent>
        </Card>

        {/* Submit Section */}
        <Card className="glass-card border-white/10">
          <CardContent className="p-6">
            <div className="flex items-center space-x-2 mb-4">
              <AlertCircle size={16} className="text-primary" />
              <p className="text-sm text-white/70">
                Please ensure all information is accurate and documents are clear and legible.
              </p>
            </div>

            <div className="flex space-x-3">
              <Button
                type="button"
                variant="outline"
                onClick={onCancel}
                className="flex-1 border-white/20 hover:border-white/40"
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Submitting...' : 'Submit for Review'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}
