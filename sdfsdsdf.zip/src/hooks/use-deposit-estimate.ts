import { useState, useEffect, useCallback } from 'react';

interface FeeEstimate {
  network: string;
  requested_amount: number;
  pay_amount: number;
  received_amount: number;
  fees: {
    nowpayments_fee?: {
      amount: number;
      percent: number;
    };
    network_fee?: {
      amount: number;
      percent: number;
    };
    total_fee: {
      amount: number;
      percent: number;
    };
  };
  payment_details: {
    currency: string;
    expires_at?: string;
    valid_until?: string;
    network_name: string;
  };
  estimated?: boolean;
  note?: string;
}

interface UseDepositEstimateResult {
  estimate: FeeEstimate | null;
  isLoading: boolean;
  error: string | null;
  fetchEstimate: (amount: string, network: string) => void;
}

export function useDepositEstimate(): UseDepositEstimateResult {
  const [estimate, setEstimate] = useState<FeeEstimate | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchEstimate = useCallback(async (amount: string, network: string) => {
    const numAmount = parseFloat(amount);

    // Сброс состояния если сумма невалидна
    if (!amount || amount.trim() === '' || isNaN(numAmount) || numAmount <= 0) {
      setEstimate(null);
      setError(null);
      setIsLoading(false);
      return;
    }

    // Не делаем запрос для очень маленьких сумм
    if (numAmount < 1) {
      setEstimate(null);
      setError(null);
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);
      setError(null);

      const response = await fetch(`/api/deposits/estimate?amount=${encodeURIComponent(amount)}&network=${encodeURIComponent(network)}`);
      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Failed to get estimate');
      }

      if (result.success) {
        setEstimate(result.data);
      } else {
        throw new Error(result.error || 'Invalid response');
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to get estimate';
      setError(errorMessage);
      setEstimate(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return {
    estimate,
    isLoading,
    error,
    fetchEstimate
  };
}
