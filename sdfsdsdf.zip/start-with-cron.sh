#!/bin/bash

echo "🚀 Starting TMA application with cron..."

# Запускаем приложение в фоне
bun start &
APP_PID=$!

echo "📦 Application started with PID: $APP_PID"

# Ждем 10 секунд для полного запуска
sleep 10

# Инициализируем cron задачи
echo "📅 Initializing cron jobs..."
curl -X POST http://localhost:3000/api/cron/init \
  -H "Content-Type: application/json" \
  -H "User-Agent: Internal-Startup"

if [ $? -eq 0 ]; then
    echo "✅ Cron initialized successfully"
else
    echo "❌ Failed to initialize cron"
fi

# Ждем завершения основного процесса
wait $APP_PID
