const https = require('https');

const data = JSON.stringify({
  email: 'karakul234123@mail.ru',
  password: 'Ghost1337@'
});

const options = {
  hostname: 'api.nowpayments.io',
  port: 443,
  path: '/v1/auth',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': data.length
  }
};

console.log('🔑 Тестируем JWT авторизацию...');

const req = https.request(options, (res) => {
  console.log('✅ Status Code:', res.statusCode);
  let responseBody = '';

  res.on('data', (chunk) => {
    responseBody += chunk;
  });

  res.on('end', () => {
    console.log('📥 Response:', responseBody);
    if (res.statusCode === 200) {
      try {
        const parsed = JSON.parse(responseBody);
        if (parsed.token) {
          console.log('🎉 JWT получен успешно!');
          console.log('Token preview:', parsed.token.substring(0, 50) + '...');
        }
      } catch (e) {
        console.log('Response not JSON');
      }
    } else {
      console.log('❌ Ошибка авторизации');
    }
  });
});

req.on('error', (error) => {
  console.error('❌ Connection Error:', error.message);
  console.log('💡 Возможные причины:');
  console.log('• Блокировка сети/firewall');
  console.log('• DNS проблема');
  console.log('• SSL сертификат');
});

req.write(data);
req.end();
