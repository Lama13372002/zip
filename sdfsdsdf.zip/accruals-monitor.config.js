module.exports = {
  apps: [
    {
      name: 'accruals-monitor',
      script: 'accruals-monitor.js',
      cwd: process.cwd(),
      env: {
        NODE_ENV: 'production',
        // URL приложения для API запросов
        NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL || 'http://localhost:3000'
      },
      instances: 1, // Важно: только один экземпляр для избежания дублирования начислений
      exec_mode: 'fork',
      max_memory_restart: '128M',
      listen_timeout: 15000,
      kill_timeout: 15000,
      out_file: './.pm2/accruals-monitor-out.log',
      error_file: './.pm2/accruals-monitor-error.log',
      merge_logs: true,
      autorestart: true,
      watch: false,
      restart_delay: 10000, // 10 секунд задержка перед перезапуском
      max_restarts: 10,
      min_uptime: '60s', // минимум 1 минута работы для стабильности
      exp_backoff_restart_delay: 100,
      // Мониторинг и алерты
      pmx: true,
      // Переменные окружения
      env_production: {
        NODE_ENV: 'production',
        NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL || process.env.APP_URL || 'http://localhost:3000'
      }
    }
  ]
};
