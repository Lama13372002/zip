#!/usr/bin/env bash
set -euo pipefail

# Deploy Next.js TMA app with Bun + PM2, using existing files in current directory.
# Requirements:
# - Run with sudo/root
# - .env already present in project root
# - Nginx/SSL already configured to proxy to PORT (default 3000)

APP_NAME="tma-app"
DOMAIN="quantumfintech.ai"
APP_USER="www-data"
APP_GROUP="www-data"
NODE_PORT="3000"
WORK_DIR="$(pwd)"

log() { echo -e "[deploy] $1"; }

if [[ ${EUID:-0} -ne 0 ]]; then
  echo "Run this script with sudo or as root."; exit 1
fi

log "System deps"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y curl ca-certificates gnupg

log "Install Bun if missing"
if ! command -v bun >/dev/null 2>&1; then
  curl -fsSL https://bun.sh/install | bash
  echo 'export PATH="/root/.bun/bin:$PATH"' > /etc/profile.d/bun.sh
  chmod +x /etc/profile.d/bun.sh
  export PATH="/root/.bun/bin:$PATH"
else
  export PATH="/root/.bun/bin:$PATH"
fi

log "Install Node.js LTS and PM2 if missing"
if ! command -v node >/dev/null 2>&1; then
  curl -fsSL https://deb.nodesource.com/setup_lts.x | bash -
  apt-get install -y nodejs
fi
if ! command -v pm2 >/dev/null 2>&1; then
  npm i -g pm2
fi

log "Ensure ownership for runtime (optional)"
chown -R "$APP_USER:$APP_GROUP" "$WORK_DIR" || true

log "Install deps with Bun"
cd "$WORK_DIR"
if [[ -f bun.lock || -f bun.lockb ]]; then
  bun install --frozen-lockfile || bun install
else
  bun install
fi

log "Build Next.js"
# Prefer package script if provided
if grep -q '"build"' package.json; then
  bun run build
else
  bunx next build
fi

log "Create PM2 ecosystem and start"
ECOSYSTEM_FILE="ecosystem.config.cjs"
cat > "$ECOSYSTEM_FILE" <<'EOF'
module.exports = {
  apps: [
    {
      name: process.env.APP_NAME || 'tma-app',
      script: 'bun',
      args: 'run start',
      cwd: process.env.WORK_DIR || process.cwd(),
      env: {
        PORT: process.env.NODE_PORT || '3000',
        NODE_ENV: 'production',
      },
      instances: 1,
      exec_mode: 'fork',
      max_memory_restart: '512M',
      listen_timeout: 10000,
      kill_timeout: 5000,
      out_file: './.pm2/out.log',
      error_file: './.pm2/error.log',
      merge_logs: true,
      autorestart: true,
      watch: false,
    },
  ],
};
EOF

export APP_NAME
export WORK_DIR
export NODE_PORT

# Stop existing app if running
if pm2 list | grep -q "$APP_NAME"; then
  pm2 delete "$APP_NAME" || true
fi

pm2 start "$ECOSYSTEM_FILE" --only "$APP_NAME" || pm2 start "$ECOSYSTEM_FILE"
pm2 save
pm2 startup systemd -u root --hp /root >/dev/null 2>&1 || true

log "Health check"
set +e
for i in {1..20}; do
  sleep 1
  code=$(curl -sk -o /dev/null -w "%{http_code}" "http://127.0.0.1:${NODE_PORT}")
  if [[ "$code" =~ ^(200|3[0-9][0-9])$ ]]; then
    log "App responded with HTTP $code on :${NODE_PORT}"; break
  fi
  log "Waiting app... attempt $i"
done
set -e

log "Done. Ensure Nginx proxies to 127.0.0.1:${NODE_PORT}. Access: https://${DOMAIN}/"
