const { Client } = require('pg');

const connectionString = 'postgresql://neondb_owner:npg_fF4I9MdHpEKB@ep-bold-haze-aem3duzs-pooler.c-2.us-east-2.aws.neon.tech/neondb?sslmode=require&channel_binding=require';

// Добавляем флаг для предотвращения одновременного выполнения
let isProcessing = false;
let processStartTime = null;

// Функция обработки confirmed депозитов
async function processConfirmedDeposits() {
  // Защита от одновременного выполнения
  if (isProcessing) {
    console.log(`⏳ [${new Date().toISOString()}] Обработка уже выполняется (запущена ${new Date(processStartTime).toISOString()})`);
    return { processed: 0, success: true, skipped: true };
  }

  isProcessing = true;
  processStartTime = Date.now();

  const client = new Client({ connectionString });

  try {
    await client.connect();

    // Устанавливаем блокировку уровня advisory lock для предотвращения race conditions
    await client.query('SELECT pg_advisory_lock(12345)');

    await client.query('BEGIN');

    // Более надежный запрос с дополнительной проверкой
    const unprocessedDeposits = await client.query(`
      SELECT d.*
      FROM deposits d
      WHERE d.status = 'confirmed'
      AND d.id NOT IN (
        SELECT DISTINCT related_deposit_id
        FROM ledger_entries
        WHERE related_deposit_id IS NOT NULL
        AND entry_type = 'deposit_in'
      )
      -- Дополнительная защита: не обрабатываем депозиты созданные менее 10 секунд назад
      AND d.created_at < NOW() - INTERVAL '10 seconds'
      ORDER BY d.created_at ASC
      FOR UPDATE SKIP LOCKED
    `);

    if (unprocessedDeposits.rows.length === 0) {
      await client.query('COMMIT');
      await client.query('SELECT pg_advisory_unlock(12345)');
      return { processed: 0, success: true };
    }

    console.log(`💰 [${new Date().toISOString()}] Найдено ${unprocessedDeposits.rows.length} необработанных депозитов`);

    let processedCount = 0;
    let errors = [];

    for (const deposit of unprocessedDeposits.rows) {
      try {
        const amountToCredit = parseFloat(String(deposit.desired_amount || deposit.amount));
        const idempotencyKey = `auto_deposit_${deposit.id}_v2`;

        // Проверяем, что такой idempotency_key еще не существует
        const existingEntry = await client.query(`
          SELECT id FROM ledger_entries
          WHERE idempotency_key = $1
        `, [idempotencyKey]);

        if (existingEntry.rows.length > 0) {
          console.log(`⚠️ Депозит ${deposit.id} уже обработан (найден idempotency_key: ${idempotencyKey})`);
          continue;
        }

        await client.query(`
          INSERT INTO users_balance (user_id, currency, available, bonus, locked, updated_at)
          VALUES ($1, $2, $3, 0, 0, NOW())
          ON CONFLICT (user_id, currency)
          DO UPDATE SET
            available = users_balance.available + $3,
            updated_at = NOW()
        `, [deposit.user_id, deposit.currency, amountToCredit]);

        await client.query(`
          INSERT INTO ledger_entries (
            user_id, currency, entry_type, amount, balance_available_delta,
            balance_bonus_delta, balance_locked_delta, related_deposit_id,
            idempotency_key, created_at
          ) VALUES ($1, $2, 'deposit_in', $3, $3, 0, 0, $4, $5, NOW())
        `, [
          deposit.user_id, deposit.currency, amountToCredit, deposit.id,
          idempotencyKey
        ]);

        console.log(`✅ Зачислено ${amountToCredit} ${deposit.currency} пользователю ${deposit.user_id} (депозит ${deposit.id})`);
        processedCount++;

      } catch (error) {
        console.error(`❌ Ошибка при обработке депозита ${deposit.id}:`, error.message);
        errors.push({ depositId: deposit.id, error: error.message });
      }
    }

    await client.query('COMMIT');
    await client.query('SELECT pg_advisory_unlock(12345)');

    console.log(`🎉 [${new Date().toISOString()}] Обработано ${processedCount} депозитов`);

    if (errors.length > 0) {
      console.log(`⚠️ Ошибки при обработке ${errors.length} депозитов:`, errors);
    }

    return { processed: processedCount, success: true, errors };

  } catch (error) {
    await client.query('ROLLBACK');
    await client.query('SELECT pg_advisory_unlock(12345)');
    console.error(`❌ [${new Date().toISOString()}] Ошибка:`, error.message);
    return { processed: 0, success: false, error: error.message };
  } finally {
    await client.end();
    isProcessing = false;
    processStartTime = null;
  }
}

// Функция для graceful shutdown
async function gracefulShutdown(signal) {
  console.log(`\n🛑 Получен сигнал ${signal}, останавливаем мониторинг...`);

  if (isProcessing) {
    console.log('⏳ Ожидаем завершения текущей обработки...');

    // Ждем максимум 30 секунд
    let attempts = 0;
    while (isProcessing && attempts < 30) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      attempts++;
    }

    if (isProcessing) {
      console.log('⚠️ Принудительная остановка (таймаут ожидания)');
    }
  }

  clearInterval(interval);
  process.exit(0);
}

// Запуск мониторинга
console.log('🚀 Запуск мониторинга депозитов...');
console.log(`⚡ Проверка каждые 5 секунд (PID: ${process.pid})`);
console.log('💡 Для остановки нажмите Ctrl+C');
console.log(`📅 Запущено: ${new Date().toISOString()}`);

// Сразу запускаем первую проверку
processConfirmedDeposits().catch(error => {
  console.error('💥 Ошибка при первичной проверке:', error);
});

// Запускаем каждые 5 секунд
const interval = setInterval(async () => {
  try {
    await processConfirmedDeposits();
  } catch (error) {
    console.error(`💥 [${new Date().toISOString()}] Критическая ошибка:`, error);
  }
}, 5000);

// Graceful shutdown handlers
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

// Обработка необработанных ошибок
process.on('unhandledRejection', (reason, promise) => {
  console.error('💥 Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (error) => {
  console.error('💥 Uncaught Exception:', error);
  process.exit(1);
});

// Периодический health check
setInterval(() => {
  const uptime = process.uptime();
  const hours = Math.floor(uptime / 3600);
  const minutes = Math.floor((uptime % 3600) / 60);
  console.log(`💚 [${new Date().toISOString()}] Система работает: ${hours}ч ${minutes}м`);
}, 300000); // каждые 5 минут
