#!/usr/bin/env node

/**
 * Демон для автоматической обработки стандартных выводов Stars в TON
 * Проверяет конвертации со статусом 'pending' и типом 'standard',
 * где прошло 21 день с момента создания, и отправляет TON.
 */

const { Pool } = require('pg');
const { TonClient, WalletContractV4, Address, beginCell, toNano, internal } = require('@ton/ton');
const { mnemonicToWalletKey } = require('@ton/crypto');
require('dotenv').config();

// Настройки базы данных
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// Настройки TON
const TON_MNEMONIC = process.env.TON_WALLET_MNEMONIC;
const TON_API_KEY = process.env.TON_API_KEY;
const TON_NETWORK = process.env.TON_NETWORK || 'mainnet';

async function initTonClient() {
  if (!TON_MNEMONIC) {
    throw new Error('TON_WALLET_MNEMONIC not configured');
  }

  const isTestnet = TON_NETWORK === 'testnet';
  const endpoint = isTestnet
    ? 'https://testnet.toncenter.com/api/v2/jsonRPC'
    : 'https://toncenter.com/api/v2/jsonRPC';

  const tonClient = new TonClient({
    endpoint,
    apiKey: TON_API_KEY
  });

  const keyPair = await mnemonicToWalletKey(TON_MNEMONIC.split(' '));
  const wallet = WalletContractV4.create({
    workchain: 0,
    publicKey: keyPair.publicKey
  });

  const contract = tonClient.open(wallet);

  return { tonClient, contract, keyPair };
}

async function processStandardWithdrawals() {
  console.log(`[${new Date().toISOString()}] Checking for standard withdrawals ready for processing...`);

  const client = await pool.connect();

  try {
    // Получаем все стандартные конвертации, готовые к обработке
    const result = await client.query(`
      SELECT
        ct.id,
        ct.user_id,
        ct.stars_amount,
        ct.ton_amount,
        ct.final_ton_amount,
        ct.ton_wallet_address,
        ct.created_at,
        ct.standard_release_date,
        u.telegram_id,
        u.first_name,
        u.username
      FROM conversion_transactions ct
      LEFT JOIN users u ON ct.user_id = u.id
      WHERE ct.withdrawal_type = 'standard'
        AND ct.status = 'pending'
        AND ct.standard_release_date <= NOW()
      ORDER BY ct.created_at ASC
      LIMIT 10
    `);

    if (result.rows.length === 0) {
      console.log('No standard withdrawals ready for processing.');
      return;
    }

    console.log(`Found ${result.rows.length} standard withdrawals ready for processing.`);

    const { contract, keyPair } = await initTonClient();

    for (const conversion of result.rows) {
      try {
        console.log(`Processing conversion ID ${conversion.id} for user ${conversion.telegram_id}...`);

        await client.query('BEGIN');

        // Отправляем TON
        const tonAmount = conversion.final_ton_amount || conversion.ton_amount;
        const tonNano = toNano(tonAmount.toString());

        const seqno = await contract.getSeqno();

        await contract.sendTransfer({
          seqno,
          secretKey: keyPair.secretKey,
          messages: [internal({
            to: conversion.ton_wallet_address,
            value: tonNano,
            body: beginCell()
              .storeUint(0, 32)
              .storeStringTail(`Стандартная конвертация ${conversion.stars_amount} Stars в ${tonAmount} TON`)
              .endCell(),
            bounce: false
          })]
        });

        // Обновляем статус на completed
        await client.query(
          'UPDATE conversion_transactions SET status = $1, processed_at = NOW() WHERE id = $2',
          ['completed', conversion.id]
        );

        await client.query('COMMIT');

        console.log(`✅ Successfully processed conversion ID ${conversion.id}: ${conversion.stars_amount} Stars → ${tonAmount} TON`);

        // Небольшая пауза между отправками
        await new Promise(resolve => setTimeout(resolve, 2000));

      } catch (error) {
        await client.query('ROLLBACK');
        console.error(`❌ Error processing conversion ID ${conversion.id}:`, error);

        // Помечаем конвертацию как failed при критической ошибке
        try {
          await client.query(
            'UPDATE conversion_transactions SET status = $1, error_message = $2 WHERE id = $3',
            ['failed', error.message, conversion.id]
          );
        } catch (updateError) {
          console.error('Failed to update conversion status to failed:', updateError);
        }
      }
    }

  } catch (error) {
    console.error('Error in processStandardWithdrawals:', error);
  } finally {
    client.release();
  }
}

async function checkDatabaseConnection() {
  try {
    const client = await pool.connect();
    await client.query('SELECT 1');
    client.release();
    console.log('✅ Database connection successful');
    return true;
  } catch (error) {
    console.error('❌ Database connection failed:', error);
    return false;
  }
}

async function main() {
  console.log('🚀 Standard Withdrawal Daemon Starting...');

  // Проверяем подключение к базе данных
  const dbConnected = await checkDatabaseConnection();
  if (!dbConnected) {
    process.exit(1);
  }

  // Проверяем настройки TON
  try {
    await initTonClient();
    console.log('✅ TON client initialization successful');
  } catch (error) {
    console.error('❌ TON client initialization failed:', error);
    process.exit(1);
  }

  console.log('✅ All systems ready. Starting monitoring...');

  // Запускаем обработку сразу
  await processStandardWithdrawals();

  // Затем каждые 10 минут
  const interval = setInterval(async () => {
    try {
      await processStandardWithdrawals();
    } catch (error) {
      console.error('Error in main loop:', error);
    }
  }, 10 * 60 * 1000); // 10 минут

  // Graceful shutdown
  process.on('SIGINT', () => {
    console.log('\n📝 Shutting down standard withdrawal daemon...');
    clearInterval(interval);
    pool.end();
    process.exit(0);
  });

  process.on('SIGTERM', () => {
    console.log('\n📝 Shutting down standard withdrawal daemon...');
    clearInterval(interval);
    pool.end();
    process.exit(0);
  });
}

// Запускаем демон только если файл запущен напрямую
if (require.main === module) {
  main().catch(error => {
    console.error('Fatal error:', error);
    process.exit(1);
  });
}

module.exports = { processStandardWithdrawals };
