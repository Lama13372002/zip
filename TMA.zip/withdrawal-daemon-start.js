/**
 * Withdrawal Daemon Starter
 * Скрипт для запуска демона обработки выводов TON
 */

require('dotenv').config();

// Импортируем демон
const { withdrawalDaemon } = require('./src/lib/withdrawal-daemon');

console.log('='.repeat(50));
console.log('🚀 Starting TON Withdrawal Daemon');
console.log('='.repeat(50));

// Обработчики сигналов для корректного завершения
process.on('SIGINT', () => {
  console.log('\n⏹️  Received SIGINT. Stopping daemon...');
  withdrawalDaemon.stop();
  process.exit(0);
});

process.on('SIGTERM', () => {
  console.log('\n⏹️  Received SIGTERM. Stopping daemon...');
  withdrawalDaemon.stop();
  process.exit(0);
});

// Обработчик ошибок
process.on('uncaughtException', (error) => {
  console.error('💥 Uncaught Exception:', error);
  withdrawalDaemon.stop();
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('💥 Unhandled Rejection at:', promise, 'reason:', reason);
});

// Запускаем демон
try {
  withdrawalDaemon.start();
  console.log('✅ Withdrawal daemon started successfully');
  console.log('📊 Status:', withdrawalDaemon.getStatus());

  // Логируем статус каждые 5 минут
  setInterval(() => {
    const status = withdrawalDaemon.getStatus();
    console.log(`📊 Daemon Status [${new Date().toISOString()}]:`, status);
  }, 5 * 60 * 1000);

} catch (error) {
  console.error('❌ Failed to start withdrawal daemon:', error);
  process.exit(1);
}
