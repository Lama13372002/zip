#!/bin/bash

# Скрипт управления демоном автопроверки ставок

DAEMON_SCRIPT="auto-checker-daemon.cjs"
PID_FILE="auto-checker.pid"
LOG_FILE="auto-checker.log"

# Цвета для вывода
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_help() {
    echo -e "${BLUE}🤖 Управление демоном автопроверки ставок${NC}"
    echo ""
    echo "Использование: $0 {start|stop|restart|status|logs|help}"
    echo ""
    echo "Команды:"
    echo "  start   - Запустить демон"
    echo "  stop    - Остановить демон"
    echo "  restart - Перезапустить демон"
    echo "  status  - Показать статус демона"
    echo "  logs    - Показать логи (последние 50 строк)"
    echo "  help    - Показать эту справку"
}

check_dependencies() {
    if ! command -v node &> /dev/null; then
        echo -e "${RED}❌ Node.js не установлен${NC}"
        exit 1
    fi

    if [ ! -f "$DAEMON_SCRIPT" ]; then
        echo -e "${RED}❌ Файл демона не найден: $DAEMON_SCRIPT${NC}"
        exit 1
    fi
}

get_pid() {
    if [ -f "$PID_FILE" ]; then
        cat "$PID_FILE"
    else
        echo ""
    fi
}

is_running() {
    local pid=$(get_pid)
    if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
        return 0
    else
        return 1
    fi
}

start_daemon() {
    echo -e "${BLUE}🚀 Запуск демона автопроверки...${NC}"

    if is_running; then
        echo -e "${YELLOW}⚠️ Демон уже запущен (PID: $(get_pid))${NC}"
        return 1
    fi

    # Удаляем старый PID файл если он есть
    [ -f "$PID_FILE" ] && rm -f "$PID_FILE"

    # Устанавливаем node-fetch если не установлен
    if ! node -e "require('node-fetch')" 2>/dev/null; then
        echo -e "${YELLOW}📦 Устанавливаю node-fetch...${NC}"
        npm install node-fetch
    fi

    # Запускаем демон в фоне
    nohup node "$DAEMON_SCRIPT" > /dev/null 2>&1 &

    # Ждем немного и проверяем запуск
    sleep 2

    if is_running; then
        echo -e "${GREEN}✅ Демон успешно запущен (PID: $(get_pid))${NC}"
        echo -e "${BLUE}📄 Логи: tail -f $LOG_FILE${NC}"
    else
        echo -e "${RED}❌ Не удалось запустить демон${NC}"
        if [ -f "$LOG_FILE" ]; then
            echo -e "${YELLOW}Последние ошибки:${NC}"
            tail -n 10 "$LOG_FILE"
        fi
        return 1
    fi
}

stop_daemon() {
    echo -e "${BLUE}🛑 Остановка демона...${NC}"

    if ! is_running; then
        echo -e "${YELLOW}⚠️ Демон не запущен${NC}"
        # Удаляем старый PID файл
        [ -f "$PID_FILE" ] && rm -f "$PID_FILE"
        return 1
    fi

    local pid=$(get_pid)
    echo -e "${BLUE}Останавливаю процесс $pid...${NC}"

    # Отправляем SIGTERM
    kill "$pid"

    # Ждем корректного завершения
    local count=0
    while is_running && [ $count -lt 10 ]; do
        sleep 1
        count=$((count + 1))
    done

    if is_running; then
        echo -e "${YELLOW}⚠️ Принудительная остановка...${NC}"
        kill -9 "$pid"
        sleep 1
    fi

    # Удаляем PID файл
    [ -f "$PID_FILE" ] && rm -f "$PID_FILE"

    if is_running; then
        echo -e "${RED}❌ Не удалось остановить демон${NC}"
        return 1
    else
        echo -e "${GREEN}✅ Демон остановлен${NC}"
    fi
}

show_status() {
    echo -e "${BLUE}📊 Статус демона автопроверки${NC}"
    echo ""

    if is_running; then
        local pid=$(get_pid)
        echo -e "Статус: ${GREEN}🟢 Запущен${NC}"
        echo -e "PID: $pid"

        # Показываем информацию о процессе
        if command -v ps &> /dev/null; then
            echo "Процесс:"
            ps -p "$pid" -o pid,ppid,cmd,etime,pcpu,pmem 2>/dev/null || echo "  Информация недоступна"
        fi

        # Показываем последние логи
        if [ -f "$LOG_FILE" ]; then
            echo ""
            echo -e "${BLUE}📄 Последние логи:${NC}"
            tail -n 5 "$LOG_FILE"
        fi
    else
        echo -e "Статус: ${RED}🔴 Остановлен${NC}"

        if [ -f "$PID_FILE" ]; then
            echo -e "${YELLOW}⚠️ Найден старый PID файл (процесс завершился некорректно)${NC}"
        fi
    fi

    echo ""
    echo -e "${BLUE}Файлы:${NC}"
    echo "  Демон: $DAEMON_SCRIPT $([ -f "$DAEMON_SCRIPT" ] && echo "✅" || echo "❌")"
    echo "  PID: $PID_FILE $([ -f "$PID_FILE" ] && echo "✅" || echo "❌")"
    echo "  Логи: $LOG_FILE $([ -f "$LOG_FILE" ] && echo "✅" || echo "❌")"
}

show_logs() {
    if [ ! -f "$LOG_FILE" ]; then
        echo -e "${YELLOW}⚠️ Лог файл не найден: $LOG_FILE${NC}"
        return 1
    fi

    echo -e "${BLUE}📄 Логи автопроверки (последние 50 строк):${NC}"
    echo ""
    tail -n 50 "$LOG_FILE"
}

# Основная логика
case "$1" in
    start)
        check_dependencies
        start_daemon
        ;;
    stop)
        stop_daemon
        ;;
    restart)
        check_dependencies
        stop_daemon
        sleep 1
        start_daemon
        ;;
    status)
        show_status
        ;;
    logs)
        show_logs
        ;;
    help|--help|-h)
        print_help
        ;;
    *)
        echo -e "${RED}❌ Неизвестная команда: $1${NC}"
        echo ""
        print_help
        exit 1
        ;;
esac
