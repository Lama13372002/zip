import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useTelegramAuth } from "@/hooks/useTelegramAuth";

export function BalanceDisplay() {
  const { userData, isLoading } = useTelegramAuth();

  if (isLoading) {
    return (
      <Card className="glass-card border-none">
        <CardContent className="p-3">
          <div className="flex justify-center items-center space-x-4">
            <div className="text-sm text-foreground/60">Загрузка баланса...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!userData) {
    return null;
  }

  return (
    <Card className="glass-card border-none">
      <CardContent className="p-3">
        <div className="flex justify-center items-center space-x-4">
          <Badge className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-none">
            <div className="flex items-center space-x-1">
              <img src="/images/ton.png" alt="TON" className="h-4 w-4" />
              <span className="font-semibold">{userData.ton_balance.toFixed(2)}</span>
            </div>
          </Badge>

          <Badge className="bg-gradient-to-r from-yellow-500 to-amber-500 text-white border-none">
            <div className="flex items-center space-x-1">
              <img src="/images/stars.png" alt="STARS" className="h-4 w-4" />
              <span className="font-semibold">{userData.stars_balance.toFixed(0)}</span>
            </div>
          </Badge>
        </div>

        {userData.first_name && (
          <div className="text-center mt-2">
            <span className="text-sm text-foreground/70">
              Привет, {userData.first_name}!
            </span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
