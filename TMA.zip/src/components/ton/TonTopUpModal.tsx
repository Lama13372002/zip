'use client';

import { useState, useEffect } from 'react';
import { useTonConnectUI, useTonWallet } from '@tonconnect/ui-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, AlertCircle, CheckCircle, Wallet, Diamond, Zap, TrendingUp, Shield, Clock, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTelegramAuth } from '@/hooks/useTelegramAuth';
import { useTelegram } from '@/components/providers/TelegramProvider';
import { TonTopUpI18nProvider, useTonTopUpI18n } from '@/components/providers/TonTopUpI18nProvider';
import { useIOSKeyboard } from '@/hooks/useIOSKeyboard';
import { Address } from '@ton/core';

interface TonTopUpModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnectWallet?: () => void;
}

const TON_PACKAGES = [
  {
    amount: 1,
    popular: false,
    icon: Diamond,
    gradient: "from-blue-400 to-cyan-500",
    key: "pkg_start" as const,
  },
  {
    amount: 5,
    popular: true,
    icon: TrendingUp,
    gradient: "from-cyan-400 via-blue-500 to-indigo-500",
    key: "pkg_popular" as const,
  },
  {
    amount: 10,
    popular: false,
    icon: Zap,
    gradient: "from-indigo-400 to-purple-500",
    key: "pkg_value" as const,
  },
  {
    amount: 25,
    popular: false,
    icon: Shield,
    gradient: "from-purple-400 to-pink-500",
    key: "pkg_premium" as const,
  },
] as const;

function TonTopUpModalContent({ isOpen, onClose, onConnectWallet }: TonTopUpModalProps) {
  const { t } = useTonTopUpI18n();
  const [tonConnectUI] = useTonConnectUI();
  const wallet = useTonWallet();
  const { userData, refreshUserData } = useTelegramAuth();
  const { isFullscreen } = useTelegram();
  const { inputRef: tonInputRef } = useIOSKeyboard({ enabled: true, delay: 200 });

  const [amount, setAmount] = useState('');
  const [selectedAmount, setSelectedAmount] = useState(5);
  const [isProcessing, setIsProcessing] = useState(false);
  const [transactionStatus, setTransactionStatus] = useState<'idle' | 'pending' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [walletAddress, setWalletAddress] = useState<string>('');

  // Получаем адрес кошелька при открытии модального окна
  useEffect(() => {
    if (isOpen && !walletAddress) {
      fetch('/api/ton/wallet-address')
        .then(res => res.json())
        .then(data => {
          if (data.address) {
            setWalletAddress(data.address);
          }
        })
        .catch(error => {
          console.error('Error fetching wallet address:', error);
          setErrorMessage(t('error_fetch_address'));
        });
    }
  }, [isOpen, walletAddress, t]);

  const handleAmountSelect = (tonAmount: number) => {
    setSelectedAmount(tonAmount);
    setAmount(tonAmount.toString());
    setErrorMessage('');
  };

  const handleAmountChange = (value: string) => {
    // Разрешаем только числа и точку
    if (/^\d*\.?\d*$/.test(value)) {
      setAmount(value);
      const numValue = Number.parseFloat(value);
      if (!isNaN(numValue)) {
        setSelectedAmount(numValue);
      }
      setErrorMessage('');
    }
  };

  const sendTonTransaction = async (tonAmount: number) => {
    if (!wallet || !tonConnectUI) {
      throw new Error(t('error_wallet_not_connected'));
    }

    if (!walletAddress) {
      throw new Error(t('error_address_not_loaded'));
    }

    // Конвертируем TON в nanotons (1 TON = 10^9 nanotons)
    const nanotons = Math.floor(tonAmount * 1000000000);

    const transaction = {
      validUntil: Math.floor(Date.now() / 1000) + 300, // 5 минут
      messages: [
        {
          address: walletAddress, // Используем адрес из переменной окружения
          amount: nanotons.toString()
        }
      ]
    };

    const result = await tonConnectUI.sendTransaction(transaction);
    return result;
  };

  const handleTopUp = async () => {
    const tonAmount = Number.parseFloat(amount);

    if (!tonAmount || tonAmount <= 0) {
      setErrorMessage(t('error_input_amount'));
      return;
    }

    if (tonAmount < 0.01) {
      setErrorMessage(t('error_min_amount'));
      return;
    }

    if (!wallet) {
      setErrorMessage(t('error_wallet_not_connected'));
      return;
    }

    if (!walletAddress) {
      setErrorMessage(t('error_address_not_loaded'));
      return;
    }

    setIsProcessing(true);
    setTransactionStatus('pending');
    setErrorMessage('');

    try {
      // Отправляем транзакцию
      const result = await sendTonTransaction(tonAmount);

      console.log('Transaction result:', result);

      // Получаем реальный хеш транзакции из cell
      let transactionHash = '';
      try {
        // result.boc содержит транзакцию в формате base64
        // Можем использовать его как уникальный идентификатор
        const transactionCell = result.boc;
        // Создаем хеш на основе boc для уникальности
        transactionHash = btoa(transactionCell).slice(0, 32) + '_' + Date.now();
      } catch (error) {
        console.error('Error processing transaction hash:', error);
        transactionHash = `tx_${Date.now()}_${userData?.telegram_id || 'unknown'}`;
      }

      // Конвертируем адрес кошелька в user-friendly формат
      const userFriendlyAddress = Address.parse(wallet.account.address).toString();
      console.log('Transaction details:', {
        hash: transactionHash,
        amount: tonAmount,
        originalAddress: wallet.account.address,
        userFriendlyAddress: userFriendlyAddress,
        boc: result.boc
      });

      // Уведомляем бэкенд о УСПЕШНОЙ транзакции (TON Connect уже подтвердил)
      const response = await fetch('/api/ton/deposit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-telegram-user-id': userData?.telegram_id?.toString() || '',
        },
        body: JSON.stringify({
          amount: tonAmount,
          transactionHash: transactionHash,
          walletAddress: userFriendlyAddress,
          transactionBoc: result.boc,
          confirmed: true // ✅ TON Connect уже подтвердил успешность транзакции
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Ошибка при обработке транзакции');
      }

      const responseData = await response.json();

      // Транзакция успешно обработана
      setTransactionStatus('success');

      // Успешное зачисление - обновляем данные
      setTimeout(() => {
        refreshUserData();
        onClose();
        setAmount('');
        setSelectedAmount(5);
        setTransactionStatus('idle');
      }, 2000);

    } catch (error: unknown) {
      console.error('Ошибка при пополнении:', error);
      setTransactionStatus('error');
      setErrorMessage(error instanceof Error ? error.message : t('error_processing_tx'));
    } finally {
      setIsProcessing(false);
    }
  };

  // Сброс состояния при закрытии
  useEffect(() => {
    if (!isOpen) {
      setErrorMessage('');
      setTransactionStatus('idle');
      setIsProcessing(false);
      setAmount('');
      setSelectedAmount(5);
    }
  }, [isOpen]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent
        className={`
          ${isFullscreen
            ? 'fixed left-0 right-0 top-16 bottom-20 w-full max-w-none max-h-none m-0 rounded-t-2xl border-none !transform-none [&>button]:hidden'
            : 'sm:max-w-md'
          }
          bg-gradient-to-br from-slate-900/98 via-slate-800/98 to-slate-900/98 backdrop-blur-xl border border-white/10 shadow-2xl
          ${isFullscreen ? 'p-4' : ''}
        `}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          transition={{ duration: 0.3 }}
          className={`
            ${isFullscreen
              ? 'h-full flex flex-col'
              : 'flex flex-col max-h-[70vh]'
            }
            p-1
          `}
        >
          {/* Scrollable content area */}
          <div className={`
            ${isFullscreen ? 'flex-1 overflow-y-auto' : 'flex-1 overflow-y-auto'}
            space-y-4 pr-1
          `}
          >
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.1 }}
                className="relative w-10 h-10 bg-gradient-to-br from-blue-400 via-cyan-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/30"
              >
                <img src="/images/ton.png" alt="TON" className="h-6 w-6" />
              </motion.div>

              <div>
                <h2 className="text-lg font-bold bg-gradient-to-r from-blue-400 via-cyan-500 to-indigo-500 bg-clip-text text-transparent">
                  {t('header_title')}
                </h2>
                <p className="text-slate-400 text-xs">
                  {t('header_sub')}
                </p>
              </div>
            </div>

            {/* Close button for fullscreen */}
            {isFullscreen && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="w-8 h-8 p-0 rounded-full hover:bg-white/10"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>

          <AnimatePresence>
            {transactionStatus === 'success' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: -10 }}
                className="bg-gradient-to-r from-green-500/20 via-emerald-500/20 to-green-600/20 border border-green-500/30 rounded-xl p-4"
              >
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-green-400 text-sm">{t('tx_success_title')}</h3>
                    <p className="text-green-300/80 text-xs">{t('tx_success_desc')}</p>
                  </div>
                </div>
              </motion.div>
            )}

            {transactionStatus === 'error' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: -10 }}
                className="bg-gradient-to-r from-red-500/20 via-rose-500/20 to-red-600/20 border border-red-500/30 rounded-xl p-4"
              >
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-red-500 rounded-lg flex items-center justify-center">
                    <AlertCircle className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-red-400 text-sm">{t('tx_error_title')}</h3>
                    <p className="text-red-300/80 text-xs">{errorMessage}</p>
                  </div>
                </div>
              </motion.div>
            )}

            {transactionStatus === 'pending' && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: -10 }}
                className="bg-gradient-to-r from-blue-500/20 via-cyan-500/20 to-blue-600/20 border border-blue-500/30 rounded-xl p-4"
              >
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                    <Loader2 className="h-4 w-4 text-white animate-spin" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-blue-400 text-sm">{t('tx_pending_title')}</h3>
                    <p className="text-blue-300/80 text-xs">{t('tx_pending_desc')}</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {!wallet && (
            <div className="bg-gradient-to-r from-orange-500/20 via-amber-500/20 to-orange-600/20 border border-orange-500/30 rounded-xl p-4">
              <div className="text-center space-y-3">
                <div className="flex items-center justify-center space-x-3">
                  <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                    <Wallet className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-orange-400 text-sm">{t('connect_wallet_title')}</h3>
                    <p className="text-orange-300/80 text-xs">{t('connect_wallet_desc')}</p>
                  </div>
                </div>
                <Button
                  onClick={() => {
                    onClose();
                    onConnectWallet?.();
                  }}
                  className="w-full bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white border-none"
                >
                  {t('connect_wallet_btn')}
                </Button>
              </div>
            </div>
          )}

          {wallet && transactionStatus === 'idle' && (
            <>
              {/* Package Selection */}
              <div className="space-y-3">
                <div className="flex items-center space-x-2 text-slate-300">
                  <Diamond className="h-4 w-4 text-blue-400" />
                  <h3 className="font-semibold text-sm">{t('choose_ton_amount')}</h3>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {TON_PACKAGES.map((pkg, index) => {
                    const IconComponent = pkg.icon;
                    const isSelected = selectedAmount === pkg.amount;

                    return (
                      <motion.div
                        key={pkg.amount}
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: index * 0.05 }}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Card
                          className={`cursor-pointer transition-all duration-300 relative overflow-hidden group ${
                            isSelected
                              ? `border-blue-500/50 bg-gradient-to-br ${pkg.gradient}/20 shadow-lg shadow-blue-500/20`
                              : "border-white/10 bg-white/5 hover:bg-white/10 hover:border-white/20"
                          }`}
                          onClick={() => handleAmountSelect(pkg.amount)}
                        >


                          <CardContent className="p-3 relative h-24 flex flex-col justify-center">
                            <div className="text-center space-y-2">
                              <div className={`mx-auto w-8 h-8 bg-gradient-to-br ${pkg.gradient} rounded-lg flex items-center justify-center shadow-md`}>
                                <img src="/images/ton.png" alt="TON" className="h-4 w-4" />
                              </div>

                              <div>
                                <div className="flex items-center justify-center space-x-1 mb-0.5">
                                  <img src="/images/ton.png" alt="TON" className="h-3 w-3" />
                                  <span className="font-bold text-base text-white">{pkg.amount} TON</span>
                                </div>
                                <p className="text-[10px] text-slate-500 mt-0.5 h-3">
                                  {t(pkg.key)}
                                </p>
                              </div>
                            </div>

                            {isSelected && (
                              <motion.div
                                initial={{ scale: 0, opacity: 0 }}
                                animate={{ scale: 1, opacity: 1 }}
                                className="absolute top-1 left-1"
                              >
                                <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                                  <CheckCircle className="h-3 w-3 text-white" />
                                </div>
                              </motion.div>
                            )}
                          </CardContent>
                        </Card>
                      </motion.div>
                    );
                  })}
                </div>
              </div>

              {/* Custom Amount */}
              <div className="space-y-2">
                <h3 className="font-semibold text-slate-300 text-sm">{t('or_enter_amount')}</h3>
                <div className="space-y-2">
                  <div className="relative">
                    <Input
                      ref={tonInputRef}
                      type="text"
                      inputMode="decimal"
                      pattern="^[0-9]*[.,]?[0-9]*$"
                      enterKeyHint="done"
                      value={amount}
                      onChange={(e) => handleAmountChange(e.target.value)}
                      placeholder="0.0"
                      className="bg-white/5 border-white/10 focus:border-blue-500/50 focus:bg-white/10 transition-all duration-200 text-center text-base h-10 rounded-lg pl-8 pr-12"
                    />
                    <div className="absolute inset-y-0 left-2 flex items-center pointer-events-none">
                      <img src="/images/ton.png" alt="TON" className="h-4 w-4" />
                    </div>
                    <div className="absolute inset-y-0 right-2 flex items-center pointer-events-none">
                      <span className="text-slate-400 text-xs">TON</span>
                    </div>
                  </div>
                  <p className="text-[10px] text-slate-500 text-center">{t('minimum_fee_note')}</p>
                </div>
              </div>

              {/* Transaction Info */}
              <div className="bg-gradient-to-r from-blue-500/10 via-cyan-500/10 to-indigo-500/10 border border-blue-500/20 rounded-xl p-3">
                <div className="space-y-1 text-xs text-slate-300">
                  <div className="flex justify-between">
                    <span>{t('amount_to_topup')}</span>
                    <span className="font-semibold text-blue-400">
                      {amount || '0'} TON
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>{t('network_fee')}</span>
                    <span className="text-slate-400">~0.01 TON</span>
                  </div>
                  <div className="border-t border-white/10 pt-1 mt-1">
                    <div className="flex justify-between font-semibold">
                      <span>{t('total_charge')}</span>
                      <span className="text-blue-400">
                        {amount ? (Number.parseFloat(amount) + 0.01).toFixed(2) : '0.01'} TON
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Compact Features */}
              <div className="flex justify-center space-x-6 text-xs text-slate-300">
                <div className="text-center space-y-1">
                  <div className="w-6 h-6 mx-auto bg-green-500/20 rounded-lg flex items-center justify-center">
                    <Clock className="h-3 w-3 text-green-400" />
                  </div>
                  <p>{t('fast')}</p>
                </div>
                <div className="text-center space-y-1">
                  <div className="w-6 h-6 mx-auto bg-blue-500/20 rounded-lg flex items-center justify-center">
                    <Shield className="h-3 w-3 text-blue-400" />
                  </div>
                  <p>{t('safe')}</p>
                </div>
                <div className="text-center space-y-1">
                  <div className="w-6 h-6 mx-auto bg-purple-500/20 rounded-lg flex items-center justify-center">
                    <img src="/images/ton.png" alt="TON" className="h-3 w-3" />
                  </div>
                  <p>{t('reliable')}</p>
                </div>
              </div>


            </>
          )}
          </div>

          {/* Fixed button area - always at bottom */}
          {wallet && transactionStatus === 'idle' && (
            <div className={`flex-shrink-0 ${isFullscreen ? 'pt-1 pb-1' : 'pt-2 pb-2'}`}>
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button
                  onClick={handleTopUp}
                  disabled={!amount || Number.parseFloat(amount) <= 0 || isProcessing}
                  className="w-full h-12 bg-gradient-to-r from-blue-500 via-cyan-500 to-indigo-500 hover:from-blue-600 hover:via-cyan-600 hover:to-indigo-600 text-white border-none rounded-lg shadow-xl hover:shadow-2xl hover:shadow-blue-500/25 transition-all duration-300 font-semibold"
                >
                  {isProcessing ? (
                    <div className="flex items-center space-x-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>{t('sending_tx')}</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      <img src="/images/ton.png" alt="TON" className="h-4 w-4" />
                      <span>{t('topup_btn', { amount: amount || '0' })}</span>
                    </div>
                  )}
                </Button>
              </motion.div>
            </div>
          )}
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}

export function TonTopUpModal(props: TonTopUpModalProps) {
  return (
    <TonTopUpI18nProvider>
      <TonTopUpModalContent {...props} />
    </TonTopUpI18nProvider>
  );
}
