"use client";

import { useState, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { WalletInput } from "@/components/ui/wallet-input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Loader2, CheckCircle, AlertCircle, ArrowRight, Zap, X, History, Clock, RefreshCw, XCircle, Shield, Timer, Info } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useTelegram } from "@/components/providers/TelegramProvider";
import { useIOSKeyboard } from "@/hooks/useIOSKeyboard";
import { StarsToTonI18nProvider, useStarsToTonI18n } from "@/components/providers/StarsToTonI18nProvider";

interface StarsToTonModalProps {
  isOpen: boolean;
  onClose: () => void;
  userBalance: number;
}

interface ConversionRate {
  starsToUsd: number;
  tonToUsd: number;
  minConversionAmount: number;
  description: string;
  history?: ConversionHistory[];
}

interface ConversionHistory {
  id: number;
  stars_amount: number;
  ton_amount: number;
  ton_amount_text?: string;
  ton_amount_float?: number;
  ton_wallet_address: string;
  status: string;
  created_at: string;
  withdrawal_type?: 'standard' | 'accelerated';
  commission_rate?: number;
  commission_amount?: number;
  final_ton_amount?: number;
  standard_release_date?: string;
  days_remaining?: number;
  is_locked?: boolean;
}

// Функция для умного форматирования TON
const formatTonAmount = (amount: number): string => {
  if (amount === 0) return '0';

  // Для сумм больше 1 TON показываем 4 знака после запятой
  if (amount >= 1) {
    return amount.toFixed(4);
  }

  // Для сумм меньше 1 TON показываем 6 знаков после запятой
  if (amount >= 0.001) {
    return amount.toFixed(6);
  }

  // Для очень маленьких сумм показываем 8 знаков
  return amount.toFixed(8);
};

const StarsToTonModalInner = ({ isOpen, onClose, userBalance }: StarsToTonModalProps) => {
  const { t } = useStarsToTonI18n();
  const { user, isFullscreen } = useTelegram();
  const { inputRef: starsConvertInputRef } = useIOSKeyboard({ enabled: true, delay: 200 });
  const [activeTab, setActiveTab] = useState<'convert' | 'history'>('convert');
  const [starsAmount, setStarsAmount] = useState("");
  const [tonWalletAddress, setTonWalletAddress] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [conversionData, setConversionData] = useState<ConversionRate | null>(null);
  const [conversionHistory, setConversionHistory] = useState<ConversionHistory[]>([]);
  const [liveRates, setLiveRates] = useState<{ tonToUsd: number; starsToUsd: number } | null>(null);
  const [rateUpdateTime, setRateUpdateTime] = useState<number>(0);
  const [currentTonAmount, setCurrentTonAmount] = useState<number>(0); // Текущая сумма TON для конвертации
  const [withdrawalType, setWithdrawalType] = useState<'standard' | 'accelerated'>('accelerated');
  const [agreementAccepted, setAgreementAccepted] = useState(false);
  const [showAgreement, setShowAgreement] = useState(false);

  // Загружаем курс конвертации и историю
  useEffect(() => {
    if (isOpen && user?.id) {
      console.log('Loading conversion history for user:', user?.id);
      // Загружаем курс и историю из официального API
      fetch(`/api/stars/convert-to-ton?telegramId=${user.id}`)
        .then(res => res.json())
        .then(data => {
          console.log('Conversion data received:', data);
          setConversionData({
            starsToUsd: data.starsToUsd || 0.015,
            tonToUsd: data.tonToUsd || 5.1,
            minConversionAmount: data.minConversionAmount || 100,
            description: data.description || "1 Star = $0.015"
          });
          setConversionHistory(data.history || []);
        })
        .catch(err => console.error('Failed to load conversion data:', err));
    }
  }, [isOpen, user?.id]);

  // Функция для получения живого курса
  const [fetchingRates, setFetchingRates] = useState(false);

  const fetchLiveRates = async () => {
    if (fetchingRates) return; // Предотвращаем одновременные запросы

    try {
      setFetchingRates(true);
      console.log('Fetching live rates...');
      const response = await fetch('/api/ton-rate');
      const data = await response.json();
      console.log('Live rates response:', data);
      if (data.success) {
        const newRates = {
          tonToUsd: data.tonToUsd,
          starsToUsd: data.starsToUsd
        };
        console.log('Setting new rates:', newRates);
        setLiveRates(newRates);
        setRateUpdateTime(Date.now());
      } else {
        console.error('Failed to get live rates:', data.error);
      }
    } catch (error) {
      console.error('Failed to fetch live rates:', error);
    } finally {
      setFetchingRates(false);
    }
  };

  // Автообновление курса каждые 2 секунды при открытой модалке
  useEffect(() => {
    if (!isOpen) return;

    // Сразу загружаем курс
    fetchLiveRates();

    // Устанавливаем интервал
    const interval = setInterval(fetchLiveRates, 10000); // Каждые 10 секунд

    return () => clearInterval(interval);
  }, [isOpen]);

  // Пересчитываем TON сумму при изменении курса или количества Stars
  useEffect(() => {
    console.log('Recalculating TON amount. starsAmount:', starsAmount, 'liveRates:', liveRates);
    if (starsAmount && liveRates) {
      const stars = Number.parseInt(starsAmount);
      if (stars > 0) {
        const usdAmount = stars * liveRates.starsToUsd;
        const newTonAmount = usdAmount / liveRates.tonToUsd;
        console.log('New TON amount calculated:', newTonAmount, 'from USD:', usdAmount, 'TON rate:', liveRates.tonToUsd);
        setCurrentTonAmount(newTonAmount);
      } else {
        setCurrentTonAmount(0);
      }
    } else {
      setCurrentTonAmount(0);
    }
  }, [starsAmount, liveRates]);

  const calculateTonAmount = (stars: number): number => {
    // Если есть актуальные live rates, используем их
    if (liveRates && stars > 0) {
      const usdAmount = stars * liveRates.starsToUsd;
      return usdAmount / liveRates.tonToUsd;
    }

    // Fallback на старую логику с conversionData
    if (conversionData && stars > 0) {
      const usdAmount = stars * conversionData.starsToUsd;
      return usdAmount / conversionData.tonToUsd;
    }

    return 0;
  };

  // Функция для расчета финальной суммы с учетом комиссии
  const calculateFinalAmount = (baseTonAmount: number, type: 'standard' | 'accelerated') => {
    if (type === 'accelerated') {
      const commission = baseTonAmount * 0.12; // 12% комиссия
      const finalAmount = baseTonAmount - commission;
      return {
        commission,
        finalAmount,
        commissionRate: 12
      };
    }
    return {
      commission: 0,
      finalAmount: baseTonAmount,
      commissionRate: 0
    };
  };

  const handleStarsAmountChange = (value: string) => {
    const numValue = Number.parseInt(value);
    if (value === "" || (numValue >= 0 && numValue <= userBalance)) {
      setStarsAmount(value);
      setError("");
    }
  };

  const handleMaxStars = () => {
    setStarsAmount(userBalance.toString());
  };

  const handleConvert = async () => {
    if (!user?.id) {
      setError(t('err_not_auth'));
      return;
    }

    const stars = Number.parseInt(starsAmount);
    console.log('Parsing stars amount:', { starsAmount, parsed: stars, isNaN: isNaN(stars) });

    if (!starsAmount || isNaN(stars) || stars <= 0) {
      setError(t('err_input'));
      return;
    }

    if (stars < (conversionData?.minConversionAmount || 100)) {
      setError(t('err_min', { min: conversionData?.minConversionAmount || 100 }));
      return;
    }

    if (stars > userBalance) {
      setError(t('err_not_enough'));
      return;
    }

    if (!tonWalletAddress.trim()) {
      setError(t('err_wallet'));
      return;
    }

    if (!agreementAccepted) {
      setError(t('err_agreement'));
      return;
    }

    // Рассчитываем TON сумму в момент конвертации для надежности
    const calculatedTonAmount = calculateTonAmount(stars);
    console.log('Converting:', { stars, calculatedTonAmount, liveRates, conversionData });

    if (calculatedTonAmount <= 0) {
      console.error('Invalid TON amount calculated:', { stars, calculatedTonAmount, liveRates, conversionData });
      setError(t('err_rate'));
      return;
    }

    const { commission, finalAmount, commissionRate } = calculateFinalAmount(calculatedTonAmount, withdrawalType);

    setLoading(true);
    setError("");

    try {
      const response = await fetch('/api/stars/convert-to-ton', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-telegram-user-id': user.id.toString()
        },
        body: JSON.stringify({
          starsAmount: stars,
          tonWalletAddress: tonWalletAddress.trim(),
          expectedTonAmount: calculatedTonAmount,
          withdrawalType,
          commissionRate,
          commissionAmount: commission,
          finalTonAmount: finalAmount,
          agreementAccepted: true
        })
      });

      const data = await response.json();
      console.log('API Response:', data);

      if (!response.ok || !data.success) {
        const errorMessage = data.error || data.details || `HTTP ${response.status}: ${response.statusText}`;
        console.error('Conversion failed:', { status: response.status, data });
        throw new Error(errorMessage);
      }

      setSuccess(true);

      // Обновляем историю конвертаций
      if (user?.id) {
        console.log('Reloading conversion history for user:', user.id);
        fetch(`/api/stars/convert-to-ton?telegramId=${user.id}`)
          .then(res => res.json())
          .then(data => {
            console.log('Updated conversion data:', data);
            setConversionHistory(data.history || []);
          })
          .catch(err => console.error('Failed to reload history:', err));
      }

      setTimeout(() => {
        setSuccess(false);
        onClose();
        // Обновляем страницу для отображения нового баланса
        window.location.reload();
      }, 3000);

    } catch (error) {
      console.error('Error converting Stars to TON:', error);

      let errorMessage = t('error_title');

      if (error instanceof Error) {
        errorMessage = error.message;
      } else if (typeof error === 'string') {
        errorMessage = error;
      } else if (error && typeof error === 'object') {
        errorMessage = JSON.stringify(error);
      }

      // Добавляем отладочную информацию если это не пользовательская ошибка
      if (errorMessage.includes('500') || errorMessage.includes('Internal') || errorMessage.includes('server')) {
        errorMessage += `\n\n${t('agreement_text_intro')} Stars=${stars}, TON=${calculatedTonAmount.toFixed(6)}, Rates=${JSON.stringify(liveRates)}`;
      }

      setError(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // Сброс состояния при закрытии
  useEffect(() => {
    if (!isOpen) {
      setError("");
      setSuccess(false);
      setLoading(false);
      setStarsAmount("");
      setTonWalletAddress("");
      setActiveTab('convert');
      setWithdrawalType('accelerated');
      setAgreementAccepted(false);
      setShowAgreement(false);
    }
  }, [isOpen]);

  const getStatusBadge = (status: string, conversion?: ConversionHistory) => {
    const withdrawalType = conversion?.withdrawal_type || 'accelerated';
    const isLocked = conversion?.is_locked || false;
    const daysRemaining = conversion?.days_remaining || 0;

    switch (status) {
      case 'completed':
        return <Badge className="bg-green-500/20 text-green-400 border-green-500/30"><CheckCircle className="w-3 h-3 mr-1" />{t('status_completed')}</Badge>;
      case 'pending':
        if (withdrawalType === 'standard' && isLocked) {
          return (
            <div className="space-y-1">
              <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                <Timer className="w-3 h-3 mr-1" />
                {t('status_pending_locked', { time: formatTimeRemaining(daysRemaining) })}
              </Badge>
            </div>
          );
        }
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30"><Clock className="w-3 h-3 mr-1" />{t('status_pending')}</Badge>;
      case 'processing':
        return <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30"><RefreshCw className="w-3 h-3 mr-1" />{t('status_processing')}</Badge>;
      case 'failed':
        return <Badge className="bg-red-500/20 text-red-400 border-red-500/30"><XCircle className="w-3 h-3 mr-1" />{t('status_failed')}</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString('ru-RU');
  };

  const formatTimeRemaining = (daysRemaining: number) => {
    if (daysRemaining <= 0) return t('available_for_withdrawal');

    const days = Math.floor(daysRemaining);
    const hours = Math.floor((daysRemaining - days) * 24);

    if (days > 0) {
      return `${days} дн. ${hours} ч.`;
    }
    return `${hours} ч.`;
  };

  const tonAmount = starsAmount ? calculateTonAmount(Number.parseInt(starsAmount)) : 0;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent
        className={`
          ${isFullscreen
            ? 'fixed left-0 right-0 bottom-0 top-16 w-full max-w-none max-h-none m-0 rounded-t-2xl border-none !transform-none [&>button]:hidden'
            : 'sm:max-w-md'
          }
          bg-gradient-to-br from-slate-900/98 via-slate-800/98 to-slate-900/98 backdrop-blur-xl border border-white/10 shadow-2xl
          ${isFullscreen ? 'pt-4 pb-[env(safe-area-inset-bottom)]' : ''}
        `}
        style={{
          paddingBottom: isFullscreen ? 'max(1rem, env(safe-area-inset-bottom))' : undefined,
          top: !isFullscreen ? '50%' : undefined,
        }}
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          transition={{ duration: 0.3 }}
          className={`
            ${isFullscreen
              ? 'h-full overflow-y-auto space-y-4 p-1'
              : 'flex flex-col max-h-[90vh] p-1'
            }
          `}
        >
          {/* Header */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.1 }}
                className="relative w-10 h-10 bg-gradient-to-br from-blue-400 via-cyan-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/30"
              >
                <ArrowRight className="h-5 w-5 text-white" />
              </motion.div>

              <div>
                <h2 className="text-lg font-bold bg-gradient-to-r from-blue-400 via-cyan-500 to-blue-600 bg-clip-text text-transparent">
                  {t('header_title')}
                </h2>
                <p className="text-slate-400 text-xs">
                  {t('header_sub')}
                </p>
              </div>
            </div>

            {/* Close button for fullscreen */}
            {isFullscreen && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onClose}
                className="w-8 h-8 p-0 rounded-full hover:bg-white/10"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>

          {/* Tabs */}
          <div className="flex space-x-2 bg-white/5 backdrop-blur-sm rounded-xl p-1 mb-4 mt-4">
            {[
              { id: 'convert', label: t('tab_convert'), icon: ArrowRight },
              { id: 'history', label: t('tab_history'), icon: History }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as 'convert' | 'history')}
                className={`flex-1 flex items-center justify-center space-x-1 py-2 px-3 rounded-lg text-sm font-medium transition-all duration-200 ${
                  activeTab === tab.id
                    ? 'bg-blue-500 text-white shadow-lg'
                    : 'text-foreground/70 hover:text-foreground hover:bg-white/5'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {success && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: -10 }}
                className="bg-gradient-to-r from-green-500/20 via-emerald-500/20 to-green-600/20 border border-green-500/30 rounded-xl p-4"
              >
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-green-400 text-sm">{t('success_title')}</h3>
                    <p className="text-green-300/80 text-xs">{t('success_desc')}</p>
                  </div>
                </div>
              </motion.div>
            )}

            {error && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: -10 }}
                className="bg-gradient-to-r from-red-500/20 via-rose-500/20 to-red-600/20 border border-red-500/30 rounded-xl p-4"
              >
                <div className="flex items-center space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-red-500 rounded-lg flex items-center justify-center">
                    <AlertCircle className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-red-400 text-sm">{t('error_title')}</h3>
                    <p className="text-red-300/80 text-xs">{error}</p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {activeTab === 'convert' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
            >
          {/* Scrollable content area */}
          <div className={`${!isFullscreen ? 'flex-1 overflow-y-auto' : ''} space-y-4 pr-1 pt-2`}>
          {!success && (
            <>
              {/* Balance Info */}
              <div className="bg-gradient-to-r from-yellow-500/10 via-amber-500/10 to-orange-500/10 border border-yellow-500/20 rounded-xl p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <img src="/images/stars.png" alt="Stars" className="h-4 w-4" />
                    <span className="text-sm font-semibold text-slate-300">{t('balance_label')}</span>
                  </div>
                  <span className="text-sm font-bold text-yellow-400">{userBalance.toLocaleString()} Stars</span>
                </div>
              </div>

              {/* Stars Amount Input */}
              <div className="space-y-2">
                <h3 className="font-semibold text-slate-300 text-sm">{t('stars_amount_label')}</h3>
                <div className="relative">
                  <Input
                    ref={starsConvertInputRef}
                    type="number"
                    placeholder={`${conversionData?.minConversionAmount || 100} - ${userBalance}`}
                    value={starsAmount}
                    onChange={(e) => handleStarsAmountChange(e.target.value)}
                    min={conversionData?.minConversionAmount || 100}
                    max={userBalance}
                    className="bg-white/5 border-white/10 focus:border-yellow-500/50 focus:bg-white/10 transition-all duration-200 text-center text-base h-12 rounded-lg pl-10 pr-16 ios-input"
                    style={{
                      fontSize: '16px',
                      WebkitAppearance: 'none',
                      WebkitBorderRadius: '0.5rem',
                    }}
                  />
                  <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
                    <img src="/images/stars.png" alt="Stars" className="h-4 w-4" />
                  </div>
                  <Button
                    type="button"
                    onClick={handleMaxStars}
                    className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 px-2 text-xs bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 border border-yellow-500/30 rounded-md"
                  >
                    {t('max')}
                  </Button>
                </div>
              </div>

              {/* Conversion Preview */}
              {starsAmount && tonAmount > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-gradient-to-r from-blue-500/10 via-cyan-500/10 to-blue-600/10 border border-blue-500/20 rounded-xl p-4"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-center space-x-4">
                      <div className="text-center">
                        <div className="flex items-center justify-center space-x-1 mb-1">
                          <img src="/images/stars.png" alt="Stars" className="h-4 w-4" />
                          <span className="font-bold text-yellow-400">{starsAmount}</span>
                        </div>
                        <p className="text-xs text-slate-400">Stars</p>
                      </div>

                      <div className="text-blue-400">
                        <ArrowRight className="h-5 w-5" />
                      </div>

                      <div className="text-center">
                        <div className="flex items-center justify-center space-x-1 mb-1">
                          <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                            <span className="text-white text-xs font-bold">T</span>
                          </div>
                          <motion.span
                            key={tonAmount.toFixed(8)} // Анимация при изменении с высокой точностью
                            initial={{ scale: 1.2, color: "#34d399" }}
                            animate={{ scale: 1, color: "#60a5fa" }}
                            transition={{ duration: 0.3 }}
                            className="font-bold text-blue-400"
                          >
                            {formatTonAmount(tonAmount)}
                          </motion.span>
                        </div>
                        <p className="text-xs text-slate-400">TON</p>
                      </div>
                    </div>

                    {/* Live rate indicator */}
                    <div className="flex items-center justify-center space-x-2 text-xs text-slate-500">
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                      <span>{t('live_rate_info')}</span>
                      {liveRates && (
                        <span className="text-green-400">
                          (1 TON = ${liveRates.tonToUsd.toFixed(2)})
                        </span>
                      )}
                    </div>
                  </div>
                </motion.div>
              )}

              {/* TON Wallet Address Input */}
              <WalletInput
                value={tonWalletAddress}
                onChange={setTonWalletAddress}
                placeholder={t('ton_wallet_placeholder')}
                label={t('ton_wallet_label')}
                hint={t('ton_wallet_hint')}
              />

              {/* Withdrawal Type Selection */}
              <div className="space-y-3">
                <h3 className="font-semibold text-slate-300 text-sm flex items-center space-x-2">
                  <Info className="h-4 w-4 text-blue-400" />
                  <span>{t('processing_type_title')}</span>
                </h3>

                <div className="bg-gradient-to-r from-blue-500/5 via-cyan-500/5 to-blue-600/5 border border-blue-500/20 rounded-xl p-4">
                  <div className="bg-gradient-to-r from-yellow-500/10 via-amber-500/10 to-orange-500/10 border border-yellow-500/20 rounded-lg p-3 mb-4">
                    <div className="flex items-start space-x-2">
                      <AlertCircle className="h-4 w-4 text-orange-400 mt-0.5 flex-shrink-0" />
                      <div className="text-xs text-orange-300">
                        <p className="font-semibold mb-1">{t('rules_important_title')}</p>
                        <p>{t('rules_important_desc')}</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    {/* Standard Processing */}
                    <div
                      onClick={() => setWithdrawalType('standard')}
                      className={`cursor-pointer p-3 rounded-lg border transition-all duration-200 ${
                        withdrawalType === 'standard'
                          ? 'border-green-500/50 bg-green-500/10'
                          : 'border-white/10 bg-white/5 hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <div className={`w-4 h-4 rounded-full border-2 mt-0.5 ${
                          withdrawalType === 'standard'
                            ? 'border-green-500 bg-green-500'
                            : 'border-white/30'
                        }`}>
                          {withdrawalType === 'standard' && (
                            <div className="w-full h-full rounded-full bg-white"></div>
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <Shield className="h-4 w-4 text-green-400" />
                            <span className="font-semibold text-green-400">{t('standard_title')}</span>
                          </div>
                          <div className="text-xs text-slate-300 space-y-1">
                            <p>⏳ {t('standard_p1')}</p>
                            <p>📭 {t('standard_p2')}</p>
                            <p>💰 {t('standard_p3')}</p>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Accelerated Processing */}
                    <div
                      onClick={() => setWithdrawalType('accelerated')}
                      className={`cursor-pointer p-3 rounded-lg border transition-all duration-200 ${
                        withdrawalType === 'accelerated'
                          ? 'border-cyan-500/50 bg-cyan-500/10'
                          : 'border-white/10 bg-white/5 hover:bg-white/10'
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <div className={`w-4 h-4 rounded-full border-2 mt-0.5 ${
                          withdrawalType === 'accelerated'
                            ? 'border-cyan-500 bg-cyan-500'
                            : 'border-white/30'
                        }`}>
                          {withdrawalType === 'accelerated' && (
                            <div className="w-full h-full rounded-full bg-white"></div>
                          )}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <Zap className="h-4 w-4 text-cyan-400" />
                            <span className="font-semibold text-cyan-400">{t('accelerated_title')}</span>
                          </div>
                          <div className="text-xs text-slate-300 space-y-1">
                            <p>🚀 {t('accelerated_p1')}</p>
                            <p>🔄 {t('accelerated_p2')}</p>
                            <p>💸 {t('accelerated_p3')}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Final amount preview */}
                  {starsAmount && tonAmount > 0 && (
                    <div className="mt-4 p-3 bg-white/5 rounded-lg">
                      <div className="text-xs text-slate-400 mb-2">{t('final_amount_title')}</div>
                      {(() => {
                        const { commission, finalAmount, commissionRate } = calculateFinalAmount(tonAmount, withdrawalType);
                        return (
                          <div className="space-y-1">
                            <div className="flex justify-between text-sm">
                              <span>{t('base_amount')}</span>
                              <span className="text-blue-400">{formatTonAmount(tonAmount)} TON</span>
                            </div>
                            {withdrawalType === 'accelerated' && commission > 0 && (
                              <div className="flex justify-between text-sm">
                                <span>{t('commission_label', { rate: commissionRate })}</span>
                                <span className="text-red-400">-{formatTonAmount(commission)} TON</span>
                              </div>
                            )}
                            <div className="flex justify-between text-sm font-bold border-t border-white/10 pt-1">
                              <span>{t('receive_label')}</span>
                              <span className={withdrawalType === 'accelerated' ? 'text-cyan-400' : 'text-green-400'}>
                                {formatTonAmount(finalAmount)} TON
                              </span>
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                  )}

                  <div className="mt-3 text-xs text-blue-300 flex items-center space-x-1">
                    <Info className="h-3 w-3" />
                    <span>{t('agreement_more')}</span>
                    <button
                      onClick={() => setShowAgreement(true)}
                      className="text-cyan-400 hover:text-cyan-300 underline"
                    >
                      {t('agreement_link')}
                    </button>
                  </div>
                </div>
              </div>

              {/* Agreement Modal */}
              {showAgreement && (
                <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
                  <div className="bg-slate-900 rounded-xl border border-white/10 max-w-md w-full max-h-[80vh] overflow-y-auto">
                    <div className="p-4">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="font-bold text-lg">{t('agreement_title')}</h3>
                        <button
                          onClick={() => setShowAgreement(false)}
                          className="w-8 h-8 rounded-full hover:bg-white/10 flex items-center justify-center"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="text-sm text-slate-300 space-y-3">
                        <p>{t('agreement_text_intro')}</p>

                        <div className="space-y-2">
                          <p className="font-semibold text-slate-200">{t('agreement_1')}</p>
                          <p>{t('agreement_1_desc')}</p>
                        </div>

                        <div className="space-y-2">
                          <p className="font-semibold text-slate-200">{t('agreement_2')}</p>
                          <p>{t('agreement_2_desc')}</p>
                        </div>

                        <div className="space-y-2">
                          <p className="font-semibold text-slate-200">{t('agreement_3')}</p>
                          <p>{t('agreement_3_desc')}</p>
                        </div>

                        <div className="space-y-2">
                          <p className="font-semibold text-slate-200">{t('agreement_4')}</p>
                          <p>{t('agreement_4_desc')}</p>
                        </div>

                        <div className="space-y-2">
                          <p className="font-semibold text-slate-200">{t('agreement_5')}</p>
                          <p>{t('agreement_5_desc')}</p>
                        </div>
                      </div>

                      <div className="mt-6 flex items-center space-x-3">
                        <input
                          type="checkbox"
                          id="agreement"
                          checked={agreementAccepted}
                          onChange={(e) => setAgreementAccepted(e.target.checked)}
                          className="w-4 h-4 rounded border-white/30 bg-white/10"
                        />
                        <label htmlFor="agreement" className="text-sm text-slate-300">
                          {t('agreement_accept_label')}
                        </label>
                      </div>

                      <button
                        onClick={() => setShowAgreement(false)}
                        disabled={!agreementAccepted}
                        className="w-full mt-4 h-10 bg-blue-500 hover:bg-blue-600 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg transition-colors"
                      >
                        {t('agreement_accept_btn')}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Warning */}
              <div className="bg-gradient-to-r from-orange-500/10 via-amber-500/10 to-yellow-500/10 border border-orange-500/20 rounded-xl p-3">
                <div className="flex items-start space-x-2">
                  <AlertCircle className="h-4 w-4 text-orange-400 mt-0.5 flex-shrink-0" />
                  <div className="text-xs text-orange-300">
                    <p className="font-semibold mb-1">{t('warning_title')}</p>
                    <p>{t('warning_i1')}</p>
                    <p>{t('warning_i2')}</p>
                    <p>{t('warning_i3')}</p>
                  </div>
                </div>
              </div>
            </>
          )}
          </div>
            </motion.div>
          )}

          {activeTab === 'history' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-4"
            >
              <Card className="bg-white/5 border-white/10">
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2 mb-4">
                    <History className="w-5 h-5 text-blue-400" />
                    <h3 className="font-semibold text-lg text-blue-400">{t('history_title')}</h3>
                  </div>

                  {conversionHistory.length === 0 ? (
                    <p className="text-center text-foreground/60 py-8">{t('history_empty')}</p>
                  ) : (
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {conversionHistory.map((conversion) => {
                        const withdrawalType = conversion.withdrawal_type || 'accelerated';
                        const finalAmount = conversion.final_ton_amount || conversion.ton_amount_float || Number(conversion.ton_amount_text) || conversion.ton_amount || 0;
                        const commissionAmount = conversion.commission_amount || 0;

                        return (
                          <div key={conversion.id} className="bg-white/5 rounded-lg p-3 space-y-2">
                            <div className="flex justify-between items-start">
                              <div className="space-y-1">
                                <div className="flex items-center space-x-2">
                                  <img src="/images/stars.png" alt="Stars" className="h-4 w-4" />
                                  <span className="font-medium text-yellow-400">{conversion.stars_amount.toLocaleString()}</span>
                                  <ArrowRight className="h-3 w-3 text-slate-400" />
                                  <div className="w-3 h-3 bg-blue-500 rounded-full flex items-center justify-center">
                                    <span className="text-white text-xs font-bold">T</span>
                                  </div>
                                  <span className="font-medium text-blue-400">{formatTonAmount(finalAmount)}</span>
                                  {withdrawalType === 'accelerated' && (
                                    <Zap className="h-3 w-3 text-cyan-400" />
                                  )}
                                  {withdrawalType === 'standard' && (
                                    <Shield className="h-3 w-3 text-green-400" />
                                  )}
                                </div>
                                <p className="text-xs text-foreground/60">{formatDate(conversion.created_at)}</p>
                              </div>
                              <div className="text-right">
                                {getStatusBadge(conversion.status, conversion)}
                              </div>
                            </div>

                            {/* Commission info for accelerated withdrawals */}
                            {withdrawalType === 'accelerated' && commissionAmount > 0 && (
                              <div className="text-xs text-slate-400 bg-white/5 rounded p-2">
                                <div className="flex justify-between">
                                  <span>{t('base_amount')}</span>
                                  <span>{formatTonAmount(finalAmount + commissionAmount)} TON</span>
                                </div>
                                <div className="flex justify-between">
                                  <span>{t('commission_fixed')}</span>
                                  <span className="text-red-400">-{formatTonAmount(commissionAmount)} TON</span>
                                </div>
                                <div className="flex justify-between font-medium border-t border-white/10 pt-1 mt-1">
                                  <span>{t('receive_label')}</span>
                                  <span className="text-cyan-400">{formatTonAmount(finalAmount)} TON</span>
                                </div>
                              </div>
                            )}

                            {/* Standard withdrawal countdown */}
                            {withdrawalType === 'standard' && conversion.status === 'pending' && conversion.is_locked && (
                              <div className="text-xs text-green-300 bg-green-500/10 border border-green-500/20 rounded p-2">
                                <div className="flex items-center space-x-2">
                                  <Timer className="h-3 w-3" />
                                  <span>{t('auto_withdraw_in', { time: formatTimeRemaining(conversion.days_remaining || 0) })}</span>
                                </div>
                                {conversion.standard_release_date && (
                                  <div className="mt-1 text-slate-400">
                                    {t('release_date')} {formatDate(conversion.standard_release_date)}
                                  </div>
                                )}
                              </div>
                            )}

                            <div className="text-xs text-foreground/60 font-mono break-all">
                              {t('wallet_label_history')} {conversion.ton_wallet_address}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Fixed button area only for convert tab */}
          {activeTab === 'convert' && !success && (
            <div className={`${!isFullscreen ? 'flex-shrink-0 pt-2 pb-2' : ''}`}>
              {/* Action Button */}
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={isFullscreen ? "sticky bottom-0 bg-gradient-to-t from-slate-900 via-slate-900/95 to-transparent pt-2" : ""}
              >
                <Button
                  onClick={handleConvert}
                  disabled={loading || !starsAmount || !tonWalletAddress.trim() || tonAmount <= 0 || !agreementAccepted}
                  className={`w-full h-12 border-none rounded-lg shadow-xl hover:shadow-2xl transition-all duration-300 font-semibold ${
                    withdrawalType === 'accelerated'
                      ? 'bg-gradient-to-r from-cyan-500 via-blue-500 to-cyan-600 hover:from-cyan-600 hover:via-blue-600 hover:to-cyan-700 hover:shadow-cyan-500/25'
                      : 'bg-gradient-to-r from-green-500 via-emerald-500 to-green-600 hover:from-green-600 hover:via-emerald-600 hover:to-green-700 hover:shadow-green-500/25'
                  } text-white`}
                >
                  {loading ? (
                    <div className="flex items-center space-x-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span>{t('converting')}</span>
                    </div>
                  ) : (
                    <div className="flex items-center space-x-2">
                      {withdrawalType === 'accelerated' ? (
                        <Zap className="h-4 w-4" />
                      ) : (
                        <Shield className="h-4 w-4" />
                      )}
                      <span>
                        {starsAmount && tonAmount > 0 ? (
                          (() => {
                            const { finalAmount } = calculateFinalAmount(tonAmount, withdrawalType);
                            return `${starsAmount} Stars → ${formatTonAmount(finalAmount)} TON ${withdrawalType === 'accelerated' ? '⚡' : '🔒'}`;
                          })()
                        ) : (
                          withdrawalType === 'accelerated' ? t('convert_btn_accel') : t('convert_btn_std')
                        )}
                      </span>
                    </div>
                  )}
                </Button>
              </motion.div>
            </div>
          )}
        </motion.div>
      </DialogContent>
    </Dialog>
  );
};

export const StarsToTonModal = (props: StarsToTonModalProps) => (
  <StarsToTonI18nProvider>
    <StarsToTonModalInner {...props} />
  </StarsToTonI18nProvider>
);
