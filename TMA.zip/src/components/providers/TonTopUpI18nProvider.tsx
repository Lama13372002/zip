"use client";
import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type Dict = Record<string, string>;

const ru: Dict = {
  header_title: "Пополнение TON",
  header_sub: "Быстро и безопасно",
  tx_success_title: "Транзакция успешна!",
  tx_success_desc: "Баланс обновляется автоматически",
  tx_error_title: "Ошибка",
  tx_pending_title: "Обработка транзакции",
  tx_pending_desc: "Пожалуйста, подождите...",
  connect_wallet_title: "Подключите TON кошелек",
  connect_wallet_desc: "Для пополнения баланса",
  connect_wallet_btn: "Перейти к подключению кошелька",
  choose_ton_amount: "Выберите сумму TON",
  or_enter_amount: "Или введите свою сумму",
  minimum_fee_note: "Минимум: 0.01 TON • Комиссия сети: ~0.01 TON",
  amount_to_topup: "Сумма к пополнению:",
  network_fee: "Комиссия сети:",
  total_charge: "Итого к списанию:",
  fast: "Быстро",
  safe: "Безопасно",
  reliable: "Надежно",
  sending_tx: "Отправка транзакции...",
  topup_btn: "Пополнить {amount} TON",
  error_fetch_address: "Ошибка получения адреса кошелька",
  error_input_amount: "Введите корректную сумму",
  error_min_amount: "Минимальная сумма пополнения: 0.01 TON",
  error_wallet_not_connected: "Подключите TON кошелек",
  error_address_not_loaded: "Адрес получателя не загружен",
  error_processing_tx: "Ошибка при отправке транзакции",
  pkg_start: "Старт",
  pkg_popular: "Популярно",
  pkg_value: "Выгодно",
  pkg_premium: "Премиум",
};

const en: Dict = {
  header_title: "Top up TON",
  header_sub: "Fast and secure",
  tx_success_title: "Transaction successful!",
  tx_success_desc: "Balance updates automatically",
  tx_error_title: "Error",
  tx_pending_title: "Processing transaction",
  tx_pending_desc: "Please wait...",
  connect_wallet_title: "Connect TON wallet",
  connect_wallet_desc: "To top up balance",
  connect_wallet_btn: "Go to wallet connection",
  choose_ton_amount: "Choose TON amount",
  or_enter_amount: "Or enter your amount",
  minimum_fee_note: "Minimum: 0.01 TON • Network fee: ~0.01 TON",
  amount_to_topup: "Amount to top up:",
  network_fee: "Network fee:",
  total_charge: "Total to charge:",
  fast: "Fast",
  safe: "Secure",
  reliable: "Reliable",
  sending_tx: "Sending transaction...",
  topup_btn: "Top up {amount} TON",
  error_fetch_address: "Failed to fetch wallet address",
  error_input_amount: "Enter a valid amount",
  error_min_amount: "Minimum top up: 0.01 TON",
  error_wallet_not_connected: "Connect TON wallet",
  error_address_not_loaded: "Recipient address not loaded",
  error_processing_tx: "Error sending transaction",
  pkg_start: "Starter",
  pkg_popular: "Popular",
  pkg_value: "Value",
  pkg_premium: "Premium",
};

const dicts = { ru, en };

type Ctx = { t: (key: string, params?: Record<string, string | number>) => string };
const Ctx = createContext<Ctx | undefined>(undefined);

export const TonTopUpI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();
  const t = useCallback((key: string, params?: Record<string, string | number>) => {
    const dict = dicts[lang] || en;
    let text = dict[key] ?? key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\\{${k}\\}`, 'g'), String(v));
      });
    }
    return text;
  }, [lang]);
  const value = useMemo(() => ({ t }), [t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useTonTopUpI18n = () => {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useTonTopUpI18n must be used within TonTopUpI18nProvider");
  return ctx;
};
