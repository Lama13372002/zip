"use client";
import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type Dict = Record<string, string>;

const ru: Dict = {
  title_guest: "Fan Fray",
  hello_user: "Привет, {name}!",
  subtitle_guest: "Споры на спортивных событиях",
  subtitle_user: "Готовы начать делать споры на спортивных событиях?",
  feature_p2p_title: "Споры",
  feature_p2p_desc: "Создавайте споры и участвуйте в них на спортивных событиях",
  feature_secure_title: "Безопасность",
  feature_secure_desc: "Автоматический расчет результатов через API",
  feature_fast_title: "Оперативное зачисление",
  feature_fast_desc: "Получайте выигрыш сразу после завершения события",
  feature_community_title: "Сообщество",
  feature_community_desc: "Общайтесь с другими участниками в чате",
  cta_start_user: "Начать приключение",
  cta_start_guest: "Начать",
  cta_skip_user: "Пропустить объяснение",
  cta_skip_guest: "Пропустить",
  badges_ton: "TON",
  badges_stars: "STARS",
  badges_realtime: "Real-time",
  badges_p2p: "P2P",
  tos_text: "Продолжая, вы соглашаетесь с",
  tos_terms: "условиями использования",
  tos_privacy: "политикой конфиденциальности",
};

const en: Dict = {
  title_guest: "Fan Fray",
  hello_user: "Hello, {name}!",
  subtitle_guest: "Bets on sports events",
  subtitle_user: "Ready to start betting on sports events?",
  feature_p2p_title: "Bets",
  feature_p2p_desc: "Create and join bets on sports events",
  feature_secure_title: "Security",
  feature_secure_desc: "Automatic result settlement via API",
  feature_fast_title: "Prompt transfer",
  feature_fast_desc: "Receive winnings right after the event",
  feature_community_title: "Community",
  feature_community_desc: "Chat with other participants",
  cta_start_user: "Start adventure",
  cta_start_guest: "Start",
  cta_skip_user: "Skip intro",
  cta_skip_guest: "Skip",
  badges_ton: "TON",
  badges_stars: "STARS",
  badges_realtime: "Real-time",
  badges_p2p: "P2P",
  tos_text: "By continuing, you agree to the",
  tos_terms: "Terms of Use",
  tos_privacy: "Privacy Policy",
};

const dicts = { ru, en };

type Ctx = { t: (key: string, params?: Record<string, string | number>) => string };
const Ctx = createContext<Ctx | undefined>(undefined);

export const AuthDialogI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();
  const t = useCallback((key: string, params?: Record<string, string | number>) => {
    const dict = dicts[lang] || en;
    let text = dict[key] ?? key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\{${k}\}`, 'g'), String(v));
      });
    }
    return text;
  }, [lang]);
  const value = useMemo(() => ({ t }), [t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useAuthDialogI18n = () => {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useAuthDialogI18n must be used within AuthDialogI18nProvider");
  return ctx;
};
