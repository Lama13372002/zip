"use client";
import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type Dict = Record<string, string>;

const ru: Dict = {
  header_title: "Конвертация в TON",
  header_sub: "Stars → TON",
  tab_convert: "Конвертация",
  tab_history: "История",
  success_title: "Конвертация успешна!",
  success_desc: "TON отправлены на ваш кошелек",
  error_title: "Ошибка",
  balance_label: "Ваш баланс:",
  stars_amount_label: "Количество Stars для конвертации",
  max: "MAX",
  live_rate_info: "Курс обновляется каждые 10 секунд",
  ton_wallet_label: "Адрес TON кошелька",
  ton_wallet_placeholder: "UQA... или 0:...",
  ton_wallet_hint: "Введите адрес вашего TON кошелька для получения монет",
  processing_type_title: "Выберите тип обработки",
  standard_title: "Стандартная обработка",
  standard_p1: "Ожидаем завершения 21-дневного периода",
  standard_p2: "Средства будут выведены автоматически после истечения срока",
  standard_p3: "Без дополнительных удержаний (0% комиссии)",
  accelerated_title: "Ускоренная обработка",
  accelerated_p1: "Выдаём TON сейчас, не дожидаясь окончания периода",
  accelerated_p2: "Используем внутренний резерв сервиса",
  accelerated_p3: "Комиссия за срочность: 12%",
  final_amount_title: "Итоговая сумма к получению:",
  base_amount: "Базовая сумма:",
  commission_label: "Комиссия ({rate}%):",
  receive_label: "К получению:",
  agreement_more: "Подробнее об условиях — ",
  agreement_link: "пользовательское соглашение",
  agreement_title: "Пользовательское соглашение",
  agreement_text_intro: "Используя сервис конвертации Stars в TON, вы соглашаетесь со следующими условиями:",
  agreement_1: "1. Правила Telegram",
  agreement_1_desc: "Пользователь соглашается с официальными правилами Telegram касательно обработки Stars и понимает ограничения по их передаче в течение 21 дня после пополнения.",
  agreement_2: "2. Мгновенный вывод",
  agreement_2_desc: "Ускоренная обработка — это дополнительная опция сервиса, а не обязательная услуга. Сервис предоставляет возможность получить TON немедленно, используя внутренний резерв.",
  agreement_3: "3. Комиссии",
  agreement_3_desc: "За ускоренную обработку взимается комиссия в размере 12% от суммы конвертации. Стандартная обработка осуществляется без комиссии.",
  agreement_4: "4. Ответственность",
  agreement_4_desc: "Пользователь несет полную ответственность за указание корректного адреса TON кошелька. Операции конвертации необратимы.",
  agreement_5: "5. Правовые аспекты",
  agreement_5_desc: "Наш сервис не является финансовой организацией...",
  agreement_accept_label: "Я прочитал и согласен с условиями",
  agreement_accept_btn: "Принять",
  warning_title: "Важно:",
  warning_i1: "• Конвертация необратима",
  warning_i2: "• Проверьте адрес кошелька",
  warning_i3: "• Внимательно выберите тип обработки",
  status_completed: "Завершена",
  status_pending: "Ожидает",
  status_processing: "В обработке",
  status_failed: "Ошибка",
  pending_locked: "Ожидает ({time})",
  available_withdraw: "Доступно для вывода",
  history_title: "История конвертаций",
  history_empty: "История конвертаций пуста",
  commission_fixed: "Комиссия (12%):",
  auto_withdraw_in: "Автоматический вывод через: {time}",
  release_date: "Дата освобождения:",
  wallet_label_history: "Кошелек:",
  convert_btn_accel: "Конвертировать (Ускоренно)",
  convert_btn_std: "Конвертировать (Стандартно)",
  converting: "Конвертация...",
  err_not_auth: "Пользователь не авторизован",
  err_input: "Введите корректное количество Stars",
  err_min: "Минимальная сумма для конвертации {min} Stars",
  err_not_enough: "Недостаточно Stars на балансе",
  err_wallet: "Введите адрес TON кошелька",
  err_agreement: "Необходимо принять пользовательское соглашение",
  err_rate: "Не удается рассчитать курс конвертации. Подождите обновления курса и попробуйте снова.",
  rules_important_title: "Важно знать!",
  rules_important_desc: "Согласно официальным правилам Telegram, после пополнения звёзды (Stars) временно недоступны для передачи в течение 21 дня.",
};

const en: Dict = {
  header_title: "Convert to TON",
  header_sub: "Stars → TON",
  tab_convert: "Convert",
  tab_history: "History",
  success_title: "Conversion successful!",
  success_desc: "TON has been sent to your wallet",
  error_title: "Error",
  balance_label: "Your balance:",
  stars_amount_label: "Stars to convert",
  max: "MAX",
  live_rate_info: "Rate updates every 10 seconds",
  ton_wallet_label: "TON wallet address",
  ton_wallet_placeholder: "UQA... or 0:...",
  ton_wallet_hint: "Enter your TON wallet address to receive coins",
  processing_type_title: "Choose processing type",
  standard_title: "Standard processing",
  standard_p1: "Wait for the 21-day period to finish",
  standard_p2: "Funds will be sent automatically after the period ends",
  standard_p3: "No extra deductions (0% fee)",
  accelerated_title: "Accelerated processing",
  accelerated_p1: "We send TON now without waiting",
  accelerated_p2: "Using the service's internal reserve",
  accelerated_p3: "Urgency fee: 12%",
  final_amount_title: "Final amount to receive:",
  base_amount: "Base amount:",
  commission_label: "Fee ({rate}%):",
  receive_label: "To receive:",
  agreement_more: "More about terms — ",
  agreement_link: "user agreement",
  agreement_title: "User Agreement",
  agreement_text_intro: "By using Stars to TON conversion, you agree to the following terms:",
  agreement_1: "1. Telegram rules",
  agreement_1_desc: "You agree with Telegram official rules regarding Stars and understand the 21-day transfer limitation after top up.",
  agreement_2: "2. Instant payout",
  agreement_2_desc: "Accelerated processing is an optional service. We provide TON immediately using internal reserves.",
  agreement_3: "3. Fees",
  agreement_3_desc: "A 12% fee is charged for accelerated processing. Standard processing has no fee.",
  agreement_4: "4. Responsibility",
  agreement_4_desc: "You are fully responsible for entering a correct TON wallet address. Conversions are irreversible.",
  agreement_5: "5. Legal",
  agreement_5_desc: "Our service is not a financial institution...",
  agreement_accept_label: "I have read and accept the terms",
  agreement_accept_btn: "Accept",
  warning_title: "Important:",
  warning_i1: "• Conversion is irreversible",
  warning_i2: "• Double-check the wallet address",
  warning_i3: "• Carefully choose processing type",
  status_completed: "Completed",
  status_pending: "Pending",
  status_processing: "Processing",
  status_failed: "Failed",
  pending_locked: "Pending ({time})",
  available_withdraw: "Available for withdrawal",
  history_title: "Conversion history",
  history_empty: "No conversions yet",
  commission_fixed: "Fee (12%):",
  auto_withdraw_in: "Auto withdrawal in: {time}",
  release_date: "Release date:",
  wallet_label_history: "Wallet:",
  convert_btn_accel: "Convert (Accelerated)",
  convert_btn_std: "Convert (Standard)",
  converting: "Converting...",
  err_not_auth: "User is not authorized",
  err_input: "Enter a valid Stars amount",
  err_min: "Minimum amount to convert is {min} Stars",
  err_not_enough: "Not enough Stars on balance",
  err_wallet: "Enter TON wallet address",
  err_agreement: "You must accept the user agreement",
  err_rate: "Cannot calculate conversion rate. Please wait for update and try again.",
  rules_important_title: "Important to know!",
  rules_important_desc: "According to Telegram rules, after top up Stars are temporarily non-transferable for 21 days.",
};

const dicts = { ru, en };

type Ctx = { t: (key: string, params?: Record<string, string | number>) => string };
const Ctx = createContext<Ctx | undefined>(undefined);

export const StarsToTonI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();
  const t = useCallback((key: string, params?: Record<string, string | number>) => {
    const dict = dicts[lang] || en;
    let text = dict[key] ?? key;
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        text = text.replace(new RegExp(`\{${k}\}`, 'g'), String(v));
      });
    }
    return text;
  }, [lang]);
  const value = useMemo(() => ({ t }), [t]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useStarsToTonI18n = () => {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useStarsToTonI18n must be used within StarsToTonI18nProvider");
  return ctx;
};
