"use client";
import React, { createContext, useCallback, useContext, useMemo } from "react";
import { useI18n } from "./I18nProvider";

type ChatDict = Record<string, string>;

const chatRu: ChatDict = {
  // Loading and errors
  loading_chat: "Загрузка чата...",
  error_loading_rooms: "Ошибка загрузки комнат",
  error_loading_messages: "Ошибка загрузки сообщений",
  error_sending_message: "Ошибка отправки сообщения",
  error_deleting_message: "Ошибка удаления сообщения",
  try_again: "Попробовать снова",

  // Chat interface
  write_message_placeholder: "Написать сообщение...",
  login_to_write: "Войдите чтобы писать сообщения",
  moderation_enabled: "Модерация включена",
  attach_files_soon: "Прикрепление файлов будет доступно в следующей версии",

  // Message actions
  delete_message: "Удалить сообщение",
  report_message: "Пожаловаться на сообщение",
  delete_confirmation: "Вы уверены, что хотите удалить это сообщение?",
  report_sent: "Жалоба на сообщение от {username} отправлена модераторам.",
  default_username: "Пользователь",

  // User roles
  admin: "Admin",
  moderator: "Mod",

  // Chat rules
  chat_rules_title: "Правила чата",
  rules_intro: "Перед началом общения в чате, пожалуйста, ознакомьтесь с правилами:",
  rule_no_insults: "Запрещены оскорбления",
  rule_no_spam: "Запрещен спам",
  rule_disputes_only_platform: "Споры разрешаются только через платформу",
  rules_agreement: "Я ознакомился с правилами чата и соглашаюсь их соблюдать",
  accept_rules: "Принять правила",
  accept_rules_check: "Поставьте галочку",
  hide_rules: "Скрыть",
};

const chatEn: ChatDict = {
  // Loading and errors
  loading_chat: "Loading chat...",
  error_loading_rooms: "Error loading rooms",
  error_loading_messages: "Error loading messages",
  error_sending_message: "Error sending message",
  error_deleting_message: "Error deleting message",
  try_again: "Try again",

  // Chat interface
  write_message_placeholder: "Write a message...",
  login_to_write: "Log in to write messages",
  moderation_enabled: "Moderation enabled",
  attach_files_soon: "File attachment will be available in the next version",

  // Message actions
  delete_message: "Delete message",
  report_message: "Report message",
  delete_confirmation: "Are you sure you want to delete this message?",
  report_sent: "Report for message from {username} sent to moderators.",
  default_username: "User",

  // User roles
  admin: "Admin",
  moderator: "Mod",

  // Chat rules
  chat_rules_title: "Chat Rules",
  rules_intro: "Before starting to chat, please read the rules:",
  rule_no_insults: "Insults are prohibited",
  rule_no_spam: "Spam is prohibited",
  rule_disputes_only_platform: "Disputes are resolved only through the platform",
  rules_agreement: "I have read the chat rules and agree to follow them",
  accept_rules: "Accept rules",
  accept_rules_check: "Check the box",
  hide_rules: "Hide",
};

const chatDicts = { ru: chatRu, en: chatEn };

type ChatI18nContextType = {
  t: (key: string, params?: Record<string, string>) => string;
};

const ChatI18nContext = createContext<ChatI18nContextType | undefined>(undefined);

export const ChatI18nProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { lang } = useI18n();

  const t = useCallback((key: string, params?: Record<string, string>) => {
    const dict = chatDicts[lang] || chatEn;
    let text = dict[key] ?? key;

    // Подстановка параметров (например, {username})
    if (params) {
      Object.entries(params).forEach(([paramKey, paramValue]) => {
        text = text.replace(new RegExp(`\\{${paramKey}\\}`, 'g'), paramValue);
      });
    }

    return text;
  }, [lang]);

  const value = useMemo(() => ({ t }), [t]);

  return <ChatI18nContext.Provider value={value}>{children}</ChatI18nContext.Provider>;
};

export const useChatI18n = () => {
  const ctx = useContext(ChatI18nContext);
  if (!ctx) throw new Error("useChatI18n must be used within ChatI18nProvider");
  return ctx;
};
