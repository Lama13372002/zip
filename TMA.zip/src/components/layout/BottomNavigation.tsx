"use client";

import React, { useState, useEffect, useRef } from "react";
import type { PageType } from "@/app/page";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Home,
  Plus,
  Users,
  MessageCircle,
  BarChart3,
  Menu
} from "lucide-react";
import { motion } from "framer-motion";
import { ChatService } from "@/lib/chat-service";
import { useTelegram } from "@/components/providers/TelegramProvider";
import { useI18n } from "@/components/providers/I18nProvider";

interface BottomNavigationProps {
  currentPage: PageType;
  onPageChange: (page: PageType) => void;
  isFullscreen?: boolean;
}

export const BottomNavigation = ({ currentPage, onPageChange, isFullscreen = false }: BottomNavigationProps) => {
  const { t } = useI18n();
  const [unreadCount, setUnreadCount] = useState(0);
  const [lastReadMessageId, setLastReadMessageId] = useState<number>(0);
  const { user } = useTelegram();

  // Функция для сохранения ID последнего прочитанного сообщения
  const saveLastReadMessageId = (messageId: number) => {
    setLastReadMessageId(messageId);
    if (typeof window !== 'undefined' && user?.id) {
      localStorage.setItem(`lastReadMessage_${user.id}`, messageId.toString());
    }
  };

  // Функция для получения ID последнего прочитанного сообщения
  const getLastReadMessageId = (): number => {
    if (typeof window !== 'undefined' && user?.id) {
      const saved = localStorage.getItem(`lastReadMessage_${user.id}`);
      return saved ? Number.parseInt(saved, 10) : 0;
    }
    return 0;
  };

  // Функция для очистки старых данных localStorage (опционально)
  const cleanupOldUserData = () => {
    if (typeof window !== 'undefined') {
      const keysToRemove: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key?.startsWith('lastReadMessage_') && user?.id && !key.includes(user.id.toString())) {
          keysToRemove.push(key);
        }
      }
      keysToRemove.forEach(key => localStorage.removeItem(key));
    }
  };

  // Функция для получения реального количества новых сообщений
  const getRealUnreadCount = async (): Promise<number> => {
    if (!user?.id) return 0;

    try {
      // Получаем все комнаты
      const rooms = await ChatService.getRooms();
      let totalNewMessages = 0;

      const userLastRead = getLastReadMessageId();

      for (const room of rooms) {
        // Получаем последние сообщения в каждой комнате
        const messages = await ChatService.getMessages(room.id, 50, 0);

        // Считаем сообщения, которые новее чем наш последний прочитанный
        const newMessagesInRoom = messages.filter(msg =>
          msg.id > userLastRead && msg.user_id !== user.id
        );

        totalNewMessages += newMessagesInRoom.length;
      }

      return totalNewMessages;
    } catch (error) {
      console.error('Error calculating real unread count:', error);
      return 0;
    }
  };

  // Функция для принудительного обновления счетчика (можно использовать извне)
  const forceUpdateUnreadCount = async () => {
    if (!user?.id) return;

    try {
      const realUnreadCount = await getRealUnreadCount();

      if (currentPage === 'chat') {
        setUnreadCount(0);
      } else {
        setUnreadCount(realUnreadCount);
      }
    } catch (error) {
      console.error('Error fetching unread count:', error);
    }
  };

  useEffect(() => {
    // Загружаем количество непрочитанных сообщений
    const fetchUnreadCount = async () => {
      if (!user?.id) return;

      try {
        // Простая логика:
        // 1. Если мы в чате - счетчик всегда 0
        // 2. Если мы не в чате - показываем реальное количество новых сообщений
        if (currentPage === 'chat') {
          setUnreadCount(0);
        } else {
          const realUnreadCount = await getRealUnreadCount();
          setUnreadCount(realUnreadCount);
        }
      } catch (error) {
        console.error('Error fetching unread count:', error);
        // При ошибке не меняем состояние
      }
    };

    fetchUnreadCount();

    // Обновляем каждые 2 секунды для более быстрой реакции
    const interval = setInterval(fetchUnreadCount, 2000);

    return () => clearInterval(interval);
  }, [user?.id, currentPage, lastReadMessageId, getRealUnreadCount]);

  // Отслеживание входа в чат (ТОЛЬКО при реальной смене страницы)
  const prevPageRef = useRef<PageType | null>(null);

  useEffect(() => {
    // Загружаем сообщения ТОЛЬКО при первом входе в чат, а не при каждом рендере
    if (user?.id && currentPage === 'chat' && prevPageRef.current !== 'chat') {
      console.log('🔄 Первый вход в чат - загружаем данные для счетчика');

      const saveLastMessageId = async () => {
        try {
          const rooms = await ChatService.getRooms();
          let maxMessageId = getLastReadMessageId();

          for (const room of rooms) {
            const messages = await ChatService.getMessages(room.id, 50, 0);
            if (messages.length > 0) {
              const roomMaxId = Math.max(...messages.map(m => m.id));
              maxMessageId = Math.max(maxMessageId, roomMaxId);
            }
            // Также отмечаем в базе данных как прочитанные
            ChatService.markAsRead(user.id, room.id).catch(console.error);
          }

          saveLastReadMessageId(maxMessageId);
          setUnreadCount(0);
        } catch (error) {
          console.error('Error saving last message ID:', error);
        }
      };

      saveLastMessageId();
    }

    prevPageRef.current = currentPage;
  }, [currentPage, user?.id, getLastReadMessageId, saveLastReadMessageId]);

  // Загрузка/сброс состояния при смене пользователя
  useEffect(() => {
    if (user?.id) {
      // При смене пользователя загружаем его персональное состояние
      const userLastRead = getLastReadMessageId();
      setLastReadMessageId(userLastRead);

      // Сбрасываем счетчик при смене пользователя
      setUnreadCount(0);

      // Очищаем данные других пользователей (опционально)
      cleanupOldUserData();
    } else {
      // Если пользователя нет - сбрасываем состояние
      setLastReadMessageId(0);
      setUnreadCount(0);
    }
  }, [user?.id, cleanupOldUserData, getLastReadMessageId]);

  // Оптимизируем структуру навигации - создаем динамически
  const navItems = [
    { id: "home", icon: Home, label: t("nav_home") },
    { id: "open-bets", icon: Users, label: t("nav_open_bets") },
    { id: "create-bet", icon: Plus, label: t("nav_create") },
    { id: "chat", icon: MessageCircle, label: t("nav_chat"), badge: (currentPage !== 'chat' && unreadCount > 0) ? unreadCount : undefined },
    { id: "my-bets", icon: BarChart3, label: t("nav_my") },
    { id: "menu", icon: Menu, label: t("nav_menu") },
  ];
  return (
    <div
      className={`fixed bottom-0 left-0 right-0 z-50 px-3 pb-3 ${isFullscreen ? 'bottom-nav-safe pb-[calc(0.75rem+var(--system-safe-bottom))]' : 'pb-3'}`}
    >
      {/* Стильное овальное меню */}
      <div className="relative">
        <div className="absolute inset-0 rounded-full blur-md bg-background/50 backdrop-blur-md"></div>
        <nav className="glass relative rounded-full border border-white/20 shadow-xl backdrop-blur-md flex items-center justify-between px-4 py-3">
          <div className="flex justify-between w-full items-center">
            {/* Все кнопки в одной линии */}
            <div className="flex justify-between w-full space-x-1 items-center">
              {navItems.map((item) => {
                const isActive = currentPage === item.id;

                return (
                  <motion.div
                    key={item.id}
                    whileTap={{ scale: 0.9 }}
                    className="relative"
                  >
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onPageChange(item.id as PageType)}
                      className={`
                        relative flex flex-col items-center justify-center h-12 w-12
                        ${isActive
                          ? 'text-primary bg-primary/10'
                          : 'text-foreground/60 hover:text-foreground hover:bg-background/50'
                        }
                        transition-all duration-200 ease-in-out
                      `}
                    >
                      <item.icon className="h-4 w-4" />
                      <span className="text-xs mt-1 font-medium">{item.label}</span>

                      {/* Badge для непрочитанных сообщений */}
                      {item.badge && item.badge > 0 && (
                        <Badge
                          variant="destructive"
                          className="absolute -top-1 -right-1 h-5 w-5 text-xs p-0 flex items-center justify-center rounded-full bg-red-500 text-white"
                        >
                          {item.badge > 99 ? '99+' : item.badge}
                        </Badge>
                      )}
                    </Button>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
};
