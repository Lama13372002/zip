'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { UserX, MessageCircleOff, Shield, Calendar } from 'lucide-react';

interface BlockedUser {
  id: number;
  telegram_id: string;
  is_blocked_app: boolean;
  is_blocked_chat: boolean;
  blocked_at: string | null;
  block_reason: string | null;
  first_name: string | null;
  username: string | null;
}

interface BlockedUserModalProps {
  telegramId: string;
  onBlockStatusChange?: (isBlocked: boolean) => void;
}

export default function BlockedUserModal({ telegramId, onBlockStatusChange }: BlockedUserModalProps) {
  const [blockedUser, setBlockedUser] = useState<BlockedUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    checkBlockStatus();
  }, [telegramId]);

  const checkBlockStatus = async () => {
    try {
      setLoading(true);
      const response = await fetch(`/api/user/check-block-status?telegramId=${telegramId}`);
      const data = await response.json();

      if (data.success) {
        const user = data.user;

        // Если пользователь заблокирован
        if (user.is_blocked_app || user.is_blocked_chat) {
          setBlockedUser(user);
          onBlockStatusChange?.(true);
        } else {
          setBlockedUser(null);
          onBlockStatusChange?.(false);
        }
      } else {
        setError(data.error);
        onBlockStatusChange?.(false);
      }
    } catch (error) {
      console.error('Ошибка при проверке статуса блокировки:', error);
      setError('Ошибка при проверке статуса');
      onBlockStatusChange?.(false);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ru-RU', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getUserDisplayName = (user: BlockedUser) => {
    const name = user.first_name || '';
    const username = user.username ? `@${user.username}` : '';
    return name || username || `ID: ${user.telegram_id}`;
  };

  // Если нет блокировки, ничего не показываем
  if (!blockedUser || loading) {
    return null;
  }

  // Если заблокирован только чат, показываем предупреждение, но позволяем пользоваться приложением
  if (blockedUser.is_blocked_chat && !blockedUser.is_blocked_app) {
    return (
      <div className="fixed top-0 left-0 right-0 z-50 p-4">
        <Alert className="border-orange-500 bg-orange-50 max-w-md mx-auto">
          <MessageCircleOff className="h-4 w-4 text-orange-600" />
          <AlertDescription className="text-orange-700">
            <div className="font-medium mb-1">Ограничение доступа к чату</div>
            <div className="text-sm">
              Ваш доступ к чату ограничен администратором.
              {blockedUser.block_reason && (
                <div className="mt-1">
                  <strong>Причина:</strong> {blockedUser.block_reason}
                </div>
              )}
            </div>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Если заблокировано приложение - показываем полноэкранную блокировку
  if (blockedUser.is_blocked_app) {
    return (
      <div className="fixed inset-0 bg-white z-[9999] flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-red-200">
          <CardHeader className="text-center pb-4">
            <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
              <UserX className="w-8 h-8 text-red-600" />
            </div>
            <CardTitle className="text-2xl font-bold text-red-700">
              Доступ заблокирован
            </CardTitle>
            <CardDescription className="text-red-600">
              Ваш аккаунт заблокирован администратором
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center gap-2 text-red-700 font-medium mb-2">
                <Shield className="w-4 h-4" />
                Информация о блокировке
              </div>

              <div className="space-y-2 text-sm text-red-600">
                <div>
                  <strong>Пользователь:</strong> {getUserDisplayName(blockedUser)}
                </div>

                {blockedUser.blocked_at && (
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    <span>
                      <strong>Дата блокировки:</strong> {formatDate(blockedUser.blocked_at)}
                    </span>
                  </div>
                )}

                {blockedUser.block_reason && (
                  <div className="mt-3 p-3 bg-white border border-red-200 rounded">
                    <strong>Причина блокировки:</strong>
                    <div className="mt-1">{blockedUser.block_reason}</div>
                  </div>
                )}
              </div>
            </div>

            <div className="text-center text-sm text-gray-600">
              Для получения дополнительной информации или оспаривания блокировки
              обратитесь к администратору.
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return null;
}
