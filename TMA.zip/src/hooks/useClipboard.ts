import { useState, useCallback, useEffect } from 'react';

interface UseClipboardReturn {
  clipboardText: string;
  isSupported: boolean;
  readFromClipboard: () => Promise<string>;
  writeToClipboard: (text: string) => Promise<void>;
  pasteText: (setValue: (value: string) => void) => Promise<void>;
}

export const useClipboard = (): UseClipboardReturn => {
  const [clipboardText, setClipboardText] = useState('');

  // Проверяем поддержку различных методов доступа к буферу
  const isTelegramWebApp = Boolean(typeof window !== 'undefined' && window.Telegram?.WebApp);
  const hasClipboardAPI = Boolean(
    typeof navigator !== 'undefined' &&
    navigator.clipboard && navigator.clipboard.readText
  );
  const isSupported = isTelegramWebApp || hasClipboardAPI;

  const readFromClipboard = useCallback(async (): Promise<string> => {
    try {
      console.log('🔍 Clipboard debug info:', {
        isTelegramWebApp,
        hasTelegram: !!window.Telegram,
        hasWebApp: !!window.Telegram?.WebApp,
        hasReadMethod: !!window.Telegram?.WebApp?.readTextFromClipboard,
        webAppVersion: window.Telegram?.WebApp?.version,
        userAgent: navigator.userAgent
      });

      // Приоритет: Telegram WebApp API (требует версию 6.4+)
      if (isTelegramWebApp && window.Telegram?.WebApp) {
        const webApp = window.Telegram.WebApp;

        // Проверяем версию WebApp
        if (webApp.isVersionAtLeast && webApp.isVersionAtLeast('6.4') && webApp.readTextFromClipboard) {
          console.log('📱 Using Telegram WebApp clipboard API');

          return new Promise((resolve) => {
            // Устанавливаем обработчик события
            const handleClipboardReceived = (eventData?: unknown) => {
              console.log('📋 Telegram clipboard event received:', eventData);
              const text = (eventData as { data?: string })?.data || (eventData as string) || '';
              setClipboardText(text);

              // Убираем обработчик после получения данных
              if (webApp.offEvent) {
                webApp.offEvent('clipboardTextReceived', handleClipboardReceived);
              }

              resolve(text);
            };

            // Регистрируем обработчик события
            if (webApp.onEvent) {
              webApp.onEvent('clipboardTextReceived', handleClipboardReceived);
            }

            // Запрашиваем данные из буфера
            webApp.readTextFromClipboard!();

            // Таймаут на случай если событие не придет
            setTimeout(() => {
              if (webApp.offEvent) {
                webApp.offEvent('clipboardTextReceived', handleClipboardReceived);
              }
              resolve('');
            }, 5000);
          });
        } else {
          console.warn('⚠️ Telegram WebApp version too old for clipboard API or method not available');
        }
      }

      // Fallback: современный Clipboard API (работает в обычных браузерах)
      if (navigator.clipboard && navigator.clipboard.readText) {
        console.log('🌐 Attempting standard Clipboard API');
        try {
          const text = await navigator.clipboard.readText();
          console.log('📋 Standard clipboard result:', { text, length: text?.length });
          setClipboardText(text);
          return text;
        } catch (clipboardError) {
          console.warn('Standard clipboard failed:', clipboardError);
        }
      }

      // Последний fallback - показываем пользователю инструкцию
      console.log('🔧 No clipboard access available, returning empty');
      return '';

    } catch (error) {
      console.error('Failed to read from clipboard:', error);
      return '';
    }
  }, [isTelegramWebApp]);

  const writeToClipboard = useCallback(async (text: string): Promise<void> => {
    try {
      // Приоритет: Telegram WebApp API
      if (isTelegramWebApp && window.Telegram?.WebApp?.writeTextToClipboard) {
        console.log('📱 Using Telegram WebApp clipboard write API');
        return new Promise((resolve) => {
          window.Telegram!.WebApp!.writeTextToClipboard!(text, () => {
            console.log('📋 Text written to Telegram clipboard');
            setClipboardText(text);
            resolve();
          });
        });
      }

      // Fallback: стандартный Clipboard API
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
        setClipboardText(text);
        return;
      }

      // Последний fallback для старых браузеров
      const textArea = document.createElement('textarea');
      textArea.value = text;
      textArea.style.position = 'fixed';
      textArea.style.left = '-9999px';
      textArea.style.top = '-9999px';
      textArea.style.opacity = '0';
      document.body.appendChild(textArea);

      textArea.focus();
      textArea.select();

      try {
        document.execCommand('copy');
        setClipboardText(text);
      } catch (err) {
        console.error('Fallback copy failed:', err);
      } finally {
        document.body.removeChild(textArea);
      }
    } catch (error) {
      console.error('Failed to write to clipboard:', error);
    }
  }, [isTelegramWebApp]);

  const pasteText = useCallback(async (setValue: (value: string) => void): Promise<void> => {
    try {
      const text = await readFromClipboard();
      if (text && text.trim()) {
        setValue(text.trim());
      }
    } catch (error) {
      console.error('Failed to paste text:', error);
    }
  }, [readFromClipboard]);

  return {
    clipboardText,
    isSupported,
    readFromClipboard,
    writeToClipboard,
    pasteText,
  };
};
