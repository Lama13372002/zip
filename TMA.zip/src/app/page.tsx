"use client";

import { useState, useEffect, useRef, Suspense } from "react";
import { useTelegram } from "@/components/providers/TelegramProvider";
import { useTelegramAuth } from "@/hooks/useTelegramAuth";
import { AuthDialog } from "@/components/auth/AuthDialog";
import { MainLayout } from "@/components/layout/MainLayout";
import { HomePage } from "@/components/pages/HomePage";
import { CreateBetPage } from "@/components/pages/CreateBetPage";
import { OpenBetsPage } from "@/components/pages/OpenBetsPage";
import { ChatPage } from "@/components/pages/ChatPage";
import { MyBetsPage } from "@/components/pages/MyBetsPage";
import { MenuPage } from "@/components/pages/MenuPage";
import { useI18n } from "@/components/providers/I18nProvider";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { preloadService } from "@/lib/preload-service";

export type PageType = "home" | "create-bet" | "open-bets" | "chat" | "my-bets" | "menu";

function AppInner() {
  const { isReady, user } = useTelegram();
  const { userData, isLoading, error } = useTelegramAuth();
  const { t } = useI18n();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  const [currentPage, setCurrentPage] = useState<PageType>("home");
  const [isFirstTime, setIsFirstTime] = useState(true);
  const [isChatInputFocused, setIsChatInputFocused] = useState(false);
  const [isCreateBetInputFocused, setIsCreateBetInputFocused] = useState(false);

  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  // Предзагрузка футбольных данных сразу при готовности Telegram
  useEffect(() => {
    if (isReady) {
      // Запускаем предзагрузку данных о командах сразу
      preloadService.preloadFootballData();
    }
  }, [isReady]);

  useEffect(() => {
    if (isReady) {
      if (user) {
        // Создаем уникальный ключ для каждого пользователя Telegram
        const userKey = `sports_betting_visited_${user.id}`;
        const hasVisited = localStorage.getItem(userKey);

        // Устанавливаем аутентификацию только после успешной регистрации в БД
        if (userData && !isLoading) {
          setIsAuthenticated(true);
          console.log('✅ Пользователь успешно зарегистрирован в БД:', userData);
        }

        // Если пользователь есть, но это первый визит - показываем онбординг
        if (!hasVisited) {
          setIsFirstTime(true);
          setShowAuthDialog(true);
        } else {
          setIsFirstTime(false);
        }

        // Показываем ошибку, если не удалось зарегистрировать пользователя
        if (error) {
          console.error('❌ Ошибка регистрации пользователя:', error);
        }
      } else {
        // Если пользователя нет - показываем авторизацию
        setShowAuthDialog(true);
        setIsFirstTime(true);
      }
    }
  }, [isReady, user, userData, isLoading, error]);

  // Синхронизация состояния страницы с URL
  useEffect(() => {
    // Определяем страницу из pathname или query ?page=
    const pageFromQuery = (searchParams?.get('page') as PageType) || undefined;
    let page: PageType = "home";
    if (pathname === "/") page = pageFromQuery || "home";
    setCurrentPage(page);
  }, [pathname, searchParams]);

  // Очистка выбранного матча при покидании страницы создания спора
  const prevPageRef = useRef<PageType>("home");
  useEffect(() => {
    if (prevPageRef.current === "create-bet" && currentPage !== "create-bet" && currentPage !== "home") {
      try {
        localStorage.removeItem('selectedEvent');
        localStorage.removeItem('navigateBackTo');
      } catch {}
    }
    prevPageRef.current = currentPage;
  }, [currentPage]);

  const handleLogin = () => {
    setIsAuthenticated(true);
    setShowAuthDialog(false);
    setIsFirstTime(false);
    // Отмечаем, что пользователь уже был здесь (используем уникальный ключ)
    if (user) {
      const userKey = `sports_betting_visited_${user.id}`;
      localStorage.setItem(userKey, 'true');
    }
  };

  const renderPage = () => {
    switch (currentPage) {
      case "home":
        return <HomePage onPageChange={(p) => {
          setCurrentPage(p);
          if (p === "home") router.push("/");
          else router.push(`/?page=${p}`);
        }} />;
      case "create-bet":
        return <CreateBetPage onBack={() => {
          setCurrentPage("home");
          router.push("/");
        }} onInputFocusChange={setIsCreateBetInputFocused} />;
      case "open-bets":
        return <OpenBetsPage />;
      case "chat":
        return <ChatPage
          onInputFocusChange={setIsChatInputFocused}
          currentUser={userData ? {
            id: userData.id,
            username: userData.username,
            first_name: userData.first_name,
            last_name: userData.last_name,
            role: userData.id === 1 ? 'admin' : 'user' // Первый пользователь - админ
          } : undefined}
        />;
      case "my-bets":
        return <MyBetsPage />;
      case "menu":
        return <MenuPage />;
      default:
        return <HomePage onPageChange={(p) => {
          setCurrentPage(p);
          if (p === "home") router.push("/");
          else router.push(`/?page=${p}`);
        }} />;
    }
  };

  if (!isReady || (user && isLoading)) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="mt-2 text-muted-foreground">
            {!isReady ? t('loading') : t('registering_user')}
          </p>
          {error && (
            <p className="mt-2 text-red-500 text-sm">
              {t('error')}: {error}
            </p>
          )}
        </div>
      </div>
    );
  }

  return (
    <>
      <AuthDialog
        open={showAuthDialog}
        onLogin={handleLogin}
        onSkip={() => {
          setShowAuthDialog(false);
          setIsFirstTime(false);
          // Отмечаем, что пользователь уже был здесь (используем уникальный ключ)
          if (user) {
            const userKey = `sports_betting_visited_${user.id}`;
            localStorage.setItem(userKey, 'true');
          }
        }}
        isFirstTime={isFirstTime}
        user={user}
      />

      {isAuthenticated && (
        <MainLayout
          currentPage={currentPage}
          onPageChange={(p) => {
            setCurrentPage(p);
            if (p === "home") router.push("/");
            else router.push(`/?page=${p}`);
          }}
          hideBottomNav={(currentPage === "chat" && isChatInputFocused) || (currentPage === "create-bet" && isCreateBetInputFocused)}
        >
          {renderPage()}
        </MainLayout>
      )}
    </>
  );
}

export default function App() {
  return (
    <Suspense>
      <AppInner />
    </Suspense>
  );
}
