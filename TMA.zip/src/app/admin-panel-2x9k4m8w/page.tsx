'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Eye, EyeOff, Settings, DollarSign, Users, TrendingUp, Bell, BarChart3 } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import UsersManagement from '@/components/admin/UsersManagement';
import StatisticsPanel from '@/components/admin/StatisticsPanel';

interface Setting {
  setting_key: string;
  setting_value: string;
  description: string;
  created_at: string;
  updated_at: string;
}

interface PushResult {
  totalUsers: number;
  successCount: number;
  errorCount: number;
  errorBreakdown: {
    chatNotFound: number;
    botBlocked: number;
    userDeactivated: number;
    rateLimited: number;
    other: number;
  };
  errors: string[];
}

export default function AdminPanel() {
  const [minimumUsdAmount, setMinimumUsdAmount] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'success' | 'error'>('success');
  const [allSettings, setAllSettings] = useState<Setting[]>([]);

  // Состояние для push-уведомлений
  const [pushMessage, setPushMessage] = useState('');
  const [pushLoading, setPushLoading] = useState(false);
  const [pushResult, setPushResult] = useState<PushResult | null>(null);

  // Загружаем текущую минимальную сумму при аутентификации
  useEffect(() => {
    if (isAuthenticated) {
      loadMinimumUsdAmount();
      loadAllSettings();
    }
  }, [isAuthenticated]);

  const loadMinimumUsdAmount = async () => {
    try {
      const response = await fetch('/api/admin/minimum-usd-amount');
      const data = await response.json();

      if (data.success) {
        setMinimumUsdAmount(data.minimumUsdAmount.toString());
      }
    } catch (error) {
      console.error('Ошибка при загрузке минимальной суммы в USD:', error);
    }
  };

  const loadAllSettings = async () => {
    try {
      const response = await fetch(`/api/admin/settings?adminPassword=${adminPassword}`);
      const data = await response.json();

      if (data.success) {
        setAllSettings(data.settings);
      }
    } catch (error) {
      console.error('Ошибка при загрузке настроек:', error);
    }
  };

  const handleAuth = async () => {
    if (!adminPassword) {
      setMessage('Введите пароль администратора');
      setMessageType('error');
      return;
    }

    setLoading(true);
    try {
      // Простая проверка авторизации через API настроек
      const response = await fetch(`/api/admin/settings?adminPassword=${adminPassword}`);
      const data = await response.json();

      if (data.success) {
        setIsAuthenticated(true);
        setMessage('Авторизация успешна');
        setMessageType('success');
      } else {
        setMessage('Неверный пароль администратора');
        setMessageType('error');
      }
    } catch (error) {
      setMessage('Ошибка при авторизации');
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateMinimumAmount = async () => {
    if (!minimumUsdAmount) {
      setMessage('Введите минимальную сумму в долларах');
      setMessageType('error');
      return;
    }

    setLoading(true);
    try {
      const response = await fetch('/api/admin/minimum-usd-amount', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          minimumUsdAmount: parseFloat(minimumUsdAmount),
          adminPassword
        }),
      });

      const data = await response.json();

      if (data.success) {
        setMessage(data.message);
        setMessageType('success');
        loadAllSettings(); // Перезагружаем все настройки
      } else {
        setMessage(data.error);
        setMessageType('error');
      }
    } catch (error) {
      setMessage('Ошибка при обновлении настроек');
      setMessageType('error');
    } finally {
      setLoading(false);
    }
  };

  const handleSendPush = async () => {
    if (!pushMessage.trim()) {
      setMessage('Введите текст сообщения');
      setMessageType('error');
      return;
    }

    if (!confirm('Вы уверены, что хотите отправить push-уведомление всем пользователям?')) {
      return;
    }

    setPushLoading(true);
    setPushResult(null);

    try {
      const response = await fetch('/api/admin/send-push', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: pushMessage,
          adminPassword
        }),
      });

      const data = await response.json();

      if (data.success) {
        setPushResult(data.statistics);
        setMessage(`Push-уведомления отправлены! Успешно: ${data.statistics.successCount}, Ошибок: ${data.statistics.errorCount}`);
        setMessageType('success');
        setPushMessage(''); // Очищаем поле после успешной отправки
      } else {
        setMessage(data.error || 'Ошибка при отправке push-уведомлений');
        setMessageType('error');
      }
    } catch (error) {
      setMessage('Ошибка при отправке push-уведомлений');
      setMessageType('error');
    } finally {
      setPushLoading(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <Settings className="w-6 h-6 text-blue-600" />
            </div>
            <CardTitle className="text-2xl font-bold text-gray-900">Админ панель</CardTitle>
            <CardDescription>
              Введите пароль для доступа к панели администратора
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="password">Пароль администратора</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  placeholder="Введите пароль"
                  onKeyPress={(e) => e.key === 'Enter' && handleAuth()}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>

            {message && (
              <Alert className={messageType === 'error' ? 'border-red-500 bg-red-50' : 'border-green-500 bg-green-50'}>
                <AlertDescription className={messageType === 'error' ? 'text-red-700' : 'text-green-700'}>
                  {message}
                </AlertDescription>
              </Alert>
            )}

            <Button
              onClick={handleAuth}
              disabled={loading}
              className="w-full"
            >
              {loading ? 'Проверка...' : 'Войти'}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Заголовок */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-3xl font-bold flex items-center gap-2 text-gray-900">
                  <Settings className="w-8 h-8 text-blue-600" />
                  Админ панель TMA
                </CardTitle>
                <CardDescription>
                  Управление настройками платформы ставок
                </CardDescription>
              </div>
              <Button
                variant="outline"
                onClick={() => setIsAuthenticated(false)}
              >
                Выйти
              </Button>
            </div>
          </CardHeader>
        </Card>

        {/* Быстрая статистика */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-green-600" />
                <div>
                  <p className="text-sm text-gray-800">Мин. сумма ставки</p>
                  <p className="text-2xl font-bold text-gray-900">${minimumUsdAmount} USD</p>
                  <p className="text-xs text-gray-700">Автоматически в TON</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="text-sm text-gray-800">Всего настроек</p>
                  <p className="text-2xl font-bold text-gray-900">{allSettings.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-purple-600" />
                <div>
                  <p className="text-sm text-gray-800">Статус</p>
                  <Badge variant="default" className="bg-green-100 text-green-800">
                    Активен
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Вкладки управления */}
        <Tabs defaultValue="statistics" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="statistics" className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4" />
              Статистика
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Настройки
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              Пользователи
            </TabsTrigger>
            <TabsTrigger value="push" className="flex items-center gap-2">
              <Bell className="w-4 h-4" />
              Push
            </TabsTrigger>
          </TabsList>

          <TabsContent value="statistics" className="space-y-6">
            <StatisticsPanel adminPassword={adminPassword} />
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            {/* Форма изменения минимальной суммы */}
            <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="w-5 h-5" />
              Минимальная сумма ставки
            </CardTitle>
            <CardDescription>
              Измените минимальную сумму в долларах. Автоматически пересчитается в TON по текущему курсу
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="minimumAmount">Минимальная сумма (USD)</Label>
              <div className="flex gap-2">
                <Input
                  id="minimumAmount"
                  type="number"
                  step="0.01"
                  min="0.1"
                  value={minimumUsdAmount}
                  onChange={(e) => setMinimumUsdAmount(e.target.value)}
                  placeholder="Введите минимальную сумму в долларах"
                  className="flex-1"
                />
                <Button
                  onClick={handleUpdateMinimumAmount}
                  disabled={loading}
                  className="min-w-[120px]"
                >
                  {loading ? 'Сохранение...' : 'Сохранить'}
                </Button>
              </div>
            </div>

            {message && (
              <Alert className={messageType === 'error' ? 'border-red-500 bg-red-50' : 'border-green-500 bg-green-50'}>
                <AlertDescription className={messageType === 'error' ? 'text-red-700' : 'text-green-700'}>
                  {message}
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Все настройки */}
        <Card>
          <CardHeader>
            <CardTitle>Все настройки приложения</CardTitle>
            <CardDescription>
              Просмотр всех настроек в базе данных
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {allSettings.map((setting, index) => (
                <div key={setting.setting_key}>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline">{setting.setting_key}</Badge>
                        <span className="text-sm text-gray-700">
                          Обновлено: {new Date(setting.updated_at).toLocaleString('ru')}
                        </span>
                      </div>
                      <p className="font-mono text-sm bg-gray-100 p-2 rounded text-gray-900">
                        {setting.setting_value}
                      </p>
                      {setting.description && (
                        <p className="text-sm text-gray-800 mt-1">
                          {setting.description}
                        </p>
                      )}
                    </div>
                  </div>
                  {index < allSettings.length - 1 && <Separator className="mt-4" />}
                </div>
              ))}

              {allSettings.length === 0 && (
                <div className="text-center py-8 text-gray-700">
                  Настройки не найдены
                </div>
              )}
            </div>
          </CardContent>
        </Card>
          </TabsContent>

          <TabsContent value="users">
            <UsersManagement adminPassword={adminPassword} />
          </TabsContent>

          <TabsContent value="push" className="space-y-6">
            {/* Форма отправки push-уведомлений */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  Массовая отправка push-уведомлений
                </CardTitle>
                <CardDescription>
                  Отправить уведомление всем пользователям бота. Сообщение будет доставлено напрямую в Telegram.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="pushMessage">Текст сообщения</Label>
                  <Textarea
                    id="pushMessage"
                    value={pushMessage}
                    onChange={(e) => setPushMessage(e.target.value)}
                    placeholder="Введите текст push-уведомления..."
                    className="min-h-[120px] resize-vertical"
                    disabled={pushLoading}
                  />
                  <div className="text-sm text-gray-700">
                    Поддерживается HTML разметка: &lt;b&gt;жирный&lt;/b&gt;, &lt;i&gt;курсив&lt;/i&gt;, &lt;code&gt;код&lt;/code&gt;
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={handleSendPush}
                    disabled={pushLoading || !pushMessage.trim()}
                    className="min-w-[150px]"
                  >
                    {pushLoading ? 'Отправка...' : 'Отправить всем'}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setPushMessage('')}
                    disabled={pushLoading}
                  >
                    Очистить
                  </Button>
                </div>

                {message && (
                  <Alert className={messageType === 'error' ? 'border-red-500 bg-red-50' : 'border-green-500 bg-green-50'}>
                    <AlertDescription className={messageType === 'error' ? 'text-red-700' : 'text-green-700'}>
                      {message}
                    </AlertDescription>
                  </Alert>
                )}

                {/* Результаты отправки */}
                {pushResult && (
                  <Card className="border-green-200 bg-green-50">
                    <CardHeader>
                      <CardTitle className="text-lg text-green-800">Результаты отправки</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-3 gap-4 mb-6">
                        <div className="text-center">
                          <div className="text-2xl font-bold text-blue-600">{pushResult.totalUsers}</div>
                          <div className="text-sm text-gray-800">Всего пользователей</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-green-600">{pushResult.successCount}</div>
                          <div className="text-sm text-gray-800">Успешно отправлено</div>
                        </div>
                        <div className="text-center">
                          <div className="text-2xl font-bold text-red-600">{pushResult.errorCount}</div>
                          <div className="text-sm text-gray-800">Всего ошибок</div>
                        </div>
                      </div>

                      {/* Детальная статистика ошибок */}
                      {pushResult.errorCount > 0 && (
                        <div className="mb-4">
                          <h4 className="font-semibold text-gray-700 mb-3">Детализация ошибок:</h4>
                          <div className="grid grid-cols-2 gap-3 text-sm">
                            {pushResult.errorBreakdown.chatNotFound > 0 && (
                              <div className="flex justify-between p-2 bg-yellow-100 rounded">
                                <span>Чат не найден:</span>
                                <Badge variant="outline" className="bg-yellow-200">{pushResult.errorBreakdown.chatNotFound}</Badge>
                              </div>
                            )}
                            {pushResult.errorBreakdown.botBlocked > 0 && (
                              <div className="flex justify-between p-2 bg-red-100 rounded">
                                <span>Бот заблокирован:</span>
                                <Badge variant="outline" className="bg-red-200">{pushResult.errorBreakdown.botBlocked}</Badge>
                              </div>
                            )}
                            {pushResult.errorBreakdown.userDeactivated > 0 && (
                              <div className="flex justify-between p-2 bg-gray-100 rounded">
                                <span>Аккаунт деактивирован:</span>
                                <Badge variant="outline" className="bg-gray-200">{pushResult.errorBreakdown.userDeactivated}</Badge>
                              </div>
                            )}
                            {pushResult.errorBreakdown.rateLimited > 0 && (
                              <div className="flex justify-between p-2 bg-orange-100 rounded">
                                <span>Превышен лимит:</span>
                                <Badge variant="outline" className="bg-orange-200">{pushResult.errorBreakdown.rateLimited}</Badge>
                              </div>
                            )}
                            {pushResult.errorBreakdown.other > 0 && (
                              <div className="flex justify-between p-2 bg-purple-100 rounded">
                                <span>Другие ошибки:</span>
                                <Badge variant="outline" className="bg-purple-200">{pushResult.errorBreakdown.other}</Badge>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      {pushResult.errors && pushResult.errors.length > 0 && (
                        <div>
                          <h4 className="font-semibold text-red-700 mb-2">Примеры ошибок:</h4>
                          <div className="max-h-40 overflow-y-auto">
                            <ul className="list-disc list-inside text-sm text-red-600 space-y-1">
                              {pushResult.errors.map((error, index) => (
                                <li key={index} className="break-words">{error}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                )}
              </CardContent>
            </Card>

            {/* Информация об ошибках */}
            <Card className="border-blue-200 bg-blue-50">
              <CardContent className="p-4">
                <div className="flex items-start gap-2">
                  <div className="w-5 h-5 text-blue-600 mt-0.5">ℹ️</div>
                  <div>
                    <h4 className="font-semibold text-blue-800">О возможных ошибках доставки</h4>
                    <ul className="text-sm text-blue-700 mt-1 space-y-1">
                      <li>• <strong>"Чат не найден"</strong> - пользователь никогда не писал боту или удалил аккаунт</li>
                      <li>• <strong>"Бот заблокирован"</strong> - пользователь заблокировал бота в Telegram</li>
                      <li>• <strong>"Аккаунт деактивирован"</strong> - пользователь удалил свой Telegram аккаунт</li>
                      <li>• Это нормальные ошибки для любой системы массовых рассылок</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Предупреждение */}
            <Card className="border-yellow-200 bg-yellow-50">
              <CardContent className="p-4">
                <div className="flex items-start gap-2">
                  <div className="w-5 h-5 text-yellow-600 mt-0.5">⚠️</div>
                  <div>
                    <h4 className="font-semibold text-yellow-800">Важная информация</h4>
                    <ul className="text-sm text-yellow-700 mt-1 space-y-1">
                      <li>• Уведомления отправляются всем активным пользователям</li>
                      <li>• Заблокированные в приложении пользователи не получат уведомления</li>
                      <li>• Между отправками есть задержка для соблюдения лимитов Telegram</li>
                      <li>• Используйте эту функцию ответственно</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
