import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';
import type { PredictionType } from '@/types/bets';
import type { PoolClient } from 'pg';

export async function POST(request: NextRequest) {
  try {
    const { bet_id, home_score, away_score } = await request.json();

    if (!bet_id || home_score === undefined || away_score === undefined) {
      return NextResponse.json({
        success: false,
        error: 'Missing required fields: bet_id, home_score, away_score'
      }, { status: 400 });
    }

    const client = await pool.connect();

    try {
      // Получаем информацию о ставке
      const betResult = await client.query(`
        SELECT
          b.*,
          m.id as match_id,
          m.home_team,
          m.away_team,
          m.league
        FROM bets b
        JOIN matches m ON b.match_id = m.id
        WHERE b.id = $1 AND b.status = 'closed'
      `, [bet_id]);

      if (betResult.rows.length === 0) {
        return NextResponse.json({
          success: false,
          error: 'Bet not found or not in closed status'
        }, { status: 404 });
      }

      const bet = betResult.rows[0];

      // Определяем результат матча
      let matchResult: PredictionType;
      if (home_score > away_score) {
        matchResult = 'home';
      } else if (home_score < away_score) {
        matchResult = 'away';
      } else {
        matchResult = 'draw';
      }

      console.log(`🏆 Manually completing bet ${bet_id}: ${bet.home_team} ${home_score}-${away_score} ${bet.away_team} (Result: ${matchResult})`);

      // Обновляем матч в базе данных
      await client.query(`
        UPDATE matches
        SET status = 'finished', home_score = $1, away_score = $2, updated_at = CURRENT_TIMESTAMP
        WHERE id = $3
      `, [home_score, away_score, bet.match_id]);

      // Завершаем ставку
      const completeResult = await completeBet(bet_id, matchResult, client);

      if (completeResult.success) {
        return NextResponse.json({
          success: true,
          bet_id,
          match: `${bet.home_team} vs ${bet.away_team}`,
          score: `${home_score}-${away_score}`,
          result: matchResult,
          message: 'Bet completed successfully'
        });
      } else {
        return NextResponse.json({
          success: false,
          error: `Failed to complete bet: ${completeResult.error}`
        }, { status: 500 });
      }

    } finally {
      client.release();
    }

  } catch (error) {
    console.error('Error in manual-complete-bet:', error);
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

// Скопированная функция завершения ставки
async function completeBet(betId: number, winningPrediction: PredictionType, client: PoolClient): Promise<{success: boolean, error?: string}> {
  try {
    await client.query('BEGIN');

    // Получаем информацию о споре
    const betResult = await client.query(`
      SELECT
        b.*,
        m.home_team,
        m.away_team,
        m.league
      FROM bets b
      JOIN matches m ON b.match_id = m.id
      WHERE b.id = $1
    `, [betId]);

    if (betResult.rows.length === 0) {
      await client.query('ROLLBACK');
      return { success: false, error: 'Bet not found' };
    }

    const bet = betResult.rows[0];

    // Получаем всех участников
    const participantsResult = await client.query(`
      SELECT
        bp.*,
        u.telegram_id,
        u.username,
        u.first_name
      FROM bet_participants bp
      JOIN users u ON bp.user_id = u.id
      WHERE bp.bet_id = $1
    `, [betId]);

    const participants = participantsResult.rows;

    // Рассчитываем общий банк
    let totalBank = Number.parseFloat(bet.amount);
    participants.forEach(p => {
      totalBank += Number.parseFloat(p.amount);
    });

    const commissionRate = 0.10; // 10%
    const commission = totalBank * commissionRate;
    const netBank = totalBank - commission;

    // Находим победителей
    const winners = [];

    // Проверяем создателя
    if (bet.prediction_type === winningPrediction) {
      winners.push({
        user_id: bet.creator_id,
        amount: Number.parseFloat(bet.amount),
        is_creator: true
      });
    }

    // Проверяем участников
    participants.forEach(p => {
      let participantPrediction = winningPrediction; // по умолчанию проигрышный

      if (p.prediction_type) {
        // Новая логика: используем prediction_type
        participantPrediction = p.prediction_type;
      } else if (p.position) {
        // Старая логика: конвертируем position в prediction_type
        if (p.position === 'for') {
          participantPrediction = bet.prediction_type;
        } else { // position === 'against'
          // Для against выбираем любой другой исход кроме основного
          if (bet.prediction_type === 'home') participantPrediction = 'away';
          else if (bet.prediction_type === 'away') participantPrediction = 'home';
          else participantPrediction = 'home'; // если создатель поставил на draw, участник ставит на home
        }
      }

      if (participantPrediction === winningPrediction) {
        winners.push({
          user_id: p.user_id,
          amount: Number.parseFloat(p.amount),
          is_creator: false
        });
      }
    });

    // В системе споров на 3 исхода всегда должен быть ровно 1 победитель
    if (winners.length === 0) {
      await client.query('ROLLBACK');
      return { success: false, error: 'No winner found - this should not happen in 3-way betting system' };
    }

    if (winners.length > 1) {
      await client.query('ROLLBACK');
      return { success: false, error: 'Multiple winners found - this should not happen in 3-way betting system' };
    }

    // Есть ровно 1 победитель - он забирает весь банк
    const winner = winners[0];

    console.log(`💰 Bet ${betId} completed: Total bank ${totalBank} ${bet.currency}, Commission ${commission} ${bet.currency}, Net bank ${netBank} ${bet.currency}`);
    console.log(`🏆 Winner: User ${winner.user_id}, Amount bet: ${winner.amount} ${bet.currency}, Winnings: ${netBank} ${bet.currency}`);

    // Начисляем весь банк (минус комиссия) победителю
    if (bet.currency === 'TON') {
      await client.query(
        'UPDATE users SET ton_balance = ton_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [netBank, winner.user_id]
      );
    } else {
      await client.query(
        'UPDATE users SET stars_balance = stars_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
        [netBank, winner.user_id]
      );
    }

    // Транзакция выигрыша
    await client.query(`
      INSERT INTO transactions (user_id, bet_id, transaction_type, currency, amount, description)
      VALUES ($1, $2, 'bet_win', $3, $4, $5)
    `, [
      winner.user_id, betId, bet.currency, netBank,
      `Manual bet completion #${betId} - full bank of ${netBank} ${bet.currency}`
    ]);

    // Обновляем статус спора
    await client.query(
      'UPDATE bets SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
      ['completed', betId]
    );

    await client.query('COMMIT');
    return { success: true };

  } catch (error) {
    await client.query('ROLLBACK');
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

// GET endpoint для получения списка ставок, которые можно завершить
export async function GET() {
  try {
    const client = await pool.connect();

    try {
      const result = await client.query(`
        SELECT
          b.id as bet_id,
          b.status,
          b.prediction_type,
          m.home_team,
          m.away_team,
          m.league,
          m.start_time,
          m.status as match_status,
          m.home_score,
          m.away_score
        FROM bets b
        JOIN matches m ON b.match_id = m.id
        WHERE b.status = 'closed'
        ORDER BY m.start_time DESC
      `);

      return NextResponse.json({
        success: true,
        closed_bets: result.rows,
        message: 'Use POST with bet_id, home_score, away_score to manually complete a bet'
      });

    } finally {
      client.release();
    }

  } catch (error) {
    return NextResponse.json({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
