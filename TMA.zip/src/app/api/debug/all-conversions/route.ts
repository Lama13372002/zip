import { NextResponse } from 'next/server';
import pool from '@/lib/database';

export async function GET() {
  try {
    console.log('Debug API: Starting database queries...');

    // Сначала проверим подключение к базе
    await pool.query('SELECT 1');
    console.log('Debug API: Database connection OK');

    // Проверяем таблицы по одной
    let usersCount, conversionsCount, allConversions;

    try {
      const usersResult = await pool.query('SELECT COUNT(*) as count FROM users');
      usersCount = usersResult.rows[0].count;
      console.log('Debug API: Users count:', usersCount);
    } catch (error) {
      console.error('Debug API: Error querying users table:', error);
      usersCount = 'Error';
    }

    try {
      const conversionsResult = await pool.query('SELECT COUNT(*) as count FROM conversion_transactions');
      conversionsCount = conversionsResult.rows[0].count;
      console.log('Debug API: Conversions count:', conversionsCount);
    } catch (error) {
      console.error('Debug API: Error querying conversion_transactions table:', error);
      conversionsCount = 'Error';
    }

    try {
      const conversionsResult = await pool.query(
        `SELECT
          ct.*,
          u.telegram_id,
          u.username,
          u.first_name
         FROM conversion_transactions ct
         LEFT JOIN users u ON ct.user_id = u.id
         ORDER BY ct.created_at DESC
         LIMIT 20`
      );
      allConversions = conversionsResult.rows;
      console.log('Debug API: All conversions loaded, count:', allConversions.length);
    } catch (error) {
      console.error('Debug API: Error querying conversions with JOIN:', error);
      allConversions = [];
    }

    return NextResponse.json({
      allConversions,
      usersCount,
      conversionsCount,
      success: true,
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Debug API: Fatal error:', error);
    return NextResponse.json({
      error: 'Database connection failed',
      details: error instanceof Error ? error.message : 'Unknown error',
      success: false,
      timestamp: new Date().toISOString()
    }, { status: 500 });
  }
}
