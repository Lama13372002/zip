import { type NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';

export async function POST(request: NextRequest) {
  try {
    const telegramId = request.headers.get('x-telegram-user-id');
    if (!telegramId) {
      return NextResponse.json({ error: 'User not authenticated' }, { status: 401 });
    }

    const body = await request.json();
    const { amount, transactionId } = body;

    if (!amount || !transactionId) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Проверяем пользователя
    const userResult = await pool.query(
      'SELECT id FROM users WHERE telegram_id = $1',
      [telegramId]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const userId = userResult.rows[0].id;

    // Начинаем транзакцию
    const client = await pool.connect();

    try {
      await client.query('BEGIN');

      // Обновляем баланс пользователя
      const balanceUpdate = await client.query(
        'UPDATE users SET stars_balance = stars_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING stars_balance',
        [amount, userId]
      );

      console.log('Balance updated:', balanceUpdate.rows[0]);

      // Записываем транзакцию
      const transactionResult = await client.query(`
        INSERT INTO transactions (user_id, transaction_type, currency, amount, description, telegram_payment_id, created_at)
        VALUES ($1, 'deposit', 'STARS', $2, $3, $4, CURRENT_TIMESTAMP)
        RETURNING id
      `, [
        userId,
        amount,
        `Пополнение баланса Stars через Telegram`,
        transactionId
      ]);

      console.log('Transaction recorded successfully with ID:', transactionResult.rows[0].id);

      // Обрабатываем реферальную комиссию с депозита
      try {
        const commissionQuery = `
          SELECT process_deposit_commission($1, $2, $3, $4) as result
        `;

        const commissionResult = await client.query(commissionQuery, [
          telegramId,
          amount,
          'STARS',
          transactionResult.rows[0].id
        ]);

        const commissionData = commissionResult.rows[0].result;
        if (commissionData.success) {
          console.log('Referral commission processed:', commissionData.details);
        }
      } catch (commissionError) {
        console.error('Error processing referral commission:', commissionError);
        // Не прерываем транзакцию из-за ошибки комиссии
      }

      await client.query('COMMIT');

      console.log(`Stars payment processed: ${amount} STARS for user ${telegramId}`);

      return NextResponse.json({
        success: true,
        newBalance: balanceUpdate.rows[0].stars_balance
      });

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }

  } catch (error) {
    console.error('Error processing Stars payment:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
