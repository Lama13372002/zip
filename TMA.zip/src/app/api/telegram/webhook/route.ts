import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/db';
import pool from '@/lib/database';

const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;

interface TelegramUser {
  id: number;
  is_bot: boolean;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
}

interface TelegramChat {
  id: number;
  type: string;
}

interface TelegramMessage {
  message_id: number;
  from: TelegramUser;
  chat: TelegramChat;
  date: number;
  text?: string;
  successful_payment?: TelegramSuccessfulPayment;
}

interface TelegramSuccessfulPayment {
  currency: string;
  total_amount: number;
  invoice_payload: string;
  telegram_payment_charge_id: string;
}

interface TelegramPreCheckoutQuery {
  id: string;
  from: {
    id: number;
    first_name: string;
    last_name?: string;
    username?: string;
  };
  currency: string;
  total_amount: number;
  invoice_payload: string;
}

interface TelegramUpdate {
  update_id: number;
  message?: TelegramMessage;
  pre_checkout_query?: TelegramPreCheckoutQuery;
}

// Функция для отправки сообщения пользователю
async function sendMessage(chatId: number, text: string) {
  if (!TELEGRAM_BOT_TOKEN) return;

  try {
    await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: text,
        parse_mode: 'HTML'
      }),
    });
  } catch (error) {
    console.error('Error sending message:', error);
  }
}

// Функция для получения и сохранения фотографии пользователя
async function saveUserPhoto(userId: number) {
  if (!TELEGRAM_BOT_TOKEN) return false;

  try {
    // Получаем фотографии профиля пользователя
    const response = await fetch(
      `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getUserProfilePhotos?user_id=${userId}&limit=1`
    );

    if (!response.ok) {
      console.error('Failed to get user photos:', response.status);
      return false;
    }

    const data = await response.json();

    if (!data.ok || !data.result?.photos?.length) {
      console.log('User', userId, 'has no profile photos');
      // Сохраняем запись с null фотографией
      await query(
        `INSERT INTO user_photos (user_id, photo_url, file_id)
         VALUES ($1, NULL, NULL)
         ON CONFLICT (user_id) DO NOTHING`,
        [userId]
      );
      return true;
    }

    // Берем первую (самую большую) фотографию
    const photo = data.result.photos[0];
    const largestPhoto = photo[photo.length - 1]; // Последний элемент - самое большое разрешение

    // Получаем файл
    const fileResponse = await fetch(
      `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getFile?file_id=${largestPhoto.file_id}`
    );

    if (!fileResponse.ok) {
      console.error('Failed to get file info:', fileResponse.status);
      return false;
    }

    const fileData = await fileResponse.json();

    if (!fileData.ok) {
      console.error('Telegram getFile API error:', fileData.description);
      return false;
    }

    // Формируем URL для фотографии
    const photoUrl = `https://api.telegram.org/file/bot${TELEGRAM_BOT_TOKEN}/${fileData.result.file_path}`;

    // Сохраняем в базу данных
    await query(
      `INSERT INTO user_photos (user_id, photo_url, file_id)
       VALUES ($1, $2, $3)
       ON CONFLICT (user_id)
       DO UPDATE SET
         photo_url = EXCLUDED.photo_url,
         file_id = EXCLUDED.file_id,
         updated_at = CURRENT_TIMESTAMP`,
      [userId, photoUrl, largestPhoto.file_id]
    );

    console.log('Saved photo for user', userId);
    return true;

  } catch (error) {
    console.error('Error saving user photo:', error);
    return false;
  }
}

export async function POST(request: NextRequest) {
  // ВСЕГДА возвращаем быстрый ответ Telegram
  const respondToTelegram = () => NextResponse.json({ ok: true });

  try {
    const update: TelegramUpdate = await request.json();
    console.log('Telegram webhook received:', JSON.stringify(update, null, 2));

    // Обрабатываем pre_checkout_query НЕМЕДЛЕННО (критично!)
    if (update.pre_checkout_query) {
      const preCheckoutQuery = update.pre_checkout_query;
      console.log('Processing pre_checkout_query:', preCheckoutQuery);

      try {
        // Отвечаем OK на pre-checkout query с коротким таймаутом
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 секунд

        const response = await fetch(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/answerPreCheckoutQuery`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            pre_checkout_query_id: preCheckoutQuery.id,
            ok: true
          }),
          signal: controller.signal
        });

        clearTimeout(timeoutId);
        const responseData = await response.json();
        console.log('answerPreCheckoutQuery response:', responseData);

        if (!response.ok || !responseData.ok) {
          console.error('Failed to answer pre-checkout query:', responseData);
        }
      } catch (error) {
        console.error('Error answering pre-checkout query:', error);
      }

      return respondToTelegram();
    }

    // Для остальных обновлений - обрабатываем асинхронно
    // Возвращаем быстрый ответ Telegram, а затем обрабатываем в фоне
    setImmediate(() => {
      processUpdateInBackground(update);
    });

    return respondToTelegram();

  } catch (error) {
    console.error('Webhook error:', error);
    // Даже при ошибке возвращаем 200, чтобы не отключился webhook
    return respondToTelegram();
  }
}

// Асинхронная обработка обновлений в фоне
async function processUpdateInBackground(update: TelegramUpdate) {
  try {
    // Обрабатываем successful_payment
    if (update.message?.successful_payment) {
      await processSuccessfulPayment(update.message.successful_payment, update.message.from.id);
      return;
    }

    // Обрабатываем сообщения
    if (update.message) {
      await processMessage(update.message);
      return;
    }
  } catch (error) {
    console.error('Background processing error:', error);
    // Логируем ошибки, но не падаем
  }
}

// Вынесем обработку платежей в отдельную функцию
async function processSuccessfulPayment(payment: TelegramSuccessfulPayment, userId: number) {
  console.log('Processing successful_payment:', payment);

  let payload;
  try {
    payload = JSON.parse(payment.invoice_payload);
  } catch (error) {
    console.error('Failed to parse payload:', payment.invoice_payload, error);
    return;
  }

  const { user_id, telegram_id, amount, currency } = payload;

  if (currency !== 'STARS' || !user_id || !telegram_id || !amount) {
    console.error('Invalid payment data:', { user_id, telegram_id, amount, currency });
    return;
  }

  // Обработка БД с таймаутом
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // Устанавливаем таймаут для запросов БД (15 секунд)
    await client.query('SET statement_timeout = 15000');

    const userCheck = await client.query('SELECT id FROM users WHERE id = $1', [user_id]);
    if (userCheck.rows.length === 0) {
      console.error('User not found:', user_id);
      return;
    }

    const balanceUpdate = await client.query(
      'UPDATE users SET stars_balance = stars_balance + $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING stars_balance',
      [amount, user_id]
    );

    await client.query(`
      INSERT INTO transactions (user_id, transaction_type, currency, amount, description, telegram_payment_id, created_at)
      VALUES ($1, 'deposit', 'STARS', $2, $3, $4, CURRENT_TIMESTAMP)
    `, [user_id, amount, 'Пополнение баланса Stars через Telegram', payment.telegram_payment_charge_id]);

    await client.query('COMMIT');
    console.log(`Stars payment processed: ${amount} STARS for user ${telegram_id}`);

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Payment processing error:', error);
  } finally {
    client.release();
  }
}

// Вынесем обработку сообщений в отдельную функцию
async function processMessage(message: TelegramMessage) {
  const userId = message.from.id;
  const chatId = message.chat.id;
  const text = message.text;

  if (!text?.startsWith('/start')) {
    if (text?.startsWith('/')) {
      await sendMessage(chatId, 'Неизвестная команда. Используйте /start для настройки профиля.');
    }
    return;
  }

  console.log('Processing /start command for user', userId);

  // Парсим реферальный код
  const parts = text.split(' ');
  let referralCode = null;
  if (parts.length > 1 && parts[1].startsWith('ref_')) {
    referralCode = parts[1].substring(4);
  }

  try {
    // Регистрируем пользователя
    await query(
      `INSERT INTO users (telegram_id, username, first_name, last_name, created_at)
       VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)
       ON CONFLICT (telegram_id) DO NOTHING`,
      [userId, message.from.username || null, message.from.first_name, message.from.last_name || null]
    );

    // Обрабатываем реферала (если есть)
    if (referralCode) {
      await processReferral(userId, referralCode, chatId, message.from);
    } else {
      await sendMessage(chatId,
        '🎉 <b>Добро пожаловать!</b>\n\n' +
        'Ваш профиль успешно настроен для участия в спортивных спорах.'
      );
    }

    // Фото сохраняем в фоне (не критично)
    setImmediate(() => {
      saveUserPhoto(userId).catch(error => {
        console.log('Photo processing failed for user', userId, ':', error);
      });
    });

  } catch (error) {
    console.error('Error processing /start command:', error);
    await sendMessage(chatId, 'Произошла ошибка при настройке профиля.');
  }
}

// Обработка реферальной системы
async function processReferral(userId: number, referralCode: string, chatId: number, user: TelegramUser) {
  try {
    const referrerResult = await query(
      'SELECT id, telegram_id, username, first_name FROM users WHERE referral_code = $1',
      [referralCode]
    );

    if (referrerResult.rows.length > 0) {
      const referrer = referrerResult.rows[0];

      if (referrer.telegram_id.toString() !== userId.toString()) {
        const existingReferralResult = await query(
          'SELECT referred_by_code FROM users WHERE telegram_id = $1 AND referred_by_code IS NOT NULL',
          [userId]
        );

        if (existingReferralResult.rows.length === 0) {
          const referredResult = await query('SELECT id FROM users WHERE telegram_id = $1', [userId]);

          if (referredResult.rows.length > 0) {
            const referredId = referredResult.rows[0].id;

            await query('UPDATE users SET referred_by_code = $1 WHERE telegram_id = $2', [referralCode, userId]);
            await query(
              `INSERT INTO referrals (referrer_id, referred_id, referrer_telegram_id, referred_telegram_id, referral_code, status, created_at)
               VALUES ($1, $2, $3, $4, $5, 'pending', CURRENT_TIMESTAMP)`,
              [referrer.id, referredId, referrer.telegram_id, userId, referralCode]
            );
          }

          await sendMessage(chatId,
            `🎉 <b>Добро пожаловать!</b>\n\n` +
            `Вы присоединились по приглашению пользователя <b>${referrer.first_name || referrer.username || 'Пользователь'}</b>!\n\n` +
            `Ваш профиль успешно настроен для участия в спортивных спорах.`
          );
          return;
        }
      }
    }

    // Фолбэк сообщение
    await sendMessage(chatId,
      '🎉 <b>Добро пожаловать!</b>\n\n' +
      'Ваш профиль успешно настроен для участия в спортивных спорах.'
    );
  } catch (error) {
    console.error('Error processing referral:', error);
    await sendMessage(chatId,
      '🎉 <b>Добро пожаловать!</b>\n\n' +
      'Ваш профиль успешно настроен для участия в спортивных спорах.'
    );
  }
}
