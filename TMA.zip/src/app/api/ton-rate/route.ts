import { NextResponse } from 'next/server';

export async function GET() {
  try {
    // Прямой запрос к CoinGecko API без кэширования для реального времени
    const response = await fetch(
      'https://api.coingecko.com/api/v3/simple/price?ids=the-open-network&vs_currencies=usd',
      {
        headers: {
          'Accept': 'application/json',
        },
        // Убираем кэширование для реального времени
        cache: 'no-store'
      }
    );

    if (!response.ok) {
      throw new Error('Failed to fetch exchange rates');
    }

    const data = await response.json();
    const tonToUsd = data['the-open-network']?.usd || 5.1;

    return NextResponse.json({
      success: true,
      tonToUsd,
      starsToUsd: 0.015, // 1000 Stars = $15
      timestamp: Date.now()
    });

  } catch (error) {
    console.error('Error fetching TON rate:', error);

    return NextResponse.json({
      success: false,
      tonToUsd: 5.1, // fallback
      starsToUsd: 0.015,
      timestamp: Date.now(),
      error: 'Failed to fetch live rate'
    });
  }
}
