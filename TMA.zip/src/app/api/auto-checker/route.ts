import { NextRequest, NextResponse } from 'next/server';
import { AutoBetChecker } from '@/lib/auto-checker';

// Глобальный экземпляр чекера
let globalChecker: AutoBetChecker | null = null;

// GET - получить статус автопроверки
export async function GET() {
  try {
    if (!globalChecker) {
      return NextResponse.json({
        success: true,
        status: 'not_initialized',
        message: 'Автопроверка не инициализирована'
      });
    }

    const status = globalChecker.getStatus();

    return NextResponse.json({
      success: true,
      status: 'active',
      data: status
    });

  } catch (error) {
    console.error('Error getting auto-checker status:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}

// POST - управление автопроверкой
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, interval } = body;

    switch (action) {
      case 'start':
        if (!globalChecker) {
          const intervalSeconds = interval || 20;
          globalChecker = new AutoBetChecker(intervalSeconds);
        }

        globalChecker.start();

        return NextResponse.json({
          success: true,
          message: 'Автопроверка запущена',
          status: globalChecker.getStatus()
        });

      case 'stop':
        if (!globalChecker) {
          return NextResponse.json({
            success: false,
            message: 'Автопроверка не инициализирована'
          });
        }

        globalChecker.stop();

        return NextResponse.json({
          success: true,
          message: 'Автопроверка остановлена',
          status: globalChecker.getStatus()
        });

      case 'restart':
        if (globalChecker) {
          globalChecker.stop();
        }

        const newInterval = interval || 20;
        globalChecker = new AutoBetChecker(newInterval);
        globalChecker.start();

        return NextResponse.json({
          success: true,
          message: 'Автопроверка перезапущена',
          status: globalChecker.getStatus()
        });

      case 'update_interval':
        if (!globalChecker) {
          return NextResponse.json({
            success: false,
            message: 'Автопроверка не инициализирована'
          });
        }

        if (!interval || interval < 5) {
          return NextResponse.json({
            success: false,
            message: 'Интервал должен быть не менее 5 секунд'
          });
        }

        globalChecker.updateInterval(interval);

        return NextResponse.json({
          success: true,
          message: `Интервал изменен на ${interval} секунд`,
          status: globalChecker.getStatus()
        });

      default:
        return NextResponse.json({
          success: false,
          message: 'Неизвестное действие. Доступные: start, stop, restart, update_interval'
        }, { status: 400 });
    }

  } catch (error) {
    console.error('Error in auto-checker API:', error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
