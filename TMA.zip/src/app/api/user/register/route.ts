import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { telegram_id, username, first_name, last_name, referral_code } = body;

    if (!telegram_id) {
      return NextResponse.json({ error: 'telegram_id is required' }, { status: 400 });
    }

    const client = await pool.connect();

    try {
      // Проверяем, существует ли пользователь
      const existingUserResult = await client.query(
        'SELECT id, telegram_id, username, first_name, last_name, ton_balance, stars_balance, referral_code, referred_by_code FROM users WHERE telegram_id = $1',
        [telegram_id]
      );

      if (existingUserResult.rows.length > 0) {
        const user = existingUserResult.rows[0];
        return NextResponse.json({
          success: true,
          user: {
            id: user.id,
            telegram_id: user.telegram_id,
            username: user.username,
            first_name: user.first_name,
            last_name: user.last_name,
            ton_balance: parseFloat(user.ton_balance),
            stars_balance: parseFloat(user.stars_balance),
            referral_code: user.referral_code,
            referred_by_code: user.referred_by_code
          },
          message: 'User already exists'
        });
      }

      // Начинаем транзакцию для создания нового пользователя
      await client.query('BEGIN');

      try {
        // Создаем нового пользователя (реферальный код будет сгенерирован автоматически триггером)
        const newUserResult = await client.query(`
          INSERT INTO users (telegram_id, username, first_name, last_name, ton_balance, stars_balance)
          VALUES ($1, $2, $3, $4, 0.0, 0.0)
          RETURNING id, telegram_id, username, first_name, last_name, ton_balance, stars_balance, referral_code, created_at
        `, [telegram_id, username, first_name, last_name]);

        const newUser = newUserResult.rows[0];
        let referralCreated = false;
        let welcomeBonus = 0;

        // Если указан реферальный код, создаем связь
        if (referral_code && referral_code.trim() !== '') {
          try {
            // Проверяем, что реферальный код существует и валиден
            const referrerResult = await client.query(
              'SELECT id, telegram_id, username, first_name FROM users WHERE referral_code = $1',
              [referral_code.trim()]
            );

            if (referrerResult.rows.length > 0) {
              const referrer = referrerResult.rows[0];

              // Проверяем, что пользователь не пытается сослаться на самого себя
              if (referrer.telegram_id.toString() !== telegram_id.toString()) {
                // Обновляем пользователя с реферальным кодом
                await client.query(
                  'UPDATE users SET referred_by_code = $1 WHERE telegram_id = $2',
                  [referral_code.trim(), telegram_id]
                );

                // Создаем запись в таблице referrals
                await client.query(`
                  INSERT INTO referrals (
                    referrer_id,
                    referred_id,
                    referrer_telegram_id,
                    referred_telegram_id,
                    referral_code,
                    status,
                    created_at
                  ) VALUES ($1, $2, $3, $4, $5, 'active', CURRENT_TIMESTAMP)
                `, [
                  referrer.id,
                  newUser.id,
                  referrer.telegram_id,
                  telegram_id,
                  referral_code.trim()
                ]);

                // Получаем настройки бонусов
                const settingsResult = await client.query(`
                  SELECT setting_key, setting_value
                  FROM referral_settings
                  WHERE setting_key IN ('referral_welcome_bonus', 'referral_activation_bonus')
                `);

                const settings: { [key: string]: number } = {};
                settingsResult.rows.forEach(row => {
                  settings[row.setting_key] = parseFloat(row.setting_value);
                });

                // Начисляем приветственный бонус новому пользователю
                if (settings.referral_welcome_bonus > 0) {
                  welcomeBonus = settings.referral_welcome_bonus;

                  await client.query(
                    'UPDATE users SET stars_balance = stars_balance + $1 WHERE telegram_id = $2',
                    [welcomeBonus, telegram_id]
                  );

                  // Записываем в историю баланса
                  await client.query(`
                    INSERT INTO balance_history (
                      telegram_id, type, amount, balance_type, description
                    ) VALUES ($1, 'bonus', $2, 'stars', 'Приветственный бонус по реферальной программе')
                  `, [telegram_id, welcomeBonus]);
                }

                // Начисляем бонус реферру за активацию
                if (settings.referral_activation_bonus > 0) {
                  await client.query(
                    'UPDATE users SET stars_balance = stars_balance + $1 WHERE telegram_id = $2',
                    [settings.referral_activation_bonus, referrer.telegram_id]
                  );

                  // Записываем в историю баланса реферра
                  await client.query(`
                    INSERT INTO balance_history (
                      telegram_id, type, amount, balance_type, description
                    ) VALUES ($1, 'referral', $2, 'stars', 'Бонус за приглашение нового пользователя')
                  `, [referrer.telegram_id, settings.referral_activation_bonus]);
                }

                // Обновляем статистику реферра
                await client.query('SELECT update_referral_stats($1)', [referrer.telegram_id]);

                referralCreated = true;
              }
            }
          } catch (referralError) {
            console.error('Error creating referral relationship:', referralError);
            // Не прерываем создание пользователя из-за ошибки реферальной системы
          }
        }

        // Подтверждаем транзакцию
        await client.query('COMMIT');

        // Получаем обновленную информацию о пользователе
        const updatedUserResult = await client.query(
          'SELECT id, telegram_id, username, first_name, last_name, ton_balance, stars_balance, referral_code, referred_by_code FROM users WHERE telegram_id = $1',
          [telegram_id]
        );

        const updatedUser = updatedUserResult.rows[0];

        return NextResponse.json({
          success: true,
          user: {
            id: updatedUser.id,
            telegram_id: updatedUser.telegram_id,
            username: updatedUser.username,
            first_name: updatedUser.first_name,
            last_name: updatedUser.last_name,
            ton_balance: parseFloat(updatedUser.ton_balance),
            stars_balance: parseFloat(updatedUser.stars_balance),
            referral_code: updatedUser.referral_code,
            referred_by_code: updatedUser.referred_by_code,
            created_at: newUser.created_at
          },
          referral: {
            created: referralCreated,
            welcome_bonus: welcomeBonus
          },
          message: 'User created successfully'
        });

      } catch (error) {
        // Откатываем транзакцию в случае ошибки
        await client.query('ROLLBACK');
        throw error;
      }

    } finally {
      client.release();
    }

  } catch (error) {
    console.error('Error registering user:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
