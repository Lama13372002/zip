import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

// GET - получить текущую минимальную сумму ставки
export async function GET() {
  try {
    // Ищем настройку минимальной суммы ставки
    const result = await query(
      `SELECT setting_value FROM app_settings WHERE setting_key = $1`,
      ['minimum_bet_amount']
    );

    if (result.rows.length === 0) {
      // Если настройка не существует, создаем её с дефолтным значением
      await query(
        `INSERT INTO app_settings (setting_key, setting_value, description, created_at, updated_at)
         VALUES ($1, $2, $3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`,
        ['minimum_bet_amount', '1.0', 'Минимальная сумма для создания ставки']
      );
      return NextResponse.json({
        success: true,
        minimumAmount: '1.0',
        message: 'Создана новая настройка с дефолтным значением'
      });
    }

    return NextResponse.json({
      success: true,
      minimumAmount: result.rows[0].setting_value
    });

  } catch (error) {
    console.error('Ошибка при получении минимальной суммы ставки:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка при получении настроек' },
      { status: 500 }
    );
  }
}

// POST - обновить минимальную сумму ставки
export async function POST(request: NextRequest) {
  try {
    const { minimumAmount, adminPassword } = await request.json();

    // Простая проверка админ пароля
    if (adminPassword !== process.env.ADMIN_PASSWORD) {
      return NextResponse.json(
        { success: false, error: 'Неверный пароль администратора' },
        { status: 401 }
      );
    }

    // Валидация суммы
    const amount = parseFloat(minimumAmount);
    if (isNaN(amount) || amount < 0) {
      return NextResponse.json(
        { success: false, error: 'Неверная сумма. Должно быть число больше 0' },
        { status: 400 }
      );
    }

    // Проверяем, существует ли настройка
    const checkResult = await query(
      `SELECT id FROM app_settings WHERE setting_key = $1`,
      ['minimum_bet_amount']
    );

    if (checkResult.rows.length === 0) {
      // Создаем новую настройку
      await query(
        `INSERT INTO app_settings (setting_key, setting_value, description, created_at, updated_at)
         VALUES ($1, $2, $3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`,
        ['minimum_bet_amount', minimumAmount.toString(), 'Минимальная сумма для создания ставки']
      );
    } else {
      // Обновляем существующую настройку
      await query(
        `UPDATE app_settings
         SET setting_value = $1, updated_at = CURRENT_TIMESTAMP
         WHERE setting_key = $2`,
        [minimumAmount.toString(), 'minimum_bet_amount']
      );
    }

    // Логируем изменение (можно добавить таблицу для логов админ действий)
    console.log(`Админ изменил минимальную сумму ставки на: ${minimumAmount}`);

    return NextResponse.json({
      success: true,
      minimumAmount: minimumAmount.toString(),
      message: 'Минимальная сумма ставки успешно обновлена'
    });

  } catch (error) {
    console.error('Ошибка при обновлении минимальной суммы ставки:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка при обновлении настроек' },
      { status: 500 }
    );
  }
}
