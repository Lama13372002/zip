import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const adminPassword = searchParams.get('adminPassword');

    // Проверка пароля администратора
    if (adminPassword !== process.env.ADMIN_PASSWORD) {
      return NextResponse.json(
        { success: false, error: 'Неверный пароль администратора' },
        { status: 401 }
      );
    }

    console.log('🔍 Получение статистики...');

    // Статистика по депозитам TON
    const depositStatsResult = await query(`
      SELECT
        COUNT(*) as total_deposits,
        COALESCE(SUM(amount), 0) as total_deposit_amount
      FROM ton_transactions
      WHERE type = 'deposit' AND status = 'confirmed'
    `);

    // Статистика по выводам TON
    const withdrawalStatsResult = await query(`
      SELECT
        COUNT(*) as total_withdrawals,
        COALESCE(SUM(amount), 0) as total_withdrawal_amount
      FROM withdrawal_history
      WHERE status = 'completed'
    `);

    // Статистика по конвертации Stars в TON (дополнительные депозиты через Stars)
    const starsConversionStatsResult = await query(`
      SELECT
        COUNT(*) as total_stars_conversions,
        COALESCE(SUM(final_ton_amount), 0) as total_stars_converted_amount
      FROM conversion_transactions
      WHERE status = 'completed'
    `);

    // Статистика по спорам (исполненные ставки)
    const completedBetsStatsResult = await query(`
      SELECT
        COUNT(*) as total_completed_bets
      FROM bets
      WHERE status = 'completed'
    `);

    // Статистика по возвращенным ставкам
    const refundedBetsStatsResult = await query(`
      SELECT
        COUNT(*) as total_refunded_bets
      FROM bets
      WHERE status = 'refunded'
    `);

    // Правильная статистика по выигранным спорам (используем bet_win транзакции)
    const disputeWinsResult = await query(`
      SELECT
        COUNT(*) as won_disputes,
        COUNT(DISTINCT user_id) as unique_winners,
        COALESCE(SUM(amount), 0) as total_won_amount
      FROM transactions
      WHERE transaction_type = 'bet_win'
    `);

    // Статистика по участию в ставках (bet_join + bet_create)
    const participationsResult = await query(`
      SELECT
        COUNT(*) as total_participations,
        COUNT(DISTINCT user_id) as unique_participants,
        COALESCE(SUM(ABS(amount)), 0) as total_bet_amount
      FROM transactions
      WHERE transaction_type IN ('bet_join', 'bet_create')
    `);

    // Статистика по возвратам
    const refundsResult = await query(`
      SELECT
        COUNT(*) as total_refunds,
        COUNT(DISTINCT user_id) as unique_refunded_users,
        COALESCE(SUM(amount), 0) as total_refund_amount
      FROM transactions
      WHERE transaction_type = 'bet_refund'
    `);

    // Участники ставок по позициям (для детализации)
    const betParticipantsStatsResult = await query(`
      SELECT
        bp.position,
        COUNT(*) as total_participants,
        COALESCE(SUM(bp.amount), 0) as total_amount
      FROM bet_participants bp
      JOIN bets b ON bp.bet_id = b.id
      WHERE b.status = 'completed'
      GROUP BY bp.position
    `);

    // Статистика по общим транзакциям (для справки)
    const transactionStatsResult = await query(`
      SELECT
        transaction_type,
        COUNT(*) as count,
        COALESCE(SUM(amount), 0) as total_amount
      FROM transactions
      GROUP BY transaction_type
      ORDER BY count DESC
    `);

    // Формируем итоговую статистику
    const depositStats = depositStatsResult.rows[0];
    const withdrawalStats = withdrawalStatsResult.rows[0];
    const starsConversionStats = starsConversionStatsResult.rows[0];
    const completedBetsStats = completedBetsStatsResult.rows[0];
    const refundedBetsStats = refundedBetsStatsResult.rows[0];
    const disputeWins = disputeWinsResult.rows[0];
    const participations = participationsResult.rows[0];
    const refunds = refundsResult.rows[0];
    const betParticipantsStats = betParticipantsStatsResult.rows;
    const transactionStats = transactionStatsResult.rows;

    // Подсчет проигранных споров = общее участие - выигрыши - возвраты
    const totalParticipations = parseInt(participations.total_participations) || 0;
    const wonDisputes = parseInt(disputeWins.won_disputes) || 0;
    const refundedParticipations = parseInt(refunds.total_refunds) || 0;
    const lostDisputes = Math.max(0, totalParticipations - wonDisputes - refundedParticipations);

    const statistics = {
      deposits: {
        total_count: parseInt(depositStats.total_deposits),
        total_amount: parseFloat(depositStats.total_deposit_amount),
        stars_conversions: {
          count: parseInt(starsConversionStats.total_stars_conversions),
          amount: parseFloat(starsConversionStats.total_stars_converted_amount)
        }
      },
      withdrawals: {
        total_count: parseInt(withdrawalStats.total_withdrawals),
        total_amount: parseFloat(withdrawalStats.total_withdrawal_amount)
      },
      disputes: {
        total_completed: parseInt(completedBetsStats.total_completed_bets),
        total_refunded: parseInt(refundedBetsStats.total_refunded_bets),
        won_disputes: wonDisputes,
        lost_disputes: lostDisputes,
        unique_winners: parseInt(disputeWins.unique_winners) || 0,
        unique_participants: parseInt(participations.unique_participants) || 0,
        total_won_amount: parseFloat(disputeWins.total_won_amount) || 0,
        total_bet_amount: parseFloat(participations.total_bet_amount) || 0,
        total_refund_amount: parseFloat(refunds.total_refund_amount) || 0,
        participants_by_position: betParticipantsStats,
        detailed_stats: {
          total_participations: totalParticipations,
          refunded_participations: refundedParticipations,
          unique_refunded_users: parseInt(refunds.unique_refunded_users) || 0
        }
      },
      transactions: transactionStats,
      summary: {
        net_flow: parseFloat(depositStats.total_deposit_amount) + parseFloat(starsConversionStats.total_stars_converted_amount) - parseFloat(withdrawalStats.total_withdrawal_amount),
        total_platform_volume: parseFloat(participations.total_bet_amount) || 0
      }
    };

    console.log('✅ Статистика получена:', statistics);

    return NextResponse.json({
      success: true,
      statistics
    });

  } catch (error) {
    console.error('❌ Ошибка при получении статистики:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка при получении статистики' },
      { status: 500 }
    );
  }
}
