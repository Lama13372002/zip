import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

// GET - получить все настройки приложения
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const adminPassword = searchParams.get('adminPassword');

    // Простая проверка админ пароля
    if (adminPassword !== process.env.ADMIN_PASSWORD) {
      return NextResponse.json(
        { success: false, error: 'Неверный пароль администратора' },
        { status: 401 }
      );
    }

    // Получаем все настройки
    const result = await query(
      `SELECT setting_key, setting_value, description, created_at, updated_at
       FROM app_settings
       ORDER BY setting_key`
    );

    return NextResponse.json({
      success: true,
      settings: result.rows
    });

  } catch (error) {
    console.error('Ошибка при получении настроек:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка при получении настроек' },
      { status: 500 }
    );
  }
}

// POST - обновить несколько настроек
export async function POST(request: NextRequest) {
  try {
    const { settings, adminPassword } = await request.json();

    // Простая проверка админ пароля
    if (adminPassword !== process.env.ADMIN_PASSWORD) {
      return NextResponse.json(
        { success: false, error: 'Неверный пароль администратора' },
        { status: 401 }
      );
    }

    // Обновляем каждую настройку
    const updatedSettings = [];
    for (const setting of settings) {
      const { key, value, description } = setting;

      // Проверяем, существует ли настройка
      const checkResult = await query(
        `SELECT id FROM app_settings WHERE setting_key = $1`,
        [key]
      );

      if (checkResult.rows.length === 0) {
        // Создаем новую настройку
        await query(
          `INSERT INTO app_settings (setting_key, setting_value, description, created_at, updated_at)
           VALUES ($1, $2, $3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`,
          [key, value, description || '']
        );
      } else {
        // Обновляем существующую настройку
        await query(
          `UPDATE app_settings
           SET setting_value = $1, description = $2, updated_at = CURRENT_TIMESTAMP
           WHERE setting_key = $3`,
          [value, description || '', key]
        );
      }

      updatedSettings.push({ key, value, description });
    }

    console.log(`Админ обновил настройки:`, updatedSettings);

    return NextResponse.json({
      success: true,
      message: 'Настройки успешно обновлены',
      updatedSettings
    });

  } catch (error) {
    console.error('Ошибка при обновлении настроек:', error);
    return NextResponse.json(
      { success: false, error: 'Ошибка при обновлении настроек' },
      { status: 500 }
    );
  }
}
