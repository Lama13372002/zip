import { NextResponse } from 'next/server';
import { query } from '@/lib/database';

// GET - публичное получение минимальной суммы в долларах
export async function GET() {
  try {
    // Ищем настройку минимальной суммы в долларах
    const result = await query(
      `SELECT setting_value FROM app_settings WHERE setting_key = $1`,
      ['minimum_usd_amount']
    );

    let minimumUsdAmount = 10; // дефолтное значение

    if (result.rows.length === 0) {
      // Если настройка не существует, создаем её с дефолтным значением
      await query(
        `INSERT INTO app_settings (setting_key, setting_value, description, created_at, updated_at)
         VALUES ($1, $2, $3, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`,
        ['minimum_usd_amount', '10', 'Минимальная сумма для создания ставки в долларах США']
      );
    } else {
      minimumUsdAmount = parseFloat(result.rows[0].setting_value);
    }

    return NextResponse.json({
      success: true,
      minimumUsdAmount,
      timestamp: Date.now()
    });

  } catch (error) {
    console.error('Ошибка при получении минимальной суммы в USD:', error);
    // Возвращаем дефолтное значение при ошибке
    return NextResponse.json({
      success: false,
      minimumUsdAmount: 10,
      timestamp: Date.now(),
      error: 'Ошибка при получении настроек, используется дефолтное значение'
    });
  }
}
