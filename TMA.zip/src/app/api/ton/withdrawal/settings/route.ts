import { type NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

export async function GET(req: NextRequest) {
  try {
    const searchParams = req.nextUrl.searchParams;
    const telegramId = searchParams.get('telegramId');

    if (!telegramId) {
      return NextResponse.json(
        { error: 'Telegram ID is required' },
        { status: 400 }
      );
    }

    const result = await query(`
      SELECT * FROM withdrawal_settings
      WHERE telegram_id = $1
    `, [telegramId]);

    const settings = result.rows[0] || {
      enabled: false,
      min_balance: 5.0,
      target_wallet: '',
      auto_interval: 1440,
      commission_rate: 0.01,
      max_daily_amount: 100.0
    };

    return NextResponse.json({ settings });
  } catch (error) {
    console.error('Error fetching withdrawal settings:', error);
    return NextResponse.json(
      { error: 'Failed to fetch withdrawal settings' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      telegramId,
      enabled,
      minBalance,
      targetWallet,
      autoInterval,
      commissionRate,
      maxDailyAmount
    } = body;

    if (!telegramId) {
      return NextResponse.json(
        { error: 'Telegram ID is required' },
        { status: 400 }
      );
    }

    if (enabled && !targetWallet) {
      return NextResponse.json(
        { error: 'Target wallet is required when auto-withdrawal is enabled' },
        { status: 400 }
      );
    }

    // Проверяем, существует ли настройка
    const existingResult = await query(`
      SELECT id FROM withdrawal_settings
      WHERE telegram_id = $1
    `, [telegramId]);

    let result;
    if (existingResult.rows.length > 0) {
      // Обновляем существующую настройку
      result = await query(`
        UPDATE withdrawal_settings
        SET enabled = $2, min_balance = $3, target_wallet = $4,
            auto_interval = $5, commission_rate = $6, max_daily_amount = $7,
            updated_at = CURRENT_TIMESTAMP
        WHERE telegram_id = $1
        RETURNING *
      `, [telegramId, enabled, minBalance, targetWallet, autoInterval, commissionRate, maxDailyAmount]);
    } else {
      // Создаем новую настройку
      result = await query(`
        INSERT INTO withdrawal_settings
        (telegram_id, enabled, min_balance, target_wallet, auto_interval, commission_rate, max_daily_amount)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING *
      `, [telegramId, enabled, minBalance, targetWallet, autoInterval, commissionRate, maxDailyAmount]);
    }

    return NextResponse.json({
      success: true,
      settings: result.rows[0]
    });
  } catch (error) {
    console.error('Error updating withdrawal settings:', error);
    return NextResponse.json(
      { error: 'Failed to update withdrawal settings' },
      { status: 500 }
    );
  }
}
