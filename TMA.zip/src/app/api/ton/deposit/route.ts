import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/database';
import { tonApi, TonApiService } from '@/lib/ton-api';

export async function POST(request: NextRequest) {
  try {
    const telegramId = request.headers.get('x-telegram-user-id');
    if (!telegramId) {
      return NextResponse.json({ error: 'User not authenticated' }, { status: 401 });
    }

    const { amount, transactionHash, walletAddress, transactionBoc, confirmed } = await request.json();

    if (!amount || amount <= 0) {
      return NextResponse.json({ error: 'Invalid amount' }, { status: 400 });
    }

    if (!transactionHash) {
      return NextResponse.json({ error: 'Transaction hash required' }, { status: 400 });
    }

    // Получаем адрес получателя из переменных окружения
    const recipientAddress = process.env.TON_WALLET_ADDRESS;
    if (!recipientAddress) {
      return NextResponse.json({ error: 'Recipient address not configured' }, { status: 500 });
    }

    // Проверяем, не была ли уже обработана эта транзакция
    const existingTransaction = await pool.query(`
      SELECT id FROM ton_transactions
      WHERE transaction_hash = $1
    `, [transactionHash]);

    if (existingTransaction.rows.length > 0) {
      return NextResponse.json({ error: 'Transaction already processed' }, { status: 409 });
    }

    console.log('Processing TON deposit:', {
      from: walletAddress,
      to: recipientAddress,
      amount: amount,
      transactionHash: transactionHash,
      confirmed: confirmed
    });

    // Начинаем транзакцию БД
    const client = await pool.connect();

    try {
      await client.query('BEGIN');

      // Определяем статус на основе параметра confirmed
      const status = confirmed ? 'confirmed' : 'pending';

      // Записываем транзакцию
      const transactionResult = await client.query(`
        INSERT INTO ton_transactions (
          telegram_id,
          transaction_hash,
          amount,
          wallet_address,
          status,
          type,
          transaction_boc,
          verified_at,
          confirmed_at,
          created_at
        )
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())
        RETURNING id
      `, [
        telegramId,
        transactionHash,
        amount,
        walletAddress,
        status,
        'deposit',
        transactionBoc || null,
        confirmed ? new Date() : null,
        confirmed ? new Date() : null
      ]);

      const transactionId = transactionResult.rows[0].id;

      // Если транзакция подтверждена, обновляем баланс
      if (confirmed) {
        // Обновляем баланс пользователя
        await client.query(`
          UPDATE users
          SET ton_balance = ton_balance + $1,
              updated_at = NOW()
          WHERE telegram_id = $2
        `, [amount, telegramId]);

        // Записываем в историю баланса
        await client.query(`
          INSERT INTO balance_history (
            telegram_id,
            type,
            amount,
            balance_type,
            description,
            transaction_id,
            created_at
          )
          VALUES ($1, $2, $3, $4, $5, $6, NOW())
        `, [telegramId, 'deposit', amount, 'ton', `TON deposit via TonConnect from ${walletAddress}`, transactionId]);

        // Обрабатываем реферальную комиссию с депозита
        try {
          const commissionQuery = `
            SELECT process_deposit_commission($1, $2, $3, $4) as result
          `;

          const commissionResult = await client.query(commissionQuery, [
            telegramId,
            amount,
            'TON',
            transactionId
          ]);

          const commissionData = commissionResult.rows[0].result;
          if (commissionData.success) {
            console.log('Referral commission processed:', commissionData.details);
          }
        } catch (commissionError) {
          console.error('Error processing referral commission:', commissionError);
          // Не прерываем транзакцию из-за ошибки комиссии
        }
      }

      await client.query('COMMIT');

      // Получаем обновленный баланс
      const userResult = await pool.query(`
        SELECT ton_balance FROM users WHERE telegram_id = $1
      `, [telegramId]);

      const newBalance = userResult.rows[0] ? parseFloat(userResult.rows[0].ton_balance) : 0;

      return NextResponse.json({
        success: true,
        transactionId,
        newBalance,
        status,
        message: confirmed ? 'Deposit processed successfully' : 'Transaction saved, waiting for confirmation'
      });

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }

  } catch (error) {
    console.error('Error processing TON deposit:', error);
    return NextResponse.json({
      error: 'Internal server error',
      details: process.env.NODE_ENV === 'development' ? (error instanceof Error ? error.message : String(error)) : undefined
    }, { status: 500 });
  }
}
