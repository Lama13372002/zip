import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';
import { getTelegramBotUsername } from '@/lib/config';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const telegramId = searchParams.get('telegram_id');

    if (!telegramId) {
      return NextResponse.json({ error: 'telegram_id is required' }, { status: 400 });
    }

    // Получаем информацию о пользователе и его рефералах
    const userQuery = `
      SELECT
        id,
        telegram_id,
        username,
        first_name,
        referral_code,
        referred_by_code,
        total_referrals,
        active_referrals,
        referral_earnings,
        pending_ton_earnings,
        pending_stars_earnings
      FROM users
      WHERE telegram_id = $1
    `;

    const userResult = await query(userQuery, [telegramId]);

    if (userResult.rows.length === 0) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const user = userResult.rows[0];

    // Получаем список рефералов пользователя
    const referralsQuery = `
      SELECT
        r.id,
        r.referred_telegram_id,
        r.status,
        r.created_at,
        r.activated_at,
        r.first_bet_amount,
        r.first_bet_date,
        u.username as referred_username,
        u.first_name as referred_first_name,
        u.last_name as referred_last_name,
        COALESCE(SUM(re.commission_amount), 0) as total_earned
      FROM referrals r
      LEFT JOIN users u ON r.referred_telegram_id = u.telegram_id
      LEFT JOIN referral_earnings re ON r.id = re.referral_id
      WHERE r.referrer_telegram_id = $1
      GROUP BY r.id, r.referred_telegram_id, r.status, r.created_at, r.activated_at,
               r.first_bet_amount, r.first_bet_date, u.username, u.first_name, u.last_name
      ORDER BY r.created_at DESC
    `;

    const referralsResult = await query(referralsQuery, [telegramId]);

    // Получаем детальную статистику по заработку
    const earningsQuery = `
      SELECT
        earning_type,
        currency,
        SUM(commission_amount) as total_amount,
        COUNT(*) as transactions_count
      FROM referral_earnings
      WHERE referrer_telegram_id = $1
      GROUP BY earning_type, currency
      ORDER BY earning_type, currency
    `;

    const earningsResult = await query(earningsQuery, [telegramId]);

    // Получаем информацию о том, кто пригласил этого пользователя
    let referredBy = null;
    if (user.referred_by_code) {
      const referredByQuery = `
        SELECT
          u.telegram_id,
          u.username,
          u.first_name,
          u.referral_code,
          r.created_at as referral_date
        FROM users u
        LEFT JOIN referrals r ON u.telegram_id = r.referrer_telegram_id AND r.referred_telegram_id = $1
        WHERE u.referral_code = $2
      `;

      const referredByResult = await query(referredByQuery, [telegramId, user.referred_by_code]);
      if (referredByResult.rows.length > 0) {
        referredBy = referredByResult.rows[0];
      }
    }

    // Формируем реферальную ссылку
    const referralLink = `https://t.me/${getTelegramBotUsername()}?start=ref_${user.referral_code}`;

    const response = {
      user: {
        telegram_id: user.telegram_id,
        username: user.username,
        first_name: user.first_name,
        referral_code: user.referral_code,
        referral_link: referralLink,
        total_referrals: user.total_referrals || 0,
        active_referrals: user.active_referrals || 0,
        total_earnings: parseFloat(user.referral_earnings || '0'),
        pending_ton_earnings: parseFloat(user.pending_ton_earnings || '0'),
        pending_stars_earnings: parseFloat(user.pending_stars_earnings || '0')
      },
      referrals: referralsResult.rows.map(ref => ({
        id: ref.id,
        telegram_id: ref.referred_telegram_id,
        username: ref.referred_username,
        first_name: ref.referred_first_name,
        last_name: ref.referred_last_name,
        status: ref.status,
        joined_date: ref.created_at,
        activated_date: ref.activated_at,
        first_bet_amount: ref.first_bet_amount ? parseFloat(ref.first_bet_amount) : null,
        first_bet_date: ref.first_bet_date,
        total_earned: parseFloat(ref.total_earned || '0')
      })),
      earnings_breakdown: earningsResult.rows.map(earning => ({
        type: earning.earning_type,
        currency: earning.currency,
        total_amount: parseFloat(earning.total_amount),
        transactions_count: parseInt(earning.transactions_count)
      })),
      referred_by: referredBy
    };

    return NextResponse.json(response);

  } catch (error) {
    console.error('Error fetching referral info:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
