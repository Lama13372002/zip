import { NextRequest, NextResponse } from 'next/server';
import { query } from '@/lib/database';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { user_telegram_id, deposit_amount, currency, transaction_id } = body;

    if (!user_telegram_id || !deposit_amount || !currency) {
      return NextResponse.json({
        error: 'user_telegram_id, deposit_amount, and currency are required'
      }, { status: 400 });
    }

    if (!['TON', 'STARS'].includes(currency)) {
      return NextResponse.json({
        error: 'Currency must be TON or STARS'
      }, { status: 400 });
    }

    // Вызываем функцию базы данных для обработки депозитной комиссии
    const processQuery = `
      SELECT process_deposit_commission($1, $2, $3, $4) as result
    `;

    const result = await query(processQuery, [
      user_telegram_id,
      deposit_amount,
      currency,
      transaction_id
    ]);

    const processResult = result.rows[0].result;

    if (!processResult.success) {
      return NextResponse.json({
        success: false,
        message: processResult.message
      }, { status: 200 });
    }

    return NextResponse.json({
      success: true,
      commission_processed: true,
      details: processResult.details
    });

  } catch (error) {
    console.error('Error processing deposit commission:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
