// Типы для API запросов
export interface CreateBetRequest {
  match_id: number;
  team_side: 'team1' | 'team2';
  amount: number;
  currency: string;
  description?: string;
}

export interface JoinBetRequest {
  bet_id: number;
}

export interface ApiRequestData {
  [key: string]: unknown;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

// Типы для ответов API
export interface BetParticipant {
  id: number;
  user_id: number;
  bet_id: number;
  amount: number;
  position?: string;
  joined_at: string;
  username?: string;
  first_name?: string;
  last_name?: string;
}

export interface BetMatch {
  id: number;
  home_team: string;
  away_team: string;
  home_team_logo?: string;
  away_team_logo?: string;
  league: string;
  league_logo?: string;
  start_time: string;
  venue?: string;
  status: string;
  minute?: number;
  home_score?: number;
  away_score?: number;
}

export interface BetResult {
  finalScore?: { home: number; away: number };
  payout?: number;
}

export interface Bet {
  id: number;
  match_id: number;
  creator_id: number;
  prediction_type: string;
  prediction_text: string;
  amount: number;
  currency: "TON" | "STARS";
  odds?: number;
  max_participants?: number;
  status: string;
  created_at: string;
  creator_username?: string;
  creator_first_name?: string;
  creator_last_name?: string;
  home_team: string;
  away_team: string;
  home_team_logo?: string;
  away_team_logo?: string;
  league: string;
  league_logo?: string;
  match_start_time: string;
  venue?: string;
  match_status: string;
  participants_count: number;
  time_left_seconds?: number;
  can_join?: boolean;
  match?: BetMatch;
  participants?: BetParticipant[];
  result?: BetResult;
  user_participation?: {
    amount: number;
    position?: string;
    joined_at: string;
    role: "creator" | "participant";
  };
  user_role?: "creator" | "participant";
  user_status?: string;
  [key: string]: unknown;
}

export interface BetStats {
  total_bets: number;
  total_amount_ton: number;
  total_amount_stars: number;
  [key: string]: unknown;
}

export interface GetBetsResponse {
  bets: Bet[];
  stats: BetStats;
}

export interface ApiResponse<T = unknown> {
  success?: boolean;
  data?: T;
  error?: string;
  bets?: Bet[];
  stats?: BetStats;
  [key: string]: unknown;
}

export interface UserData {
  id: number;
  telegram_id: number;
  username?: string;
  first_name?: string;
  last_name?: string;
  ton_balance: number;
  stars_balance: number;
  created_at?: string;
  [key: string]: unknown;
}

export interface ReferralInfo {
  created?: boolean;
  welcome_bonus?: number;
  [key: string]: unknown;
}

export interface RegisterUserResponse {
  user: UserData;
  referral?: ReferralInfo;
  [key: string]: unknown;
}
