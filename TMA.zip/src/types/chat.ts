export interface ChatRoom {
  id: number;
  name: string;
  description?: string;
  is_general: boolean;
  created_at: string;
  updated_at: string;
  message_count?: number;
}

export interface ChatMessage {
  id: number;
  room_id: number;
  user_id: number;
  username?: string;
  first_name?: string;
  last_name?: string;
  message: string;
  is_system: boolean;
  reply_to_id?: number;
  created_at: string;
}

export interface ChatUser {
  id: number;
  username?: string;
  first_name?: string;
  last_name?: string;
  role?: 'admin' | 'moderator' | 'user';
}

export interface SendMessageRequest {
  roomId: number;
  userId: number;
  message: string;
  replyToId?: number;
}

export interface DeleteMessageRequest {
  messageId: number;
  userId: number;
  isAdmin?: boolean;
}

export interface ChatStats {
  overall: {
    total_messages: number;
    messages_last_day: number;
    messages_last_week: number;
    old_messages_to_cleanup: number;
    latest_message_time?: string;
    oldest_message_time?: string;
  };
  byRoom: {
    name: string;
    message_count: number;
  }[];
}

export interface ChatUpdates {
  newMessages: ChatMessage[];
  deletedMessageIds: number[];
  syncTime: string;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}
