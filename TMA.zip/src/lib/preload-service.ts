import type { MatchEvent, League } from '@/types/football';

type PreloadedData = {
  liveMatches: MatchEvent[];
  todayMatches: MatchEvent[];
  popularLeagues: League[];
  timestamp: number;
};

class PreloadService {
  private cache: Map<string, PreloadedData> = new Map();
  private readonly CACHE_DURATION = 5 * 60 * 1000; // 5 минут
  private preloadPromise: Promise<void> | null = null;

  // Предзагрузка данных о футболе
  async preloadFootballData(): Promise<void> {
    // Если уже идет предзагрузка, ждем её завершения
    if (this.preloadPromise) {
      return this.preloadPromise;
    }

    this.preloadPromise = this.doPreload();
    return this.preloadPromise;
  }

  private async doPreload(): Promise<void> {
    try {
      console.log('🏈 Начинаем предзагрузку футбольных данных...');

      // Предзагружаем главную страницу футбола
      const response = await fetch('/api/football/home');
      if (response.ok) {
        const result = await response.json();
        if (result.success) {
          this.cache.set('football-home', {
            ...result.data,
            timestamp: Date.now()
          });

          // Предзагружаем изображения логотипов команд
          this.preloadTeamLogos(result.data);

          console.log('✅ Футбольные данные предзагружены успешно');
        }
      }
    } catch (error) {
      console.error('❌ Ошибка предзагрузки футбольных данных:', error);
    } finally {
      this.preloadPromise = null;
    }
  }

  // Предзагрузка логотипов команд в фоне
  private preloadTeamLogos(data: { liveMatches?: MatchEvent[]; todayMatches?: MatchEvent[] }): void {
    const allMatches = [
      ...(data.liveMatches || []),
      ...(data.todayMatches || [])
    ];

    const logoUrls = new Set<string>();

    allMatches.forEach((match: MatchEvent) => {
      if (match.homeTeamLogo) logoUrls.add(match.homeTeamLogo);
      if (match.awayTeamLogo) logoUrls.add(match.awayTeamLogo);
    });

    // Асинхронно предзагружаем логотипы
    logoUrls.forEach(logoUrl => {
      if (logoUrl && logoUrl.startsWith('http')) {
        const img = new Image();
        img.src = logoUrl;
        // Логи только для отладки
        img.onload = () => console.log(`✅ Логотип предзагружен: ${logoUrl}`);
        img.onerror = () => console.warn(`⚠️ Не удалось загрузить логотип: ${logoUrl}`);
      }
    });

    console.log(`🖼️ Запущена предзагрузка ${logoUrls.size} логотипов команд`);
  }

  // Получить предзагруженные данные
  getCachedData(key: string): PreloadedData | null {
    const cached = this.cache.get(key);
    if (!cached) return null;

    // Проверяем свежесть данных
    if (Date.now() - cached.timestamp > this.CACHE_DURATION) {
      this.cache.delete(key);
      return null;
    }

    return cached;
  }

  // Проверить, есть ли предзагруженные данные
  hasPreloadedData(): boolean {
    return this.getCachedData('football-home') !== null;
  }

  // Очистить кэш
  clearCache(): void {
    this.cache.clear();
  }
}

export const preloadService = new PreloadService();
