import { query } from '@/lib/database';

export interface BlockCheckResult {
  isBlocked: boolean;
  isBlockedApp: boolean;
  isBlockedChat: boolean;
  blockReason: string | null;
}

export async function checkUserBlockStatus(userId: number): Promise<BlockCheckResult> {
  try {
    const result = await query(`
      SELECT
        is_blocked_app,
        is_blocked_chat,
        block_reason
      FROM users
      WHERE id = $1
    `, [userId]);

    if (result.rows.length === 0) {
      return {
        isBlocked: false,
        isBlockedApp: false,
        isBlockedChat: false,
        blockReason: null
      };
    }

    const user = result.rows[0];
    const isBlockedApp = user.is_blocked_app || false;
    const isBlockedChat = user.is_blocked_chat || false;

    return {
      isBlocked: isBlockedApp || isBlockedChat,
      isBlockedApp,
      isBlockedChat,
      blockReason: user.block_reason
    };

  } catch (error) {
    console.error('Ошибка при проверке статуса блокировки:', error);
    // В случае ошибки возвращаем безопасное значение
    return {
      isBlocked: false,
      isBlockedApp: false,
      isBlockedChat: false,
      blockReason: null
    };
  }
}

export async function checkUserBlockStatusByTelegramId(telegramId: string): Promise<BlockCheckResult> {
  try {
    const result = await query(`
      SELECT
        id,
        is_blocked_app,
        is_blocked_chat,
        block_reason
      FROM users
      WHERE telegram_id = $1
    `, [telegramId]);

    if (result.rows.length === 0) {
      return {
        isBlocked: false,
        isBlockedApp: false,
        isBlockedChat: false,
        blockReason: null
      };
    }

    const user = result.rows[0];
    const isBlockedApp = user.is_blocked_app || false;
    const isBlockedChat = user.is_blocked_chat || false;

    return {
      isBlocked: isBlockedApp || isBlockedChat,
      isBlockedApp,
      isBlockedChat,
      blockReason: user.block_reason
    };

  } catch (error) {
    console.error('Ошибка при проверке статуса блокировки:', error);
    // В случае ошибки возвращаем безопасное значение
    return {
      isBlocked: false,
      isBlockedApp: false,
      isBlockedChat: false,
      blockReason: null
    };
  }
}
