/**
 * Сервис для мониторинга и автоматической проверки TON транзакций
 */
import pool from './database';
import { tonApi, TonApiService } from './ton-api';
import { PoolClient } from 'pg';

interface PendingTransaction {
  id: number;
  telegram_id: string;
  transaction_hash: string;
  amount: number;
  wallet_address: string;
  created_at: Date;
}

export class TonTransactionMonitor {
  private isRunning = false;
  private checkInterval = 30000; // 30 секунд
  private maxRetries = 10;
  private recipientAddress: string;

  constructor(recipientAddress: string) {
    this.recipientAddress = recipientAddress;
  }

  /**
   * Запустить мониторинг транзакций
   */
  start() {
    if (this.isRunning) {
      console.log('Transaction monitor is already running');
      return;
    }

    this.isRunning = true;
    console.log('Starting TON transaction monitor...');
    this.monitorLoop();
  }

  /**
   * Остановить мониторинг транзакций
   */
  stop() {
    this.isRunning = false;
    console.log('Stopping TON transaction monitor...');
  }

  /**
   * Основной цикл мониторинга
   */
  private async monitorLoop() {
    while (this.isRunning) {
      try {
        await this.checkPendingTransactions();
      } catch (error) {
        console.error('Error in transaction monitor loop:', error);
      }

      // Ждем перед следующей проверкой
      await new Promise(resolve => setTimeout(resolve, this.checkInterval));
    }
  }

  /**
   * Проверить все ожидающие транзакции
   */
  private async checkPendingTransactions() {
    const client = await pool.connect();

    try {
      // Получаем все неподтвержденные транзакции
      const result = await client.query(`
        SELECT id, telegram_id, transaction_hash, amount, wallet_address, created_at
        FROM ton_transactions
        WHERE status = 'pending'
        AND created_at > NOW() - INTERVAL '1 hour'
        ORDER BY created_at DESC
        LIMIT 50
      `);

      const pendingTransactions: PendingTransaction[] = result.rows;

      console.log(`Checking ${pendingTransactions.length} pending transactions...`);

      for (const transaction of pendingTransactions) {
        await this.verifyTransaction(transaction);
      }

    } finally {
      client.release();
    }
  }

  /**
   * Проверить конкретную транзакцию
   */
  private async verifyTransaction(transaction: PendingTransaction) {
    const client = await pool.connect();

    try {
      console.log(`Verifying transaction ${transaction.transaction_hash}...`);

      // Проверяем транзакцию через TON API
      const verification = await tonApi.verifyPayment(
        transaction.wallet_address,
        this.recipientAddress,
        TonApiService.tonToNano(transaction.amount),
        3600 // 1 час окно для поиска
      );

      if (verification.verified && verification.transaction) {
        // Транзакция подтверждена
        await this.confirmTransaction(client, transaction, verification.transaction);
        console.log(`Transaction ${transaction.transaction_hash} confirmed`);

      } else {
        // Проверяем, не истекло ли время ожидания
        const hoursSinceCreation = (Date.now() - transaction.created_at.getTime()) / (1000 * 60 * 60);

        if (hoursSinceCreation > 2) { // 2 часа максимум
          await this.failTransaction(client, transaction, 'Transaction verification timeout');
          console.log(`Transaction ${transaction.transaction_hash} failed due to timeout`);
        } else {
          console.log(`Transaction ${transaction.transaction_hash} still pending...`);
        }
      }

    } catch (error) {
      console.error(`Error verifying transaction ${transaction.transaction_hash}:`, error);

      // Увеличиваем счетчик попыток
      await client.query(`
        UPDATE ton_transactions
        SET error_message = $1
        WHERE id = $2
      `, [error instanceof Error ? error.message : String(error), transaction.id]);

    } finally {
      client.release();
    }
  }

  /**
   * Подтвердить транзакцию
   */
  private async confirmTransaction(
    client: PoolClient,
    transaction: PendingTransaction,
    verifiedTx: { hash: string; in_msg?: { value: string }; utime: number }
  ) {
    try {
      await client.query('BEGIN');

      // Обновляем статус транзакции
      await client.query(`
        UPDATE ton_transactions
        SET status = 'confirmed',
            confirmed_at = NOW(),
            verified_at = NOW()
        WHERE id = $1
      `, [transaction.id]);

      // Обновляем баланс пользователя (только если еще не обновлен)
      const balanceCheck = await client.query(`
        SELECT COUNT(*) FROM balance_history
        WHERE transaction_id = $1 AND type = 'deposit'
      `, [transaction.id]);

      if (parseInt(balanceCheck.rows[0].count) === 0) {
        // Обновляем баланс
        await client.query(`
          UPDATE users
          SET ton_balance = ton_balance + $1, updated_at = NOW()
          WHERE telegram_id = $2
        `, [transaction.amount, transaction.telegram_id]);

        // Записываем в историю баланса
        await client.query(`
          INSERT INTO balance_history (
            telegram_id, type, amount, balance_type,
            description, transaction_id, created_at
          )
          VALUES ($1, $2, $3, $4, $5, $6, NOW())
        `, [
          transaction.telegram_id,
          'deposit',
          transaction.amount,
          'ton',
          `Verified TON deposit from ${transaction.wallet_address}`,
          transaction.id
        ]);
      }

      await client.query('COMMIT');

    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    }
  }

  /**
   * Пометить транзакцию как неуспешную
   */
  private async failTransaction(
    client: PoolClient,
    transaction: PendingTransaction,
    reason: string
  ) {
    await client.query(`
      UPDATE ton_transactions
      SET status = 'failed',
          failed_at = NOW(),
          error_message = $1
      WHERE id = $2
    `, [reason, transaction.id]);
  }

  /**
   * Получить статистику мониторинга
   */
  async getStats() {
    const result = await pool.query(`
      SELECT
        status,
        COUNT(*) as count,
        SUM(amount) as total_amount
      FROM ton_transactions
      WHERE created_at > NOW() - INTERVAL '24 hours'
      GROUP BY status
    `);

    return result.rows;
  }
}

// Создаем и экспортируем экземпляр монитора
const recipientAddress = process.env.TON_WALLET_ADDRESS;
export const transactionMonitor = recipientAddress
  ? new TonTransactionMonitor(recipientAddress)
  : null;

// Автозапуск в продакшене
if (process.env.NODE_ENV === 'production' && transactionMonitor) {
  transactionMonitor.start();
}
